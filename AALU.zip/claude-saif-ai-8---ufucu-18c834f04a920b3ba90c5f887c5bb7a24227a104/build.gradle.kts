/*
 * Copyright (c) SAIF AI. All rights reserved.
 *
 * Root build script. Its only job is to declare the plugins the modules share; every module
 * then opts in with `alias(...)` of its own, so nothing here is applied to a project that did
 * not ask for it.
 */

plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.android.library) apply false
    alias(libs.plugins.compose.compiler) apply false
    alias(libs.plugins.kotlin.serialization) apply false
    alias(libs.plugins.google.devtools.ksp) apply false
    alias(libs.plugins.google.services) apply false
}
