/*
 * Copyright (c) SAIF AI. All rights reserved.
 *
 * Where this build gets its plugins and its libraries from, and which modules it contains.
 *
 * Each repository is scoped to the groups it actually serves. That is not decoration: with
 * FAIL_ON_PROJECT_REPOS below, a dependency resolved by accident from the wrong repository
 * becomes a build error instead of a silent, un-reproducible download.
 */

pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("androidx.*")
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)

    repositories {
        // One dependency in this build - the embeddable Kotlin compiler - is large enough that
        // Maven Central occasionally hands CI a redirect that then times out. When CI has
        // already fetched and checksum-verified it, it points SAIF_VERIFIED_MAVEN_DIR at that
        // folder and the artifact is read from disk instead. Local builds never set it.
        System.getenv("SAIF_VERIFIED_MAVEN_DIR")
            ?.takeIf { it.isNotBlank() }
            ?.let { verifiedDir ->
                maven {
                    url = uri(verifiedDir)
                    content { includeModule("org.jetbrains.kotlin", "kotlin-compiler-embeddable") }
                    metadataSources {
                        mavenPom()
                        ignoreGradleMetadataRedirection()
                    }
                }
            }

        google {
            content {
                includeGroupByRegex("androidx.*")
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
            }
        }
        mavenCentral()

        // JitPack serves the few libraries that publish straight from a Git tag.
        maven("https://jitpack.io")
    }
}

plugins {
    // Lets Gradle download the JDK the toolchain asks for instead of failing when it is absent.
    id("org.gradle.toolchains.foojay-resolver-convention") version "1.0.0"
}

rootProject.name = "SAIF AI"

include(":app")

// The empty Android app that the on-device compiler wraps a generated project inside.
include(":apprunner")
