/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saifagent

import android.content.Context
import com.example.saifagent.tools.ProcessShellRunner
import com.example.saifagent.tools.ShellRunner
import java.io.File

/**
 * The front door to SAIF AI's own agent runtime.
 *
 * One call — [runTask] — is all the UI needs. Everything else here is wiring: where the workspace
 * lives, which shell the command tool uses, and how the runtime reaches a model. Each of those is
 * replaceable, and none of them is required for the runtime to work.
 *
 * This module is intentionally self-contained. It depends only on SAIF AI's own provider layer
 * (`com.example.llm`) and on the Android platform, so it can be kept, moved or relicensed on its own.
 */
object SaifAgent {

    /** Commands the shell tool is never allowed to run, however the rest of the policy is set. */
    private val BLOCKED_COMMAND_PATTERNS = listOf(
        Regex("(?i)\\brm\\s+-rf\\s+/(?!\\s)"),   // rm -rf at the filesystem root
        Regex("(?i)\\bmkfs\\b"),
        Regex("(?i):\\(\\)\\{.*\\|.*&.*\\}"),     // fork bomb
        Regex("(?i)\\bdd\\s+if=.*of=/dev/")
    )

    fun init(context: Context) {
        AgentPrefs.init(context)
    }

    /** The single directory the agent's tools may read and write. */
    fun workspace(context: Context): File =
        File(context.applicationContext.filesDir, AgentPrefs.workspaceDir).apply { mkdirs() }

    /**
     * The shell the command tool uses.
     *
     * The default is Android's own `/system/bin/sh`. A Linux environment can be substituted later by
     * passing a different [ShellRunner] to [runtime] — this module never reaches for one itself.
     */
    fun defaultShell(): ShellRunner = ProcessShellRunner()

    /** True when the agent has a usable model to talk to. */
    fun isConfigured(): Boolean =
        com.example.data.local.ProviderSettingsManager.getActiveModel().isNotBlank() &&
            com.example.data.local.ProviderSettingsManager.hasCustomUserKey()

    /** Which provider and model the next run will use, for display. */
    fun activeTarget(): String {
        val provider = com.example.data.local.ProviderSettingsManager.getActiveProvider()
        val model = com.example.data.local.ProviderSettingsManager.getActiveModel()
        return if (model.isBlank()) provider else "$provider · $model"
    }

    /**
     * Builds a runtime.
     *
     * @param shell command runner; defaults to the Android shell
     * @param extraTools capability the caller wants to add on top of the default kit
     */
    fun runtime(
        shell: ShellRunner = defaultShell(),
        extraTools: List<AgentTool> = emptyList()
    ): AgentRuntime {
        val registry = ToolRegistry.defaults(
            shell = shell,
            searchEndpoint = { AgentPrefs.searchEndpoint },
            commandPolicy = ::isCommandAllowed
        )
        extraTools.forEach { registry.register(it) }
        return AgentRuntime(
            registry = registry,
            model = providerGateway(),
            maxSteps = AgentPrefs.maxSteps,
            autoApprove = { AgentPrefs.autoApprove }
        )
    }

    /** Sends one task through the runtime. See [AgentRuntime.run]. */
    fun runTask(
        task: String,
        workspace: File,
        approval: ApprovalGate,
        shell: ShellRunner = defaultShell(),
        isCancelled: () -> Boolean = { false }
    ) = runtime(shell).run(task, workspace, approval, isCancelled)

    /**
     * Bridges the runtime to SAIF AI's provider gateway.
     *
     * `jsonMode` is requested because the protocol expects a JSON object; the parser still copes
     * when a provider ignores it, so this is a hint rather than a requirement.
     */
    private fun providerGateway(): ModelGateway = object : ModelGateway {
        override suspend fun complete(system: String, prompt: String): Result<String> {
            val provider = com.example.data.local.ProviderSettingsManager.getActiveProvider()
            val model = com.example.data.local.ProviderSettingsManager.getActiveModel()
            val key = com.example.data.local.ProviderSettingsManager.getActiveApiKey()
            if (model.isBlank()) return Result.failure(IllegalStateException("No model selected"))
            if (key.isBlank()) return Result.failure(IllegalStateException("No API key configured"))

            val request = com.example.llm.LlmRequest(
                prompt = prompt,
                systemPrompt = system,
                mode = "agent",
                jsonMode = true,
                maxTokens = 4096
            )
            return com.example.llm.LlmGateway.call(
                role = com.example.llm.LlmRole.CODER,
                provider = provider,
                apiKey = key,
                model = model,
                request = request
            ).map { it.text }
        }
    }

    /** Final guard on the command tool: some commands are refused regardless of approval. */
    fun isCommandAllowed(command: String): Boolean =
        BLOCKED_COMMAND_PATTERNS.none { it.containsMatchIn(command) }
}
