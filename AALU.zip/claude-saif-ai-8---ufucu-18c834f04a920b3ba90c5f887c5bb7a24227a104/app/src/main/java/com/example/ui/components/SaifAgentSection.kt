/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.saifagent.AgentPrefs
import com.example.saifagent.AgentRuntime
import com.example.saifagent.ApprovalGate
import com.example.saifagent.SaifAgent
import com.example.ui.theme.SaifTheme
import kotlinx.coroutines.launch

/**
 * Settings → SAIF AI AGENT (OWN ENGINE).
 *
 * This is the control surface for the agent runtime SAIF AI owns outright: which model it drives,
 * what it is allowed to touch, and a "test run" so the user can watch it work before relying on it.
 *
 * The distinction matters for licensing as much as for function — everything behind this screen is
 * original SAIF AI code, with no third-party agent engine involved.
 */
@Composable
fun SaifAgentSection(glassBorderBrush: Brush) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var enabled by remember { mutableStateOf(AgentPrefs.enabled) }
    var autoApprove by remember { mutableStateOf(AgentPrefs.autoApprove) }
    var searchEndpoint by remember { mutableStateOf(AgentPrefs.searchEndpoint) }
    var maxStepsText by remember { mutableStateOf(AgentPrefs.maxSteps.toString()) }

    var log by remember { mutableStateOf("") }
    var running by remember { mutableStateOf(false) }

    LiquidSurface(
        color = SaifTheme.colors.surfaceCard,
        glassBorderBrush = glassBorderBrush,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .background(Color(0xFF7C5CE0).copy(alpha = 0.16f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Outlined.Psychology, contentDescription = null,
                        tint = Color(0xFF7C5CE0), modifier = Modifier.size(17.dp)
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "Enable SAIF AI agent",
                        color = SaifTheme.colors.textPrimary,
                        fontSize = 15.sp, fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        "SAIF AI's own tool-using runtime. Files, search and shell, confined to one folder.",
                        color = SaifTheme.colors.textSecondary, fontSize = 12.sp
                    )
                }
                Switch(checked = enabled, onCheckedChange = {
                    enabled = it
                    AgentPrefs.enabled = it
                })
            }

            HorizontalDivider(color = SaifTheme.colors.cardBorder)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Auto-approve tool calls",
                        color = SaifTheme.colors.textPrimary, fontSize = 15.sp
                    )
                    Text(
                        "Off means every file write and command is confirmed first.",
                        color = SaifTheme.colors.textSecondary, fontSize = 12.sp
                    )
                }
                Switch(checked = autoApprove, onCheckedChange = {
                    autoApprove = it
                    AgentPrefs.autoApprove = it
                })
            }

            HorizontalDivider(color = SaifTheme.colors.cardBorder)
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text(
                    "Model", color = SaifTheme.colors.textSecondary, fontSize = 11.5.sp
                )
                Text(
                    if (SaifAgent.isConfigured()) SaifAgent.activeTarget()
                    else "No provider key set — add one in your provider settings first.",
                    color = if (SaifAgent.isConfigured()) SaifTheme.colors.textPrimary else Color(0xFFEF4444),
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(10.dp))
                Text("Workspace", color = SaifTheme.colors.textSecondary, fontSize = 11.5.sp)
                Text(
                    SaifAgent.workspace(context).absolutePath,
                    color = SaifTheme.colors.textPrimary,
                    fontSize = 12.sp, fontFamily = FontFamily.Monospace
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = maxStepsText,
                        onValueChange = { text ->
                            maxStepsText = text.filter { it.isDigit() }.take(3)
                            maxStepsText.toIntOrNull()?.let { AgentPrefs.maxSteps = it }
                        },
                        label = { Text("Max steps") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = searchEndpoint,
                    onValueChange = { searchEndpoint = it; AgentPrefs.searchEndpoint = it },
                    label = { Text("Web search endpoint (optional)") },
                    placeholder = { Text("https://your-search-api/search?q=") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            HorizontalDivider(color = SaifTheme.colors.cardBorder)
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(
                        onClick = {
                            if (running) return@OutlinedButton
                            log = ""
                            running = true
                            scope.launch {
                                val ws = SaifAgent.workspace(context)
                                SaifAgent.runTask(
                                    task = "Create a file named hello.txt containing 'SAIF AI agent ready', " +
                                        "then read it back and report its contents.",
                                    workspace = ws,
                                    approval = object : ApprovalGate {
                                        override suspend fun confirm(
                                            tool: String, summary: String, detail: String
                                        ) = true
                                    }
                                ).collect { event ->
                                    log += when (event) {
                                        is AgentRuntime.Event.Thinking -> "• ${event.text.take(200)}\n"
                                        is AgentRuntime.Event.Action -> "→ ${event.tool} ${event.arguments}\n"
                                        is AgentRuntime.Event.Observation ->
                                            "  ${if (event.ok) "" else "!"} ${event.output.take(400)}\n"
                                        is AgentRuntime.Event.Refused -> "  refused ${event.tool}: ${event.reason}\n"
                                        is AgentRuntime.Event.Asking -> "? ${event.tool}: ${event.summary}\n"
                                        is AgentRuntime.Event.Done -> "\n✔ ${event.answer}\n"
                                        is AgentRuntime.Event.Failed -> "\n✖ ${event.reason}\n"
                                    }
                                }
                                running = false
                            }
                        },
                        enabled = !running && enabled && SaifAgent.isConfigured()
                    ) { Text(if (running) "Running…" else "Run a test task") }
                }
                if (running) {
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { 0.5f },
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFF7C5CE0)
                    )
                }
                if (log.isNotBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 220.dp)
                            .background(
                                SaifTheme.colors.cardBorder.copy(alpha = 0.25f),
                                RoundedCornerShape(10.dp)
                            )
                            .padding(10.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Text(
                            log,
                            color = SaifTheme.colors.textPrimary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                if (!SaifAgent.isConfigured()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Add a provider API key to run the agent.",
                        color = SaifTheme.colors.textSecondary, fontSize = 11.5.sp
                    )
                }
            }
        }
    }
}
