/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.UriHandler
import androidx.compose.ui.unit.dp
import com.example.saifcore.AgentKind
import com.example.saifcore.ChatFeedCache
import com.example.saifcore.ChatFeedItem
import com.example.saifcore.ChatMessage
import com.example.saifcore.MarkdownBlock
import com.example.saifcore.ToolStatus
import com.example.saifcore.ToolType
import com.example.saifcore.ui.AgentWorkingSpinner
import com.example.saifcore.ui.AssistantFooter
import com.example.saifcore.ui.MarkdownBlockView
import com.example.saifcore.ui.MessageBubble
import com.example.saifcore.ui.ModelTypingIndicator
import com.example.saifcore.ui.ThinkingAccordion
import com.example.saifcore.ui.ToolCardView
import com.example.saifcore.ui.WaveDivider
import com.example.saifcore.ui.findPendingQuestion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val FeedAccent = Color(0xFF7C5CE0)

/**
 * The agent conversation feed shown on the home screen.
 *
 * Written from scratch against SAIF AI's own feed model. Three things decide its shape:
 *
 *  - **Rows, not messages.** Every message is parsed into keyed rows so a long reply does not
 *    recompose as a single unit while it streams.
 *  - **Auto-scroll only when the user is already at the bottom.** Scrolling someone away from what
 *    they are reading is worse than making them scroll once.
 *  - **File links are handled in-app.** A path the agent produced has to be opened through the app's
 *    own file provider, so the external browser never sees a `file://` it cannot resolve.
 */
@Composable
internal fun HomeAgentFeed(
    messages: List<ChatMessage>,
    modelId: String,
    generating: Boolean,
    listState: LazyListState,
    viewModel: ChatViewModel,
    onRetry: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val externalUris = LocalUriHandler.current

    /** Opens a path the agent produced, copying it somewhere shareable first when needed. */
    val openFile: (String) -> Unit = remember(context, scope) {
        { raw ->
            scope.launch {
                runCatching {
                    val path = android.net.Uri.decode(raw).removePrefix("file://").substringBefore("#")
                    val file = withContext(Dispatchers.IO) {
                        val source = com.example.compiler.LinuxApkBuildBridge
                            .resolveLinuxPathOnHost(context, path)
                            ?: java.io.File(path)
                        val name = source.name.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "output" }
                        val target = java.io.File(context.cacheDir, "agent-outputs")
                            .apply { mkdirs() }
                            .let { java.io.File(it, name) }
                        if (source.isFile && source.canRead()) {
                            source.copyTo(target, overwrite = true)
                        } else {
                            val encoded = com.example.saifcore.AgyHubClient()
                                .readFileAsBase64("file://$path").getOrThrow()
                            require(encoded.length <= 200_000_000) { "File is too large to open here." }
                            target.writeBytes(android.util.Base64.decode(encoded, android.util.Base64.DEFAULT))
                        }
                        target
                    }
                    if (file.extension.equals("apk", ignoreCase = true)) {
                        com.example.compiler.AppCompilerEngine.installApk(context, file)
                        return@launch
                    }
                    val uri = androidx.core.content.FileProvider.getUriForFile(
                        context, "${context.packageName}.fileprovider", file
                    )
                    val ext = file.extension.lowercase()
                    val type = android.webkit.MimeTypeMap.getSingleton()
                        .getMimeTypeFromExtension(ext) ?: "application/octet-stream"
                    val intent = android.content.Intent(android.content.Intent.ACTION_VIEW)
                        .setDataAndType(uri, type)
                        .addFlags(
                            android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                        )
                    context.startActivity(android.content.Intent.createChooser(intent, "Open ${file.name}"))
                }.onFailure { error ->
                    android.widget.Toast.makeText(
                        context, "Cannot open file: ${error.localizedMessage}", android.widget.Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    val safeUris = remember(externalUris, openFile) {
        object : UriHandler {
            override fun openUri(uri: String) {
                if (uri.startsWith("file://", ignoreCase = true) || uri.startsWith("/")) {
                    openFile(uri)
                } else {
                    runCatching { externalUris.openUri(uri) }.onFailure { error ->
                        android.widget.Toast.makeText(
                            context, "Cannot open link: ${error.localizedMessage}", android.widget.Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        }
    }

    val feed = remember(messages, modelId) { ChatFeedCache.buildFeedItems(messages, modelId) }
    val question = remember(messages) { findPendingQuestion(AgentKind.AGY, messages) }
    val approvals by viewModel.mainAgentApprovals.collectAsState()

    // Follow the conversation only while the user is already at the bottom of it.
    LaunchedEffect(feed.size, messages.lastOrNull(), generating) {
        val layout = listState.layoutInfo
        val nearBottom = layout.totalItemsCount == 0 ||
            (layout.visibleItemsInfo.lastOrNull()?.index ?: 0) >= layout.totalItemsCount - 3
        if (nearBottom && (feed.isNotEmpty() || generating)) {
            val count = listState.layoutInfo.totalItemsCount
            if (count > 0) listState.scrollToItem(count - 1)
        }
    }

    CompositionLocalProvider(LocalUriHandler provides safeUris) {
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(top = 12.dp, bottom = 16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(feed, key = { it.key }, contentType = { it.contentType }) { item ->
                FeedRow(
                    item = item,
                    modelId = modelId,
                    generating = generating,
                    onRetry = onRetry,
                    onApproveTool = { tool -> viewModel.approveMainTool(tool, item.messageId, null) },
                    onRejectTool = { tool ->
                        if (tool.toolType == ToolType.ASK_CHOICE) viewModel.cancelMainChoices(tool, item.messageId)
                        else viewModel.rejectMainTool(tool, item.messageId, null)
                    },
                    onTerminateTool = { tool -> viewModel.terminateMainTool(tool, item.messageId) }
                )
            }
            if (generating && approvals.isEmpty() && question == null) {
                item(key = "home_agent_working") { AgentWorkingSpinner(color = FeedAccent) }
            }
        }
    }
}

@Composable
private fun FeedRow(
    item: ChatFeedItem,
    modelId: String,
    generating: Boolean,
    onRetry: () -> Unit,
    onApproveTool: (com.example.saifcore.ToolCall) -> Unit,
    onRejectTool: (com.example.saifcore.ToolCall) -> Unit,
    onTerminateTool: (com.example.saifcore.ToolCall) -> Unit
) {
    when (item) {
        is ChatFeedItem.User -> MessageBubble(message = item.message)

        is ChatFeedItem.Summary -> MessageBubble(message = item.message, modelId = modelId)

        is ChatFeedItem.StreamingMessage -> MessageBubble(message = item.message, modelId = modelId)

        is ChatFeedItem.AssistantThinking -> ThinkingAccordion(
            thought = item.thoughtText,
            durationMs = item.durationMs,
            isStreaming = item.isStreaming,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        is ChatFeedItem.AssistantTyping -> if (!generating) ModelTypingIndicator(modelId = item.modelId)

        is ChatFeedItem.AssistantFooter -> AssistantFooter(
            message = item.message,
            modelId = item.message.modelId ?: modelId,
            onRetry = onRetry
        )

        is ChatFeedItem.Divider -> WaveDivider(label = item.label)

        is ChatFeedItem.AssistantBlock -> {
            val block = item.block
            Box(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp)) {
                when (block) {
                    is MarkdownBlock.ToolCard -> {
                        val pending = block.tool.status == ToolStatus.PENDING_APPROVAL
                        val running = block.tool.status == ToolStatus.RUNNING
                        ToolCardView(
                            tool = block.tool,
                            onApprove = if (pending) ({ onApproveTool(block.tool) }) else null,
                            onReject = if (pending) ({ onRejectTool(block.tool) }) else null,
                            onTerminate = if (running) ({ onTerminateTool(block.tool) }) else null
                        )
                    }
                    is MarkdownBlock.Text,
                    is MarkdownBlock.Heading,
                    is MarkdownBlock.ListBlock,
                    is MarkdownBlock.Quote,
                    is MarkdownBlock.Table -> SelectionContainer { MarkdownBlockView(block = block) }
                    else -> MarkdownBlockView(block = block)
                }
            }
        }
    }
}
