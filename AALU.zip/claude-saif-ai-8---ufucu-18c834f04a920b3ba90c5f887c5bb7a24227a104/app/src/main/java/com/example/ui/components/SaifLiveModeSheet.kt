/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.ui.components

import android.content.Context
import com.example.saiflive.LiveMode
import com.example.saiflive.LivePermissions
import com.example.saiflive.SaifLive

/**
 * Starts a voice-only live conversation.
 *
 * The wake-word listener owns the microphone on the home screen, so it is stopped first: two
 * readers of one microphone is the classic way for live conversation to start and hear nothing.
 * If the session cannot start for a reason the user can fix, the engine publishes why and we hand
 * the microphone straight back to the wake word so the home screen is not left deaf.
 *
 * Returns true only when the session actually started, which the callers use to decide whether to
 * show the conversation panel.
 */
fun startNormal(context: Context, isLightMode: Boolean, onDismiss: () -> Unit): Boolean {
    val canStart = LivePermissions.hasLiveConversationPermission(context) &&
        (SaifLive.currentApi().hasKey || SaifLive.hasHostLiveAgent())

    if (canStart) com.example.util.WakeWordAudioDetector.stop()

    val started = SaifLive.startLive(context, LiveMode.NORMAL, isLightMode)

    if (started) {
        SaifLiveSession.isHostPanelOpen = true
    } else if (canStart &&
        com.example.util.WakeWordManager.isWakeWordEnabledFlow.value &&
        com.example.util.WakeWordManager.isAppInForeground
    ) {
        com.example.util.WakeWordAudioDetector.start(context)
    }

    onDismiss()
    return started
}

/**
 * Tiny piece of shared state between the host UI and the live engine.
 *
 * The panel and the session are separate things that must agree: the panel is a screen inside the
 * app, the session is a foreground service that can outlive it. These two flags are the whole
 * handshake between them.
 */
object SaifLiveSession {

    /** True while SAIF AI's own full-screen conversation panel is showing. */
    @Volatile
    var isHostPanelOpen: Boolean = false

    /** A mode the user asked for that the engine has not received a capture grant for yet. */
    @Volatile
    var pendingScreenShare: Boolean = false
}
