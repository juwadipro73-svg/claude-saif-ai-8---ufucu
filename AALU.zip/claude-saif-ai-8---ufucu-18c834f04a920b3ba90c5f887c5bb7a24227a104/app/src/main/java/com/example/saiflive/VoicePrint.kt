/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saiflive

import android.content.Context
import android.content.SharedPreferences
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * A voice lock: does this recording sound like the person who enrolled?
 *
 * The method is the classic one, and simple enough to describe in a paragraph. Speech is cut into
 * overlapping 25 ms windows; each window is turned into a vector of how much energy sits in each of
 * twenty-six mel-spaced frequency bands; those vectors are averaged over the voiced part of the
 * recording to give one fixed-length voiceprint; two voiceprints are compared by cosine similarity,
 * which measures the *shape* of the spectrum rather than how loud the speaker was.
 *
 * What this is for, and what it is not: it is a convenience filter, so a conversation started by
 * someone else in the room does not act as the owner. It is not a security boundary. Anyone who
 * needs a real one should use the platform's own biometric prompt, which is backed by hardware this
 * class has no access to. The limits are stated here rather than buried, because a lock that
 * overstates itself is worse than no lock.
 *
 * Enrolment is not currently surfaced in the UI, so the lock stays out of the way until a
 * voiceprint is stored.
 */
object VoicePrint {

    // --- Analysis parameters ------------------------------------------------------------------

    private const val SAMPLE_RATE = 16000
    private const val FRAME_MS = 25
    private const val HOP_MS = 10
    private const val FRAME_SIZE = SAMPLE_RATE * FRAME_MS / 1000   // 400 samples
    private const val HOP_SIZE = SAMPLE_RATE * HOP_MS / 1000       // 160 samples
    private const val FFT_SIZE = 512
    private const val BINS = FFT_SIZE / 2 + 1
    private const val MEL_BANDS = 26
    private const val MIN_HZ = 80.0
    private const val MAX_HZ = 7600.0

    /** Windows quieter than this are mostly room noise and would only smear the average. */
    private const val VOICED_RMS = 250.0

    /**
     * Similarity at or above which a speaker is accepted.
     *
     * Deliberately lenient. A false rejection reads as "SAIF AI ignored me", while a false
     * acceptance only matters in situations this lock was never meant to defend against.
     */
    private const val ACCEPT_AT = 0.80f

    private const val PREFS = "saif_voice_lock"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_PRINT = "print"
    private const val KEY_SAMPLES = "samples"

    // --- Public surface -----------------------------------------------------------------------

    fun isEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    fun hasProfile(context: Context): Boolean =
        prefs(context).getString(KEY_PRINT, null).orEmpty().isNotBlank()

    /** True when the lock should actually be applied to a turn. */
    fun isArmed(context: Context): Boolean = isEnabled(context) && hasProfile(context)

    /**
     * Compares a recording against the enrolled voiceprint.
     *
     * [pcm] is mono 16 kHz little-endian signed 16-bit audio, which is what the live pipeline
     * produces. A recording too short or too quiet to analyse reports
     * [SpeakerVerdict.hasExtractedVector] false, which callers must treat as "could not check"
     * rather than "did not match".
     */
    fun verify(context: Context, pcm: ByteArray): SpeakerVerdict {
        val stored = loadPrint(context)
        if (stored == null) {
            // Nothing enrolled means no restriction, not a rejection: staying silent because nobody
            // ever enrolled would look exactly like a broken microphone.
            return SpeakerVerdict(isMatch = true, hasExtractedVector = false, score = 0f)
        }
        val candidate = extract(pcm)
            ?: return SpeakerVerdict(isMatch = false, hasExtractedVector = false, score = 0f)
        val score = cosine(stored, candidate)
        return SpeakerVerdict(isMatch = score >= ACCEPT_AT, hasExtractedVector = true, score = score)
    }

    /**
     * Adds a recording to the enrolment.
     *
     * The stored voiceprint is a running mean, so each sample nudges it towards the newest
     * recording. That lets a bad enrolment be corrected by speaking again instead of starting over,
     * at the cost of older samples slowly losing influence - the trade wanted here.
     */
    fun enrol(context: Context, pcm: ByteArray): Boolean {
        val sample = extract(pcm) ?: return false
        val preferences = prefs(context)
        val count = preferences.getInt(KEY_SAMPLES, 0)
        val current = loadPrint(context)
        val merged = if (current == null || count <= 0) {
            sample
        } else {
            FloatArray(MEL_BANDS) { i -> (current[i] * count + sample[i]) / (count + 1) }
        }
        preferences.edit()
            .putString(KEY_PRINT, merged.joinToString(","))
            .putInt(KEY_SAMPLES, (count + 1).coerceAtMost(32))
            .apply()
        return true
    }

    /** Discards the enrolled voiceprint. */
    fun clear(context: Context) {
        prefs(context).edit().remove(KEY_PRINT).remove(KEY_SAMPLES).apply()
    }

    /** Loudness of a recording, so callers can reject silence before spending work on it. */
    fun rms(pcm: ByteArray): Double {
        val samples = decodePcm16(pcm)
        if (samples.isEmpty()) return 0.0
        var energy = 0.0
        for (value in samples) energy += value * value
        return sqrt(energy / samples.size)
    }

    // --- Feature extraction -------------------------------------------------------------------

    /** Average mel-band energies over the voiced windows of a recording, or null if unusable. */
    private fun extract(pcm: ByteArray): FloatArray? {
        val samples = decodePcm16(pcm)
        if (samples.size < FRAME_SIZE * 2) return null

        val window = hannWindow()
        val filters = filterbank()
        val re = DoubleArray(FFT_SIZE)
        val im = DoubleArray(FFT_SIZE)
        val power = DoubleArray(BINS)

        val accumulator = DoubleArray(MEL_BANDS)
        var voiced = 0

        var offset = 0
        while (offset + FRAME_SIZE <= samples.size) {
            var energy = 0.0
            for (i in 0 until FRAME_SIZE) {
                val value = samples[offset + i]
                energy += value * value
            }
            if (sqrt(energy / FRAME_SIZE) >= VOICED_RMS) {
                for (i in 0 until FFT_SIZE) {
                    re[i] = if (i < FRAME_SIZE) samples[offset + i] * window[i] else 0.0
                    im[i] = 0.0
                }
                fft(re, im)
                for (i in 0 until BINS) {
                    power[i] = re[i] * re[i] + im[i] * im[i]
                }
                for (band in 0 until MEL_BANDS) {
                    var sum = 0.0
                    val weights = filters[band]
                    for (bin in weights.indices) {
                        val weight = weights[bin]
                        if (weight != 0.0) sum += power[bin] * weight
                    }
                    // Log compression: hearing is roughly logarithmic in energy, and it stops one
                    // loud band from dominating the cosine comparison.
                    accumulator[band] += ln(1.0 + sum)
                }
                voiced++
            }
            offset += HOP_SIZE
        }

        if (voiced == 0) return null

        val print = FloatArray(MEL_BANDS) { (accumulator[it] / voiced).toFloat() }
        // Mean-normalise so overall loudness and microphone gain drop out of the comparison.
        var mean = 0f
        for (value in print) mean += value
        mean /= MEL_BANDS
        for (i in print.indices) print[i] -= mean
        return print
    }

    private fun cosine(a: FloatArray, b: FloatArray): Float {
        var dot = 0.0
        var normA = 0.0
        var normB = 0.0
        for (i in a.indices) {
            dot += a[i] * b[i]
            normA += a[i] * a[i]
            normB += b[i] * b[i]
        }
        val denominator = sqrt(normA) * sqrt(normB)
        if (denominator < 1e-9) return 0f
        return (dot / denominator).toFloat().coerceIn(-1f, 1f)
    }

    /**
     * Triangular mel filterbank, one row of weights per band.
     *
     * Built once and reused: it depends only on the constants above, and rebuilding it for every
     * window would double the cost of enrolment for no benefit.
     */
    @Volatile
    private var cachedFilterbank: Array<DoubleArray>? = null

    private fun filterbank(): Array<DoubleArray> {
        cachedFilterbank?.let { return it }
        val built = buildFilterbank()
        cachedFilterbank = built
        return built
    }

    private fun buildFilterbank(): Array<DoubleArray> {
        val minMel = hzToMel(MIN_HZ)
        val maxMel = hzToMel(MAX_HZ)
        // Band edges, evenly spaced on the mel scale, converted back to FFT bins.
        val edges = IntArray(MEL_BANDS + 2) { i ->
            val hz = melToHz(minMel + (maxMel - minMel) * i / (MEL_BANDS + 1))
            (hz * FFT_SIZE / SAMPLE_RATE).toInt().coerceIn(0, BINS - 1)
        }
        return Array(MEL_BANDS) { band ->
            val weights = DoubleArray(BINS)
            val left = edges[band]
            val centre = max(edges[band + 1], left + 1)
            val right = max(edges[band + 2], centre + 1)
            for (bin in left..right) {
                weights[bin] = when {
                    bin < left || bin > right -> 0.0
                    bin <= centre -> (bin - left).toDouble() / (centre - left)
                    else -> (right - bin).toDouble() / (right - centre)
                }
            }
            weights
        }
    }

    private fun hzToMel(hz: Double): Double = 2595.0 * log10(1.0 + hz / 700.0)

    private fun melToHz(mel: Double): Double = 700.0 * (10.0.pow(mel / 2595.0) - 1.0)

    private fun hannWindow(): DoubleArray =
        DoubleArray(FRAME_SIZE) { i -> 0.5 - 0.5 * cos(2.0 * Math.PI * i / (FRAME_SIZE - 1)) }

    /**
     * In-place iterative radix-2 FFT.
     *
     * Iterative rather than recursive, and reusing the caller's arrays, because this runs once per
     * voiced window - around a hundred times per second of speech - inside a path that must not
     * stall the capture thread.
     */
    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size

        // Bit-reversal permutation.
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j or bit
            if (i < j) {
                var swap = re[i]; re[i] = re[j]; re[j] = swap
                swap = im[i]; im[i] = im[j]; im[j] = swap
            }
        }

        var length = 2
        while (length <= n) {
            val angle = -2.0 * Math.PI / length
            val stepRe = cos(angle)
            val stepIm = sin(angle)
            var i = 0
            while (i < n) {
                var twiddleRe = 1.0
                var twiddleIm = 0.0
                for (k in 0 until length / 2) {
                    val aRe = re[i + k]
                    val aIm = im[i + k]
                    val bRe = re[i + k + length / 2]
                    val bIm = im[i + k + length / 2]
                    val productRe = bRe * twiddleRe - bIm * twiddleIm
                    val productIm = bRe * twiddleIm + bIm * twiddleRe
                    re[i + k] = aRe + productRe
                    im[i + k] = aIm + productIm
                    re[i + k + length / 2] = aRe - productRe
                    im[i + k + length / 2] = aIm - productIm
                    val nextRe = twiddleRe * stepRe - twiddleIm * stepIm
                    twiddleIm = twiddleRe * stepIm + twiddleIm * stepRe
                    twiddleRe = nextRe
                }
                i += length
            }
            length = length shl 1
        }
    }

    private fun sin(value: Double): Double = kotlin.math.sin(value)

    // --- Storage ------------------------------------------------------------------------------

    private fun decodePcm16(bytes: ByteArray): DoubleArray {
        val count = bytes.size / 2
        val out = DoubleArray(count)
        for (i in 0 until count) {
            val low = bytes[i * 2].toInt() and 0xFF
            val high = bytes[i * 2 + 1].toInt()
            out[i] = (high shl 8 or low).toShort().toDouble()
        }
        return out
    }

    private fun loadPrint(context: Context): FloatArray? {
        val raw = prefs(context).getString(KEY_PRINT, null) ?: return null
        val parts = raw.split(",")
        if (parts.size != MEL_BANDS) return null
        val out = FloatArray(MEL_BANDS)
        for (i in parts.indices) {
            out[i] = parts[i].trim().toFloatOrNull() ?: return null
        }
        return out
    }

    private fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
