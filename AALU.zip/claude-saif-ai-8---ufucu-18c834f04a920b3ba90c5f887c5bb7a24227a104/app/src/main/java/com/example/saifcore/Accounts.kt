/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. The app as distributed also contains third-party
 * GNU GPL v3 material - see LICENSE and THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore

import android.content.Context
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * SAIF AI's own hub client.
 *
 * Written from scratch, and speaking plain JSON over HTTP to the local SAIF AI bridge instead of a
 * generated remote-procedure stack. That is a deliberate simplification: the surface the app needs
 * (who is signed in, read a file, refresh the tool list) is a handful of calls, and a hand-written
 * JSON client keeps them readable, testable, and free of a code-generation step at build time.
 */
class AgyHubClient {

    /** How far the sign-in check has got. */
    enum class AgyAuthStatus { CHECKING, AUTHENTICATED, UNAUTHENTICATED, OFFLINE }

    /** Everything the app knows about the signed-in account. */
    data class AgyAuthInfo(
        val status: AgyAuthStatus = AgyAuthStatus.CHECKING,
        val isLoggedIn: Boolean = false,
        val fullName: String = "",
        val displayName: String = fullName,
        val email: String = "",
        val username: String = "",
        val homeDir: String = "",
        val userTier: String = "",
        val userTierId: String = "",
        val userTierDescription: String = "",
        val planName: String = "",
        val teamsTier: String = "",
        val availablePromptCredits: Long? = null,
        val availableFlowCredits: Long? = null,
        val monthlyPromptCredits: Long? = null,
        val monthlyFlowCredits: Long? = null,
        val upgradeSubscriptionUri: String = "",
        val upgradeSubscriptionText: String = "",
        val profilePictureUrl: String? = null,
        val grantedScopes: List<String> = emptyList(),
        val isOffline: Boolean = false
    )

    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    private val json = "application/json; charset=utf-8".toMediaType()

    /** Reads the current account state from the bridge. */
    suspend fun fetchAuthInfo(hubUrl: String = AuthPreferences.currentHubUrl): Result<AgyAuthInfo> =
        withContext(Dispatchers.IO) {
            runCatching {
                val body = get("$hubUrl/auth/status") ?: return@withContext Result.success(
                    AgyAuthInfo(status = AgyAuthStatus.OFFLINE, isOffline = true)
                )
                val obj = JSONObject(body)
                val loggedIn = obj.optBoolean("isLoggedIn", false)
                AgyAuthInfo(
                    status = if (loggedIn) AgyAuthStatus.AUTHENTICATED else AgyAuthStatus.UNAUTHENTICATED,
                    isLoggedIn = loggedIn,
                    fullName = obj.optString("fullName"),
                    email = obj.optString("email"),
                    username = obj.optString("username"),
                    homeDir = obj.optString("homeDir"),
                    userTier = obj.optString("userTier"),
                    userTierId = obj.optString("userTierId"),
                    userTierDescription = obj.optString("userTierDescription"),
                    planName = obj.optString("planName"),
                    teamsTier = obj.optString("teamsTier"),
                    availablePromptCredits = obj.optLongOrNull("availablePromptCredits"),
                    availableFlowCredits = obj.optLongOrNull("availableFlowCredits"),
                    monthlyPromptCredits = obj.optLongOrNull("monthlyPromptCredits"),
                    monthlyFlowCredits = obj.optLongOrNull("monthlyFlowCredits"),
                    upgradeSubscriptionUri = obj.optString("upgradeSubscriptionUri"),
                    upgradeSubscriptionText = obj.optString("upgradeSubscriptionText"),
                    profilePictureUrl = obj.optStringOrNull("profilePictureUrl"),
                    isOffline = false
                )
            }
        }

    /**
     * Reads a file as base64.
     *
     * `file://` paths are read straight from disk — the common case, and it must work with the
     * bridge down. Anything else is asked of the bridge, which can reach places the app cannot.
     */
    suspend fun readFileAsBase64(uri: String, hubUrl: String = AuthPreferences.currentHubUrl): Result<String> =
        withContext(Dispatchers.IO) {
            if (uri.startsWith("file://")) {
                val path = uri.removePrefix("file://")
                runCatching {
                    val bytes = File(path).readBytes()
                    Base64.encodeToString(bytes, Base64.NO_WRAP)
                }
            } else {
                runCatching {
                    val encoded = java.net.URLEncoder.encode(uri, "UTF-8")
                    val body = get("$hubUrl/files/base64?uri=$encoded")
                        ?: error("the local server is not reachable")
                    JSONObject(body).getString("base64")
                }
            }
        }

    /** Asks the bridge to re-read its tool server list. */
    suspend fun refreshMcpServers(hubUrl: String = AuthPreferences.currentHubUrl): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                post("$hubUrl/mcp/refresh", "{}")
                Unit
            }
        }

    /** Signs out of the agent session. */
    suspend fun logout(hubUrl: String = AuthPreferences.currentHubUrl): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val request = Request.Builder()
                    .url("$hubUrl/auth/logout")
                    .post("{}".toRequestBody(json))
                    .build()
                http.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) error("the local server returned HTTP ${response.code}")
                }
                Unit
            }
        }

    /** Cancels the run in progress, if any. */
    suspend fun cancelCascade(hubUrl: String = AuthPreferences.currentHubUrl): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                post("$hubUrl/cascade/cancel", "{}")
                Unit
            }
        }

    private fun get(url: String): String? {
        val request = Request.Builder().url(url).get().build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            return response.body?.string()
        }
    }

    private fun post(url: String, body: String): String? {
        val request = Request.Builder().url(url).post(body.toRequestBody(json)).build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            return response.body?.string()
        }
    }

    private fun JSONObject.optLongOrNull(key: String): Long? =
        if (has(key) && !isNull(key)) optLong(key) else null

    private fun JSONObject.optStringOrNull(key: String): String? =
        optString(key).takeIf { it.isNotBlank() }
}

/**
 * Remembers which SAIF AI account an agent session belongs to.
 *
 * The agent backend keeps its own sign-in, so the app has to remember who it was signed in *for*.
 * Without this, signing in as a second account would leave the first account's agent session
 * visible to it — which is a privacy problem, not a convenience one.
 */
object AntigravityAppBinding {

    private const val PREFS = "saif_agent_binding"
    private const val KEY_OWNER = "owner_uid"
    private const val KEY_IDENTITY = "hub_identity"

    private var prefs: android.content.SharedPreferences? = null

    @Volatile
    var ownerUid: String? = null
        private set

    @Volatile
    var hubIdentity: String? = null
        private set

    fun init(context: Context) {
        val p = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs = p
        ownerUid = p.getString(KEY_OWNER, null)
        hubIdentity = p.getString(KEY_IDENTITY, null)
    }

    fun record(owner: String, hub: AgyHubClient.AgyAuthInfo) {
        ownerUid = owner
        hubIdentity = hub.email.ifBlank { hub.username }.trim().lowercase()
        prefs?.edit()
            ?.putString(KEY_OWNER, owner)
            ?.putString(KEY_IDENTITY, hubIdentity)
            ?.apply()
    }

    fun clear() {
        ownerUid = null
        hubIdentity = null
        prefs?.edit()?.remove(KEY_OWNER)?.remove(KEY_IDENTITY)?.apply()
    }
}

/**
 * Decides whether the signed-in SAIF AI account may use the connected agent session.
 *
 * Returns `null` when everything matches, or a message the UI can show as-is. The check exists
 * because the two sign-ins are independent: the app's own account and the agent backend's account
 * can drift apart, and using one account's agent session from another would leak that session.
 */
object GoogleAccountBinding {

    fun denialReason(
        appUser: com.example.data.local.AuthUser?,
        hub: AgyHubClient.AgyAuthInfo,
        boundOwnerUid: String? = AntigravityAppBinding.ownerUid,
        boundHubIdentity: String? = AntigravityAppBinding.hubIdentity
    ): String? {
        if (appUser == null || appUser.uid.isBlank() || !appUser.isActive || appUser.isBanned) {
            return "Sign in to SAIF AI first."
        }
        if (!hub.isLoggedIn || hub.status != AgyHubClient.AgyAuthStatus.AUTHENTICATED || hub.isOffline) {
            return "SAIF AI's agent is not connected. Open its sign-in screen inside SAIF AI."
        }
        if (boundOwnerUid != null && boundOwnerUid != appUser.uid) {
            return "This agent session belongs to another app account. Sign in again inside SAIF AI."
        }
        val currentHub = hub.email.ifBlank { hub.username }.trim().lowercase()
        if (!boundHubIdentity.isNullOrBlank() && boundHubIdentity != currentHub) {
            return "The agent account changed. Reconnect it inside SAIF AI."
        }
        return null
    }
}
