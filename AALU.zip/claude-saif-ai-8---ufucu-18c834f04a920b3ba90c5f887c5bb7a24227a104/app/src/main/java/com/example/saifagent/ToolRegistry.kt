/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. The app as distributed also contains third-party
 * GNU GPL v3 material - see LICENSE and THIRD_PARTY_NOTICES.md.
 */

package com.example.saifagent

import com.example.saifagent.tools.AnswerTool
import com.example.saifagent.tools.DeleteFileTool
import com.example.saifagent.tools.HttpGetTool
import com.example.saifagent.tools.ListDirTool
import com.example.saifagent.tools.MakeDirTool
import com.example.saifagent.tools.ReadFileTool
import com.example.saifagent.tools.RunCommandTool
import com.example.saifagent.tools.SearchTool
import com.example.saifagent.tools.ShellRunner
import com.example.saifagent.tools.UnavailableShell
import com.example.saifagent.tools.WebSearchTool
import com.example.saifagent.tools.WriteFileTool

/**
 * The tools one agent run can use.
 *
 * The registry is built per run rather than held as a global, because the shell and the search
 * endpoint can change between runs (the Linux environment finishes installing, the user adds a
 * search URL), and a stale tool would quietly keep failing.
 */
class ToolRegistry(tools: List<AgentTool> = emptyList()) {

    private val byName = LinkedHashMap<String, AgentTool>()

    init {
        tools.forEach { register(it) }
    }

    fun register(tool: AgentTool) {
        require(tool.name.matches(Regex("[a-z0-9_]{2,40}"))) {
            "tool names must be lowercase letters, digits or underscores: '${tool.name}'"
        }
        byName[tool.name] = tool
    }

    fun unregister(name: String) {
        byName.remove(name)
    }

    fun find(name: String): AgentTool? = byName[name]
    fun all(): List<AgentTool> = byName.values.toList()
    fun names(): List<String> = byName.keys.toList()

    companion object {

        /**
         * The default kit: files, search, shell if one is wired in, web if an endpoint is set.
         *
         * Everything here is a capability SAIF AI implements itself — no plugin, no MCP server and no
         * third-party agent is required for the runtime to be useful.
         */
        fun defaults(
            shell: ShellRunner = UnavailableShell,
            searchEndpoint: () -> String = { "" },
            commandPolicy: (String) -> Boolean = { true }
        ): ToolRegistry = ToolRegistry(
            listOf(
                ReadFileTool(),
                WriteFileTool(),
                ListDirTool(),
                SearchTool(),
                MakeDirTool(),
                DeleteFileTool(),
                RunCommandTool(shell, commandPolicy),
                HttpGetTool(),
                WebSearchTool(searchEndpoint),
                AnswerTool()
            )
        )
    }
}
