/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */
package com.example

import android.app.Application
import com.example.data.local.ProviderSettingsManager
import com.example.saiflive.LiveProviderConfig
import com.example.saiflive.SaifLive
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class SaifApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        ProviderSettingsManager.init(this)

        // Warm the on-device speech model at startup so the purple-mic live conversation works with
        // any provider key. Cloud transcription only exists for a few providers; for the rest
        // (OpenRouter, Anthropic, chat-only keys, custom endpoints) recognition happens on the phone.
        try {
            com.example.saiflive.OfflineSpeechEngine.init(
                this, CoroutineScope(SupervisorJob() + Dispatchers.IO)
            )
        } catch (_: Throwable) {}

        // Memory is app-wide: chat, live conversation, video director, builder and agent all learn
        // into it and recall from it, so what SAIF AI remembers does not depend on where it learned it.
        com.example.util.SaifMemoryCore.init(this)
        com.example.utils.TTSManager.init(this)

        // SAIF ADVANCE EDITING ENGINE needs these at process start (the workspace has its own Application class that no
        // longer runs now that SaifApplication is the app class). The app self-updater and the original project's
        // analytics are deliberately NOT started here.
        try { com.example.saifcore.AdbConnectManager.init(this) } catch (_: Throwable) {}
        try { com.example.saifcore.PluginUpdateCheckWorker.schedule(this) } catch (_: Throwable) {}

        // The live engine reads its provider from the Settings panel: whatever the user saved there
        // (provider, key, model) is what a live conversation uses.
        SaifLive.link(
            apiResolver = {
                val state = ProviderSettingsManager.loadState()
                val key = state.apiKeys.getOrNull(state.currentKeyIndex)?.takeIf { it.isNotBlank() }
                    ?: state.apiKeys.firstOrNull { it.isNotBlank() }
                    ?: ""
                LiveProviderConfig(
                    provider = state.providerName,
                    apiKey = key,
                    model = state.activeModel
                )
            },
            openHostSettings = { HostNavigation.openSettingsRequest.value = true }
        )

        // A live conversation speaks with the voice chosen in Settings, not one of its own.
        SaifLive.hostLiveTurnFactory = { context, prompt, listener ->
            com.example.live.LiveTurnLoop(context, prompt, listener)
        }
        SaifLive.hostCanRespondWithoutKey = { com.example.live.LiveCodingBridge.available() }
        SaifLive.hostVoiceResolver = { com.example.utils.SaifVoice.liveVoiceName(this) }
        SaifLive.hostMemoryResolver = { feature -> com.example.util.SaifMemoryCore.promptBlock(feature) }
        SaifLive.hostAutoLanguageResolver = { com.example.util.SaifMemoryCore.autoLanguage.value }
    }
}
