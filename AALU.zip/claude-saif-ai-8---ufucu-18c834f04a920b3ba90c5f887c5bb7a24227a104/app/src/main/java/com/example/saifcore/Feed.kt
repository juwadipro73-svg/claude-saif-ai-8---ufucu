/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore

import java.util.concurrent.ConcurrentHashMap

/**
 * A chat message broken into the rows a lazy feed can render.
 *
 * Splitting is what keeps a long reply cheap to scroll: each block is keyed and typed, so Compose
 * recomposes only the block that actually changed while a reply streams in, instead of the whole
 * message on every token.
 */
sealed class ChatFeedItem(val key: String, val contentType: String, open val messageId: String = "") {

    /** A stored conversation summary shown at the top of a resumed chat. */
    data class Summary(val message: ChatMessage) : ChatFeedItem("summary_${message.id}", "SUMMARY", message.id)

    data class User(val message: ChatMessage) : ChatFeedItem("user_${message.id}", "USER", message.id)

    /** The model's reasoning passage, shown collapsed until the user opens it. */
    data class AssistantThinking(
        override val messageId: String,
        val thoughtText: String,
        val durationMs: Long?,
        val isStreaming: Boolean
    ) : ChatFeedItem("thought_$messageId", "THOUGHT")

    data class AssistantBlock(
        override val messageId: String,
        val blockIndex: Int,
        val block: MarkdownBlock,
        val isFirst: Boolean,
        val isLast: Boolean
    ) : ChatFeedItem("block_${messageId}_$blockIndex", block.javaClass.simpleName)

    /** The animated indicator shown while a reply is in flight. */
    data class AssistantTyping(override val messageId: String, val modelId: String) :
        ChatFeedItem("active_assistant_typing", "TYPING", messageId)

    /** Copy / retry / token-count row under a finished reply. */
    data class AssistantFooter(val message: ChatMessage) : ChatFeedItem("footer_${message.id}", "FOOTER", message.id)

    /** A reply that is still arriving, rendered as one growing block. */
    data class StreamingMessage(val message: ChatMessage) : ChatFeedItem("streaming_${message.id}", "STREAMING", message.id)

    /** A labelled divider: a new day, or a switch to a different model. */
    data class Divider(val id: String, val label: String) : ChatFeedItem("divider_$id", "DIVIDER")
}

/**
 * Caches the parsed form of a message.
 *
 * The key folds in every field the parse depends on, so a message that is still streaming simply
 * misses the cache and re-parses — and a message that is not changing stops being parsed at all.
 */
object ChatFeedCache {

    private const val MAX_ENTRIES = 400

    val cache = ConcurrentHashMap<String, List<ChatFeedItem>>()

    fun getOrParse(msg: ChatMessage): List<ChatFeedItem> {
        val cacheKey = buildString {
            append(msg.id).append('|')
            append(msg.content.hashCode()).append('|')
            append(msg.toolCalls.hashCode()).append('|')
            append(msg.thoughtText?.hashCode() ?: 0).append('|')
            append(msg.tokenUsage?.hashCode() ?: 0).append('|')
            append(msg.isStreaming)
        }
        cache[cacheKey]?.let { return it }

        val items = parse(msg)
        if (cache.size > MAX_ENTRIES) cache.clear()
        cache[cacheKey] = items
        return items
    }

    fun clear() = cache.clear()

    /**
     * Turns a whole conversation into one flat list of feed rows.
     *
     * Runs from the oldest message to the newest so the feed reads top-to-bottom, and skips empty
     * parses — a message with nothing to show should not produce a blank row.
     */
    fun buildFeedItems(messages: List<ChatMessage>, modelId: String = ""): List<ChatFeedItem> {
        val items = mutableListOf<ChatFeedItem>()
        for (message in messages) {
            val parsed = getOrParse(message)
            if (parsed.isEmpty()) continue
            // A finished reply that only has a footer adds nothing on its own.
            if (parsed.size == 1 && parsed.first() is ChatFeedItem.AssistantFooter && message.content.isBlank()) continue
            items.addAll(parsed)
        }
        return items
    }

    /** Turns one message into feed rows. Exposed so callers can bypass the cache when needed. */
    fun parse(msg: ChatMessage): List<ChatFeedItem> {
        val items = mutableListOf<ChatFeedItem>()

        when (msg.role) {
            MessageRole.SUMMARY -> {
                items.add(ChatFeedItem.Summary(msg))
                return items
            }

            MessageRole.USER -> {
                items.add(ChatFeedItem.User(msg))
                return items
            }

            MessageRole.ASSISTANT -> Unit
            MessageRole.TOOL, MessageRole.SYSTEM -> {
                items.add(ChatFeedItem.AssistantFooter(msg))
                return items
            }
        }

        // Assistant messages: thought first, then content blocks, then tools, then the footer.
        val (thought, body) = MarkdownParser.splitThought(msg.content)
        val thoughtText = msg.thoughtText ?: thought

        if (!thoughtText.isNullOrBlank()) {
            items.add(
                ChatFeedItem.AssistantThinking(
                    messageId = msg.id,
                    thoughtText = thoughtText,
                    durationMs = msg.thoughtDurationMs,
                    isStreaming = msg.isStreaming
                )
            )
        }

        val blocks = MarkdownParser.parse(body, emptyList())
        blocks.forEachIndexed { i, block ->
            items.add(
                ChatFeedItem.AssistantBlock(
                    messageId = msg.id,
                    blockIndex = i,
                    block = block,
                    isFirst = i == 0,
                    isLast = i == blocks.lastIndex
                )
            )
        }

        msg.toolCalls.forEach { tool ->
            items.add(
                ChatFeedItem.AssistantBlock(
                    messageId = msg.id,
                    blockIndex = items.size,
                    block = MarkdownBlock.ToolCard(tool),
                    isFirst = false,
                    isLast = false
                )
            )
        }

        if (msg.isStreaming && body.isEmpty() && msg.toolCalls.isEmpty()) {
            items.add(ChatFeedItem.AssistantTyping(msg.id, msg.modelId.orEmpty()))
        }

        if (!msg.isStreaming) {
            items.add(ChatFeedItem.AssistantFooter(msg))
        }

        return items
    }
}
