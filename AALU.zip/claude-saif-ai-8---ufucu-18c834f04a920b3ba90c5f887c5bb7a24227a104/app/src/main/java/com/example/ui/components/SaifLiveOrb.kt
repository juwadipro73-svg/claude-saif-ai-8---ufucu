/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ScreenShare
import androidx.compose.material.icons.automirrored.filled.StopScreenShare
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.center
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.saiflive.LiveConversationState
import com.example.saiflive.LiveMode
import com.example.saiflive.SaifLive
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * The SAIF AI LIVE orb.
 *
 * It is drawn straight onto a Compose canvas rather than hosted in a web view: an animated sphere
 * is a few circles and a sine wave, and paying for a browser engine, a JavaScript bridge and a
 * bundled scene file to get there costs memory on every live session and slows the first frame.
 *
 * The look follows the state machine. Violet and still while idle, violet and breathing while
 * listening, deep purple and slow while thinking, green and reactive while speaking - and the
 * microphone level drives the amplitude, so the orb visibly responds to the person talking.
 */
@Composable
fun SaifLiveOrb(
    modifier: Modifier = Modifier,
    isLightMode: Boolean = false,
    compact: Boolean = false,
    onTap: () -> Unit = {},
    onLongPress: () -> Unit = {}
) {
    val state by SaifLive.orbState.collectAsState()
    val level by SaifLive.audioLevel.collectAsState()

    // One clock drives every blob. A single transition rather than one per blob keeps the
    // animation on one frame callback instead of eight.
    val phase by rememberInfiniteTransition(label = "orb").animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(durationMillis = 9000, easing = LinearEasing), RepeatMode.Restart),
        label = "orbPhase"
    )

    // The level is smoothed: raw microphone amplitude jumps every frame, and an orb that jitters
    // looks broken rather than alive.
    val smoothed = remember { androidx.compose.animation.core.Animatable(0f) }
    androidx.compose.runtime.LaunchedEffect(level) {
        smoothed.animateTo(level.coerceIn(0f, 1f), tween(durationMillis = 90))
    }

    val palette = orbPalette(state, isLightMode)

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawOrb(
                phase = phase,
                level = smoothed.value,
                palette = palette,
                state = state
            )
        }
    }

    if (!compact) {
        Box(Modifier.fillMaxSize().statusBarsPadding(), contentAlignment = Alignment.TopCenter) {
            StatusPill(state)
        }
    }
}

/** The four colour sets the orb moves between, plus the background wash behind it. */
private class OrbPalette(
    val core: Color,
    val edge: Color,
    val glow: Color,
    val accent: Color
)

/**
 * Colours per conversation state.
 *
 * [isLightMode] only lifts the halo: the orb itself keeps its own palette either way, because a
 * light-mode orb on a light panel loses the depth that makes the state readable at a glance.
 */
private fun orbPalette(state: LiveConversationState, isLightMode: Boolean): OrbPalette {
    val base = when (state) {
        LiveConversationState.IDLE -> OrbPalette(
            core = Color(0xFF6B45C9),
            edge = Color(0xFF3F2A85),
            glow = Color(0x332F1F63),
            accent = Color(0x26FFFFFF)
        )
        LiveConversationState.LISTENING -> OrbPalette(
            core = Color(0xFFB79DF5),
            edge = Color(0xFF7C5CE0),
            glow = Color(0x555B39B8),
            accent = Color(0x40FFFFFF)
        )
        LiveConversationState.THINKING -> OrbPalette(
            core = Color(0xFF8B6BE8),
            edge = Color(0xFF5B39B8),
            glow = Color(0x443F2A85),
            accent = Color(0x33FFFFFF)
        )
        LiveConversationState.SPEAKING -> OrbPalette(
            core = Color(0xFF6EE7A8),
            edge = Color(0xFF22C55E),
            glow = Color(0x4412A150),
            accent = Color(0x40FFFFFF)
        )
    }
    return if (isLightMode) {
        OrbPalette(core = base.core, edge = base.edge, glow = base.glow.copy(alpha = 0.22f), accent = base.accent)
    } else {
        base
    }
}

private fun DrawScope.drawOrb(
    phase: Float,
    level: Float,
    palette: OrbPalette,
    state: LiveConversationState
) {
    val centre = size.center
    val baseRadius = size.minDimension * 0.30f

    // Outer glow: a soft halo that swells with the voice.
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(palette.glow, Color.Transparent),
            center = centre,
            radius = baseRadius * (2.4f + level * 0.8f)
        ),
        radius = baseRadius * (2.4f + level * 0.8f),
        center = centre
    )

    // Liquid body: seven circles orbiting the centre, each breathing on its own offset. Drawing
    // overlapping circles and letting them union is what gives the surface its wobble; a single
    // path would need the same maths but an extra allocation per frame.
    val blobs = 7
    for (index in 0 until blobs) {
        val angle = phase + (2 * PI.toFloat() * index / blobs)
        val wobble = 0.10f + level * 0.34f
        val distance = baseRadius * (0.26f + 0.16f * sin(phase * 1.7f + index))
        val radius = baseRadius * (0.62f + wobble * sin(phase * 2.3f + index * 1.4f))
        drawCircle(
            color = palette.edge,
            radius = radius,
            center = Offset(
                x = centre.x + cos(angle) * distance,
                y = centre.y + sin(angle) * distance
            )
        )
    }

    // Core.
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(palette.core, palette.edge),
            center = Offset(centre.x - baseRadius * 0.25f, centre.y - baseRadius * 0.3f),
            radius = baseRadius * 1.5f
        ),
        radius = baseRadius * 0.92f,
        center = centre
    )

    // Specular highlight, fixed relative to the light source rather than to the rotation.
    drawCircle(
        color = palette.accent,
        radius = baseRadius * 0.30f,
        center = Offset(centre.x - baseRadius * 0.32f, centre.y - baseRadius * 0.38f)
    )

    // Rim: a ring whose thickness tracks the voice while speaking, and stays a hairline otherwise.
    val ringWidth = if (state == LiveConversationState.SPEAKING) {
        2.dp.toPx() + level * 6.dp.toPx()
    } else {
        1.5.dp.toPx()
    }
    drawCircle(
        color = palette.core.copy(alpha = 0.55f),
        radius = baseRadius * (1.02f + level * 0.10f),
        center = centre,
        style = Stroke(width = ringWidth)
    )
}

/** Small glass pill showing where the conversation is, in SAIF AI's colours. */
@Composable
private fun StatusPill(state: LiveConversationState) {
    val colour = when (state) {
        LiveConversationState.IDLE -> Color(0xFFA8A59B)
        LiveConversationState.LISTENING -> Color(0xFF7C5CE0)
        LiveConversationState.THINKING -> Color(0xFF6B31CF)
        LiveConversationState.SPEAKING -> Color(0xFF22C55E)
    }
    Row(
        Modifier
            .padding(top = 6.dp)
            .clip(RoundedCornerShape(50))
            .background(Color(0x22000000))
            .padding(horizontal = 12.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(colour))
        Spacer(Modifier.width(7.dp))
        Text(
            text = state.label.uppercase(),
            color = Color(0xFFE8E4DA),
            fontSize = 10.5.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.3.sp
        )
    }
}

/**
 * The full-screen live conversation surface: orb, captions and controls.
 *
 * It sits above chat, the editor and the workspace views alike, because a live conversation is a
 * mode rather than a screen - everything underneath stays exactly where the user left it.
 */
@Composable
fun SaifLiveConversationPanel(
    isLightMode: Boolean,
    onClose: () -> Unit,
    onRequestScreenShare: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val userText by SaifLive.userTranscript.collectAsState()
    val aiText by SaifLive.assistantTranscript.collectAsState()
    val liveError by SaifLive.liveError.collectAsState()
    val state by SaifLive.orbState.collectAsState()
    val sharing by SaifLive.isScreenSharing.collectAsState()
    val mode by SaifLive.liveMode.collectAsState()
    var muted by remember { mutableStateOf(false) }

    DisposableEffect(Unit) { onDispose { SaifLive.setMicMuted(false) } }

    Box(
        modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF22211E),
                        Color(0xFF150C2E),
                        Color(0xFF22211E)
                    )
                )
            )
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "SAIF AI LIVE",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.6.sp
                    )
                    Text(
                        text = if (mode == LiveMode.SCREEN_SHARE) "Helping with your screen" else "Voice conversation",
                        color = Color(0xFFB3A0F2),
                        fontSize = 11.sp
                    )
                }
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(0x33FFFFFF))
                        .tapTo { onClose() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Close, "Close", tint = Color.White, modifier = Modifier.size(20.dp))
                }
            }

            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                SaifLiveOrb(
                    modifier = Modifier.size(if (sharing) 300.dp else 340.dp),
                    isLightMode = isLightMode,
                    onTap = {
                        if (state == LiveConversationState.SPEAKING) SaifLive.interrupt()
                        else {
                            muted = !muted
                            SaifLive.setMicMuted(muted)
                        }
                    },
                    onLongPress = {
                        SaifLive.stopLive(context)
                        onClose()
                    }
                )
            }

            Column(
                Modifier.fillMaxWidth().padding(horizontal = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                androidx.compose.animation.AnimatedVisibility(
                    visible = userText.isNotBlank(),
                    enter = androidx.compose.animation.fadeIn(),
                    exit = androidx.compose.animation.fadeOut()
                ) {
                    Text(
                        userText,
                        color = Color(0xFFD6D3C7),
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        maxLines = 2
                    )
                }
                Spacer(Modifier.height(6.dp))
                androidx.compose.animation.AnimatedVisibility(
                    visible = aiText.isNotBlank(),
                    enter = androidx.compose.animation.fadeIn(),
                    exit = androidx.compose.animation.fadeOut()
                ) {
                    Text(
                        aiText,
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center,
                        maxLines = 4
                    )
                }
                // A failed transcription or a refused provider call is recoverable while the
                // session is still up, so the reason stays visible next to the orb instead of being
                // turned into a dialog the user has to dismiss.
                liveError?.let { error ->
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "${error.title}: ${error.message}",
                        color = Color(0xFFFCA5A5),
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                }
                Spacer(Modifier.height(18.dp))
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 26.dp)
                    .padding(bottom = 34.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OrbButton(Icons.Default.Mic, Icons.Default.MicOff, "Mic", !muted) {
                    muted = !muted
                    SaifLive.setMicMuted(muted)
                }
                OrbButton(
                    if (sharing) Icons.AutoMirrored.Filled.StopScreenShare else Icons.AutoMirrored.Filled.ScreenShare,
                    if (sharing) Icons.AutoMirrored.Filled.StopScreenShare else Icons.AutoMirrored.Filled.ScreenShare,
                    if (sharing) "Screen on" else "Screen",
                    !sharing
                ) {
                    if (sharing) SaifLive.stopScreenShare() else onRequestScreenShare()
                }
                OrbButton(Icons.Default.Close, Icons.Default.Close, "Stop", false) {
                    SaifLive.stopLive(context)
                    onClose()
                }
            }
        }
    }
}

@Composable
private fun OrbButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    offIcon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(CircleShape)
            .background(if (active) Color(0x33FFFFFF) else Color(0x14FFFFFF))
            .tapTo(onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Icon(
            if (active) icon else offIcon,
            label,
            tint = if (active) Color.White else Color(0x99FFFFFF),
            modifier = Modifier.size(22.dp)
        )
        Spacer(Modifier.height(3.dp))
        Text(label, color = if (active) Color.White else Color(0x99FFFFFF), fontSize = 10.sp)
    }
}

/** A plain tap handler, so buttons behave like buttons rather than firing on any pointer change. */
private fun Modifier.tapTo(onClick: () -> Unit): Modifier =
    this.pointerInput(onClick) { detectTapGestures(onTap = { onClick() }) }
