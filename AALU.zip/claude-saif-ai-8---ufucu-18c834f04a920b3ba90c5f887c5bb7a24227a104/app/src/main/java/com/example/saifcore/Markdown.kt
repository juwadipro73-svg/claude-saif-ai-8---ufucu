/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore

/**
 * A small markdown reader for SAIF AI's own chat feed.
 *
 * Written from scratch, and deliberately line-based: chat replies are short documents where the
 * structure that matters (fenced code, headings, lists, tables, quotes) is always line-aligned.
 * A block-level reader handles those reliably, keeps the streaming case cheap — each new chunk is
 * just a few more lines — and avoids pulling in a full CommonMark engine for features chat never
 * uses.
 *
 * Inline formatting (**bold**, *italic*, `code`, [links](url)) is left in the text and resolved by
 * the renderer rather than stripped, so a partially streamed sentence still reads correctly.
 */

sealed class MarkdownBlock {

    /** Ordinary prose and inline formatting. */
    data class Text(val text: String) : MarkdownBlock()

    /** `#` … `######`. */
    data class Heading(val level: Int, val text: String) : MarkdownBlock()

    /** A fenced or indented block, with the language hint if one was given. */
    data class CodeBlock(val language: String, val code: String) : MarkdownBlock()

    /** `-`/`*`/`+` bullets, or an ordered list. */
    data class ListBlock(val ordered: Boolean, val items: List<String>) : MarkdownBlock()

    /** `>` quoted text, with the markers removed. */
    data class Quote(val text: String) : MarkdownBlock()

    /** `---` or `***`. */
    data object Rule : MarkdownBlock()

    /** A pipe table, headers and body rows. */
    data class Table(val headers: List<String>, val rows: List<List<String>>) : MarkdownBlock()

    /** A tool call rendered inline in the feed, in the order it happened. */
    data class ToolCard(val tool: ToolCall) : MarkdownBlock()
}

object MarkdownParser {

    private val FENCE = Regex("^\\s*```+\\s*([A-Za-z0-9_+-]*)\\s*$")
    private val HEADING = Regex("^(#{1,6})\\s+(.*)$")
    private val BULLET = Regex("^\\s*[-*+]\\s+(.*)$")
    private val ORDERED = Regex("^\\s*(\\d+)[.)]\\s+(.*)$")
    private val QUOTE = Regex("^\\s*>\\s?(.*)$")
    private val RULE = Regex("^\\s*(-{3,}|\\*{3,}|_{3,})\\s*$")
    private val TABLE_DIVIDER = Regex("^\\s*\\|?\\s*:?-{2,}:?\\s*(\\|\\s*:?-{2,}:?\\s*)+\\|?\\s*$")

    /**
     * Splits [content] into blocks.
     *
     * Any `<!-- thought -->` region is recognised so the renderer can show it as a reasoning
     * passage instead of as prose. Tool calls are appended as cards at the end, which is where the
     * feed expects them.
     */
    fun parse(content: String, toolCalls: List<ToolCall> = emptyList()): List<MarkdownBlock> {
        if (content.isEmpty() && toolCalls.isEmpty()) return emptyList()

        val blocks = mutableListOf<MarkdownBlock>()
        val lines = content.replace("\r\n", "\n").split('\n')

        var index = 0
        while (index < lines.size) {
            val line = lines[index]

            // Fenced code: consume until the closing fence or the end of the message, so a reply
            // still being streamed shows a complete-looking code block.
            val fence = FENCE.matchEntire(line)
            if (fence != null) {
                val language = fence.groupValues[1]
                val body = StringBuilder()
                index++
                while (index < lines.size && FENCE.matchEntire(lines[index]) == null) {
                    body.append(lines[index]).append('\n')
                    index++
                }
                if (index < lines.size) index++ // closing fence
                blocks.add(MarkdownBlock.CodeBlock(language, body.toString().trimEnd('\n')))
                continue
            }

            if (RULE.matches(line)) {
                blocks.add(MarkdownBlock.Rule)
                index++
                continue
            }

            val heading = HEADING.matchEntire(line)
            if (heading != null) {
                blocks.add(MarkdownBlock.Heading(heading.groupValues[1].length, heading.groupValues[2].trim()))
                index++
                continue
            }

            // Pipe table: a header row, a divider row, then body rows.
            if (line.contains('|') && index + 1 < lines.size && TABLE_DIVIDER.matches(lines[index + 1])) {
                val headers = splitTableRow(line)
                index += 2
                val rows = mutableListOf<List<String>>()
                while (index < lines.size && lines[index].contains('|')) {
                    rows.add(splitTableRow(lines[index]))
                    index++
                }
                blocks.add(MarkdownBlock.Table(headers, rows))
                continue
            }

            if (BULLET.matches(line)) {
                val items = mutableListOf<String>()
                while (index < lines.size && BULLET.matches(lines[index])) {
                    items.add(BULLET.matchEntire(lines[index])!!.groupValues[1].trim())
                    index++
                }
                blocks.add(MarkdownBlock.ListBlock(ordered = false, items = items))
                continue
            }

            if (ORDERED.matches(line)) {
                val items = mutableListOf<String>()
                while (index < lines.size && ORDERED.matches(lines[index])) {
                    items.add(ORDERED.matchEntire(lines[index])!!.groupValues[2].trim())
                    index++
                }
                blocks.add(MarkdownBlock.ListBlock(ordered = true, items = items))
                continue
            }

            if (QUOTE.matches(line)) {
                val body = StringBuilder()
                while (index < lines.size && QUOTE.matches(lines[index])) {
                    val text = QUOTE.matchEntire(lines[index])!!.groupValues[1]
                    if (text.isNotBlank()) body.append(text).append('\n')
                    index++
                }
                blocks.add(MarkdownBlock.Quote(body.toString().trimEnd()))
                continue
            }

            // Prose: gather until a blank line or the start of another construct.
            val prose = StringBuilder()
            while (index < lines.size && lines[index].isNotBlank() && !startsBlock(lines[index])) {
                prose.append(lines[index]).append('\n')
                index++
            }
            if (prose.isNotEmpty()) {
                blocks.add(MarkdownBlock.Text(prose.toString().trimEnd()))
            } else {
                index++ // blank line or an unmatched marker: skip it rather than looping
            }
        }

        blocks.addAll(toolCalls.map { MarkdownBlock.ToolCard(it) })
        return blocks
    }

    private fun startsBlock(line: String) =
        FENCE.matchEntire(line) != null ||
            HEADING.matchEntire(line) != null ||
            BULLET.matches(line) ||
            ORDERED.matches(line) ||
            QUOTE.matches(line) ||
            RULE.matches(line)

    private fun splitTableRow(line: String): List<String> =
        line.trim().trim('|').split('|').map { it.trim() }

    /** Splits a `<!-- thought -->` passage out of [content]. Returns the thought and the rest. */
    fun splitThought(content: String): Pair<String?, String> {
        val open = content.indexOf("<!-- thought")
        if (open < 0) return null to content
        val afterOpen = content.indexOf("-->", open)
        if (afterOpen < 0) return null to content
        val close = content.indexOf("<!-- /thought -->", afterOpen)
        if (close < 0) {
            // Still streaming: everything after the opening marker is thought for now.
            return content.substring(afterOpen + 3).trim() to content.substring(0, open).trim()
        }
        val thought = content.substring(afterOpen + 3, close).trim()
        val rest = (content.substring(0, open) + content.substring(close + "<!-- /thought -->".length)).trim()
        return thought to rest
    }
}
