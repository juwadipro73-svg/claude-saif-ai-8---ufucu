/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. The app as distributed also contains third-party
 * GNU GPL v3 material - see LICENSE and THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore

import android.app.Application
import com.example.saifagent.AgentProtocol
import com.example.saifagent.AgentStep
import com.example.saifagent.ApprovalGate
import com.example.saifagent.ToolContext
import com.example.saifagent.ToolOutcome
import com.example.saifagent.ToolRegistry
import com.example.saifagent.TranscriptEntry
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * SAIF AI's own agent backend — the engine behind the main chat.
 *
 * Written from scratch, and built on two things SAIF AI owns: the provider gateway in
 * `com.example.llm` for talking to a model, and the agent runtime in `com.example.saifagent` for
 * deciding and running the next step. There is no external agent service in the loop at all: the
 * conversation stays on the device and goes straight to whichever provider the user configured.
 *
 * The loop is the ordinary one — ask for one step, run it, show the result, repeat — but three
 * policies around it are deliberate:
 *
 *  - **Anything that changes the device waits for the user.** A tool that writes or runs is
 *    suspended on a deferred until the UI resolves it, unless auto-approval is on. The wait is in
 *    the tool call, not in the loop, so refusing one action does not end the run.
 *  - **The model is told about refusals.** A "no" becomes an observation the model can work around,
 *    which is the difference between a helpful agent and one that stalls.
 *  - **A malformed reply is repaired, not fatal.** The parser's complaint is fed back as an
 *    observation and the model gets another turn.
 */
class SaifAgentBackend(
    private val application: Application,
    private val backendScope: CoroutineScope,
    private val authPrefs: AuthPreferences,
    private val store: ChatSessionStore,
    private val isNetworkConnectedProvider: () -> Boolean = { true },
    private val onHubOnline: () -> Unit = {},
    private val commandPolicyProvider: () -> String = { "CASCADE_COMMANDS_AUTO_EXECUTION_OFF" },
    private val authInfoProvider: (() -> AgyHubClient.AgyAuthInfo)? = null
) {

    private companion object {
        const val MAX_STEPS = 40
        const val AUTO_EAGER = "CASCADE_COMMANDS_AUTO_EXECUTION_EAGER"
    }

    // ---- Observable state --------------------------------------------------------------------

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    /** The conversation the backend is writing to, if one is open. */
    private val _currentConversation = MutableStateFlow<Conversation?>(null)
    val currentConversation: StateFlow<Conversation?> = _currentConversation.asStateFlow()

    /** The error that stopped the last run, or null when it finished cleanly. */
    private val _conversationError = MutableStateFlow<String?>(null)
    val conversationError: StateFlow<String?> = _conversationError.asStateFlow()

    /** True while a run is producing output. */
    private val _isStreaming = MutableStateFlow(false)
    val isStreaming: StateFlow<Boolean> = _isStreaming.asStateFlow()

    /** True while a stored conversation is being loaded. */
    private val _isLoadingConversation = MutableStateFlow(false)
    val isLoadingConversation: StateFlow<Boolean> = _isLoadingConversation.asStateFlow()

    private val _conversations = MutableStateFlow<List<Conversation>>(emptyList())
    val conversations: StateFlow<List<Conversation>> = _conversations.asStateFlow()

    private val _pendingApprovals = MutableStateFlow<List<PendingToolApproval>>(emptyList())
    val pendingApprovals: StateFlow<List<PendingToolApproval>> = _pendingApprovals.asStateFlow()

    private val _availableModels = MutableStateFlow<List<AgentModel>>(emptyList())
    val availableModels: StateFlow<List<AgentModel>> = _availableModels.asStateFlow()

    private val _selectedModelId = MutableStateFlow<String>("")
    val selectedModelId: StateFlow<String> = _selectedModelId.asStateFlow()

    private val _quotas = MutableStateFlow<List<AgentQuota>>(emptyList())
    val quotas: StateFlow<List<AgentQuota>> = _quotas.asStateFlow()

    private val _isAuthBusy = MutableStateFlow(false)
    val isAuthBusy: StateFlow<Boolean> = _isAuthBusy.asStateFlow()

    private val _authFeedbackMessage = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val authFeedbackMessage: SharedFlow<String> = _authFeedbackMessage.asSharedFlow()

    private val _agyAuthInfo = MutableStateFlow(AgyHubClient.AgyAuthInfo())
    val agyAuthInfo: StateFlow<AgyHubClient.AgyAuthInfo> = _agyAuthInfo.asStateFlow()

    /** A sign-in the user has to finish in a browser, and the URL to do it in. */
    data class AgyLoginIssue(val message: String, val verificationUrl: String)

    private val _agyLoginIssue = MutableStateFlow<AgyLoginIssue?>(null)
    val agyLoginIssue: StateFlow<AgyLoginIssue?> = _agyLoginIssue.asStateFlow()

    /** The sign-in URL waiting to be opened, if any. */
    private val _pendingLoginUrl = MutableStateFlow<String?>(null)
    val pendingLoginUrl: StateFlow<String?> = _pendingLoginUrl.asStateFlow()

    fun clearAgyLoginIssue() {
        _agyLoginIssue.value = null
    }

    fun clearPendingLoginUrl() {
        _pendingLoginUrl.value = null
    }

    val agyHubClient = AgyHubClient()

    // ---- Run bookkeeping ----------------------------------------------------------------------

    /** Tool calls waiting for the user to allow or refuse them, by tool call id. */
    private val approvalWaiters = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()

    /** Tool calls waiting for an answer to a questionnaire, by tool call id. */
    private val choiceWaiters = ConcurrentHashMap<String, CompletableDeferred<ChoiceAnswer?>>()

    @Volatile
    private var runJob: Job? = null

    @Volatile
    private var cancelled = false

    private val workspace: File get() = com.example.saifagent.SaifAgent.workspace(application)

    init {
        refreshModels()
        refreshConversations()
        backendScope.launch { refreshAuth() }
    }

    // ---- Tools --------------------------------------------------------------------------------

    private fun tools(): ToolRegistry = ToolRegistry.defaults(
        shell = com.example.saifagent.SaifAgent.defaultShell(),
        searchEndpoint = { com.example.saifagent.AgentPrefs.searchEndpoint },
        commandPolicy = { com.example.saifagent.SaifAgent.isCommandAllowed(it) }
    )

    private fun autoApprove(): Boolean = commandPolicyProvider() == AUTO_EAGER

    // ---- Conversations ------------------------------------------------------------------------

    fun newConversation(title: String = "New Chat"): Conversation {
        val conversation = store.newConversation(title, _selectedModelId.value)
        refreshConversations()
        _messages.value = emptyList()
        _currentConversation.value = conversation
        return conversation
    }

    /** Starts a fresh conversation and makes it current. */
    fun startNewChat(): Conversation = newConversation()

    /** Stops the run in progress. Anything already produced is kept. */
    fun stopStreaming() = cancelRun()

    /**
     * Switches to a stored conversation.
     *
     * Loading is flagged rather than awaited so the caller can show progress; a conversation that
     * is not in the store simply becomes an empty one instead of an error.
     */
    fun selectConversation(conversationId: String) {
        backendScope.launch {
            _isLoadingConversation.value = true
            _conversationError.value = null
            withContext(Dispatchers.IO) {
                store.setActive(conversationId)
                if (store.get(conversationId) == null) {
                    store.newConversation().let { store.setActive(it.id) }
                }
                val activeId = store.activeConversationId
                if (activeId != null) {
                    _currentConversation.value = store.get(activeId)
                    _messages.value = store.messagesFor(activeId)
                }
                refreshConversations()
            }
            _isLoadingConversation.value = false
        }
    }

    fun openConversation(conversationId: String) {
        store.setActive(conversationId)
        _messages.value = store.messagesFor(conversationId)
        _currentConversation.value = store.get(conversationId)
    }

    fun renameConversation(conversationId: String, title: String) {
        store.rename(conversationId, title)
        refreshConversations()
    }

    fun deleteConversation(conversationId: String) {
        store.delete(conversationId)
        refreshConversations()
        if (store.activeConversationId == null) _messages.value = emptyList()
    }

    fun refreshConversations() {
        _conversations.value = store.all()
        store.activeConversationId?.let { _messages.value = store.messagesFor(it) }
    }

    // ---- Sending ------------------------------------------------------------------------------

    /**
     * Sends one user message and runs the agent until it answers, stops, or is cancelled.
     *
     * The user's text is stored exactly as typed; only the copy sent to the model is expanded, so
     * the feed always shows what the user actually wrote.
     */
    fun sendMessage(text: String, attachments: List<ChatAttachment> = emptyList()) {
        val conversationId = store.activeConversationId ?: startNewChat().id
        val expanded = PromptExpansion.expand(text)
        _conversationError.value = null
        store.addMessage(
            conversationId,
            ChatMessage(
                conversationId = conversationId,
                role = MessageRole.USER,
                content = text,
                attachments = attachments
            )
        )
        _messages.value = store.messagesFor(conversationId)
        runTurn(conversationId, expanded)
    }

    private fun runTurn(conversationId: String, task: String) {
        runJob?.cancel()
        cancelled = false
        store.markRunning(conversationId, true)
        refreshConversations()

        _isStreaming.value = true
        runJob = backendScope.launch {
            val registry = tools()
            val system = AgentProtocol.systemPrompt(registry.all(), workspace.absolutePath)
            val startedAt = System.currentTimeMillis()

            try {
                var step = 0
                while (step < MAX_STEPS && !cancelled) {
                    step++
                    val history = buildHistory(conversationId)
                    val prompt = AgentProtocol.renderTurn(task, history)

                    val reply = callModel(system, prompt)
                    if (reply.isFailure) {
                        val message = reply.exceptionOrNull()?.message ?: "unknown error"
                        _conversationError.value = message
                        appendAssistant(conversationId, "The model call failed: $message")
                        break
                    }

                    when (val parsed = AgentProtocol.parse(reply.getOrThrow())) {
                        is AgentStep.Answer -> {
                            appendAssistant(conversationId, parsed.text)
                            break
                        }

                        is AgentStep.Unreadable -> {
                            // Feed the complaint back; the model usually repairs it on its own.
                            store.addMessage(
                                conversationId,
                                ChatMessage(
                                    conversationId = conversationId,
                                    role = MessageRole.SYSTEM,
                                    content = "Your reply could not be used (${parsed.reason}). " +
                                        "Answer with exactly one JSON object."
                                )
                            )
                            _messages.value = store.messagesFor(conversationId)
                        }

                        is AgentStep.Call -> {
                            val handled = performCall(conversationId, registry, parsed)
                            if (!handled) break
                        }
                    }
                }

                if (step >= MAX_STEPS) {
                    appendAssistant(
                        conversationId,
                        "I stopped after $MAX_STEPS steps without finishing. Ask me to continue if you want me to keep going."
                    )
                }
            } finally {
                _isStreaming.value = false
                store.markRunning(conversationId, false)
                refreshConversations()
                onHubOnline()
            }
        }
    }

    /**
     * Runs one tool call and records it on the message the UI is watching.
     *
     * Returns false when the run should stop.
     */
    private suspend fun performCall(
        conversationId: String,
        registry: ToolRegistry,
        call: AgentStep.Call
    ): Boolean {
        val tool = registry.find(call.tool)
        if (tool == null) {
            store.addMessage(
                conversationId,
                ChatMessage(
                    conversationId = conversationId,
                    role = MessageRole.SYSTEM,
                    content = "There is no tool called '${call.tool}'. Available: ${registry.names().joinToString(", ")}"
                )
            )
            _messages.value = store.messagesFor(conversationId)
            return true // a wrong tool name is recoverable: let the model try again
        }

        val toolCall = ToolCall(
            name = tool.name,
            toolType = ToolType.of(tool.name),
            command = call.arguments.toString(),
            status = ToolStatus.RUNNING,
            stepIndex = store.messagesFor(conversationId).size
        )

        val message = ChatMessage(
            conversationId = conversationId,
            role = MessageRole.ASSISTANT,
            content = "",
            thoughtText = call.thought.takeIf { it.isNotBlank() },
            toolCalls = listOf(toolCall),
            isStreaming = true,
            modelId = _selectedModelId.value.ifBlank { null }
        )
        store.addMessage(conversationId, message)
        _messages.value = store.messagesFor(conversationId)

        if (tool.needsApproval && !autoApprove()) {
            val deferred = CompletableDeferred<Boolean>()
            approvalWaiters[toolCall.id] = deferred
            updateTool(conversationId, message.id, toolCall.copy(status = ToolStatus.PENDING_APPROVAL))
            _pendingApprovals.value = _pendingApprovals.value + PendingToolApproval(toolCall, message.id)

            val allowed = deferred.await()
            if (!allowed) {
                finishTool(
                    conversationId, message.id,
                    toolCall.copy(status = ToolStatus.TERMINATED, output = "Refused by the user.")
                )
                return true // refusal is information for the model, not the end of the run
            }
        }

        val startedAt = System.currentTimeMillis()
        val outcome: ToolOutcome = try {
            tool.run(call.arguments, ToolContext(workspace, gate()) { })
        } catch (t: Throwable) {
            ToolOutcome.fail("${t.javaClass.simpleName}: ${t.message}")
        }

        finishTool(
            conversationId,
            message.id,
            toolCall.copy(
                status = if (outcome.ok) ToolStatus.SUCCESS else ToolStatus.FAILED,
                output = outcome.output,
                durationMs = System.currentTimeMillis() - startedAt
            )
        )
        return !outcome.fatal
    }

    private fun gate(): ApprovalGate = object : ApprovalGate {
        override suspend fun confirm(tool: String, summary: String, detail: String) = autoApprove()
    }

    private suspend fun callModel(system: String, prompt: String): Result<String> {
        if (!isNetworkConnectedProvider()) {
            return Result.failure(IllegalStateException("There is no internet connection."))
        }
        val provider = com.example.data.local.ProviderSettingsManager.getActiveProvider()
        val model = _selectedModelId.value.ifBlank {
            com.example.data.local.ProviderSettingsManager.getActiveModel()
        }
        val key = com.example.data.local.ProviderSettingsManager.getActiveApiKey()
        if (model.isBlank()) return Result.failure(IllegalStateException("No model is selected."))
        if (key.isBlank()) return Result.failure(IllegalStateException("No API key is configured."))

        val request = com.example.llm.LlmRequest(
            prompt = prompt,
            systemPrompt = system,
            mode = "agent",
            jsonMode = true,
            maxTokens = 4096
        )

        var thought: String? = null
        return com.example.llm.LlmGateway.call(
            role = com.example.llm.LlmRole.CODER,
            provider = provider,
            apiKey = key,
            model = model,
            request = request,
            onThinking = { chunk -> thought = (thought ?: "") + chunk }
        ).map { response ->
            // Reasoning, when a provider reports it, is kept on the message the UI renders.
            _lastThought = response.thinkingText ?: thought
            response.text
        }
    }

    @Volatile
    private var _lastThought: String? = null

    /** Stored tool arguments are re-parsed defensively: they are written by the model. */
    private fun parseArgs(raw: String): JSONObject = runCatching { JSONObject(raw) }.getOrElse { JSONObject() }

    private fun appendAssistant(conversationId: String, text: String) {
        store.addMessage(
            conversationId,
            ChatMessage(
                conversationId = conversationId,
                role = MessageRole.ASSISTANT,
                content = text,
                thoughtText = _lastThought,
                isStreaming = false,
                modelId = _selectedModelId.value.ifBlank { null }
            )
        )
        _lastThought = null
        _messages.value = store.messagesFor(conversationId)
    }

    private fun updateTool(conversationId: String, messageId: String, tool: ToolCall) {
        store.updateToolCall(conversationId, messageId, tool)
        _messages.value = store.messagesFor(conversationId)
    }

    private fun finishTool(conversationId: String, messageId: String, tool: ToolCall) {
        approvalWaiters.remove(tool.id)?.takeIf { !it.isCompleted }?.cancel()
        choiceWaiters.remove(tool.id)?.takeIf { !it.isCompleted }?.cancel()
        _pendingApprovals.value = _pendingApprovals.value.filterNot { it.toolCall.id == tool.id }
        store.updateToolCall(conversationId, messageId, tool)
        val message = store.findMessage(conversationId, messageId) ?: return
        store.upsertMessage(conversationId, message.copy(isStreaming = false))
        _messages.value = store.messagesFor(conversationId)
    }

    // ---- Rendering the transcript --------------------------------------------------------------

    /**
     * Rebuilds the transcript the model sees.
     *
     * Only the last few turns are sent in full; older ones are folded into a summary line so a long
     * conversation cannot outgrow the provider's context window.
     */
    private fun buildHistory(conversationId: String, keep: Int = 12): List<TranscriptEntry> {
        val all = store.messagesFor(conversationId)
        val recent = all.takeLast(keep)
        val entries = mutableListOf<TranscriptEntry>()

        if (all.size > recent.size) {
            entries.add(
                TranscriptEntry.Observation(
                    "history", true,
                    "${all.size - recent.size} earlier messages are not shown."
                )
            )
        }

        for (message in recent) {
            when (message.role) {
                MessageRole.USER -> entries.add(
                    TranscriptEntry.Observation("user", true, message.content)
                )
                MessageRole.SYSTEM -> entries.add(
                    TranscriptEntry.Observation("system", false, message.content)
                )
                MessageRole.ASSISTANT -> {
                    if (!message.thoughtText.isNullOrBlank()) {
                        entries.add(TranscriptEntry.Observation("thought", true, message.thoughtText))
                    }
                    message.toolCalls.forEach { tool ->
                        entries.add(TranscriptEntry.Call(tool.name, parseArgs(tool.command)))
                        entries.add(
                            TranscriptEntry.Observation(
                                tool.name,
                                tool.status == ToolStatus.SUCCESS,
                                tool.output
                            )
                        )
                    }
                    if (message.content.isNotBlank()) {
                        entries.add(TranscriptEntry.Observation("assistant", true, message.content))
                    }
                }
                MessageRole.TOOL -> entries.add(
                    TranscriptEntry.Observation("tool", true, message.content)
                )
                MessageRole.SUMMARY -> entries.add(
                    TranscriptEntry.Observation("summary", true, message.content)
                )
            }
        }
        return entries
    }

    // ---- Approvals and choices ------------------------------------------------------------------

    fun approveAndExecuteTerminalTool(tool: ToolCall, messageId: String, scope: String?) {
        resolveApproval(tool.id, allowed = true)
    }

    fun rejectTerminalTool(tool: ToolCall, messageId: String, reason: String?) {
        resolveApproval(tool.id, allowed = false)
    }

    fun approveAllPendingTools(items: List<PendingToolApproval>) {
        items.forEach { resolveApproval(it.toolCall.id, allowed = true) }
    }

    fun rejectAllPendingTools(items: List<PendingToolApproval>) {
        items.forEach { resolveApproval(it.toolCall.id, allowed = false) }
    }

    private fun resolveApproval(toolCallId: String, allowed: Boolean) {
        approvalWaiters.remove(toolCallId)?.takeIf { !it.isCompleted }?.complete(allowed)
        _pendingApprovals.value = _pendingApprovals.value.filterNot { it.toolCall.id == toolCallId }
    }

    /** Stops the tool that is running, and refuses it if it was still waiting. */
    fun terminateRunningTerminalTool(tool: ToolCall, messageId: String) {
        resolveApproval(tool.id, allowed = false)
        choiceWaiters.remove(tool.id)?.takeIf { !it.isCompleted }?.complete(null)
        val conversationId = store.activeConversationId ?: return
        finishTool(
            conversationId, messageId,
            tool.copy(status = ToolStatus.TERMINATED, output = "Stopped by the user.")
        )
    }

    /** The user's answers to a questionnaire, in the order the questions were asked. */
    data class ChoiceAnswer(val responses: List<AskQuestionResponseItemDto>, val note: String)

    fun submitUserChoices(
        tool: ToolCall,
        messageId: String,
        responses: List<AskQuestionResponseItemDto>,
        summary: String
    ) {
        choiceWaiters.remove(tool.id)?.takeIf { !it.isCompleted }
            ?.complete(ChoiceAnswer(responses, summary))
    }

    fun skipUserChoices(tool: ToolCall, messageId: String, responses: List<AskQuestionResponseItemDto>) {
        choiceWaiters.remove(tool.id)?.takeIf { !it.isCompleted }
            ?.complete(ChoiceAnswer(responses, ""))
    }

    fun cancelUserChoices(tool: ToolCall, messageId: String) {
        choiceWaiters.remove(tool.id)?.takeIf { !it.isCompleted }?.complete(null)
    }

    /** Cancels the whole run. Anything already done stays done. */
    fun cancelRun() {
        cancelled = true
        runJob?.cancel()
        approvalWaiters.values.forEach { if (!it.isCompleted) it.complete(false) }
        choiceWaiters.values.forEach { if (!it.isCompleted) it.complete(null) }
        approvalWaiters.clear()
        choiceWaiters.clear()
    }

    // ---- Models and account ---------------------------------------------------------------------

    fun selectModel(id: String) {
        _selectedModelId.value = id
        authPrefs.preferredModelId = id
    }

    fun refreshModels() {
        val configured = com.example.data.local.ProviderSettingsManager.getActiveModel()
            .takeIf { it.isNotBlank() }
        val provider = com.example.data.local.ProviderSettingsManager.getActiveProvider()

        val models = mutableListOf<AgentModel>()
        if (configured != null) {
            models += AgentModel(id = configured, label = configured, isDefault = true)
        }
        _availableModels.value = models
        if (_selectedModelId.value.isBlank()) {
            _selectedModelId.value = authPrefs.preferredModelId.ifBlank { configured.orEmpty() }
        }
        if (provider.isNotBlank()) {
            _quotas.value = emptyList()
        }
    }

    /**
     * Fetches the provider's live model list in the background.
     *
     * Separate from [refreshModels] because it needs the network: the picker shows the configured
     * model immediately and gains the full list whenever this returns.
     */
    fun refreshModelsAsync() {
        backendScope.launch {
            val key = com.example.data.local.ProviderSettingsManager.getActiveApiKey()
            if (key.isBlank()) return@launch
            val live = runCatching { com.example.llm.GeminiModelCatalog.live(key) }
                .getOrDefault(emptyList())
            if (live.isEmpty()) return@launch
            val configured = com.example.data.local.ProviderSettingsManager.getActiveModel()
            val merged = LinkedHashMap<String, AgentModel>()
            _availableModels.value.forEach { merged[it.id] = it }
            live.filter { it.isNotBlank() }
                .forEach { merged.getOrPut(it) { AgentModel(id = it, label = it) } }
            merged[configured]?.let { merged[configured] = it.copy(isDefault = true) }
            _availableModels.value = merged.values.toList()
        }
    }

    /** Re-reads the account state from the local bridge and reports it. */
    suspend fun refreshAuth() {
        _isAuthBusy.value = true
        val info = agyHubClient.fetchAuthInfo().getOrDefault(
            AgyHubClient.AgyAuthInfo(
                status = AgyHubClient.AgyAuthStatus.OFFLINE,
                isOffline = true
            )
        )
        _agyAuthInfo.value = info
        _isAuthBusy.value = false
    }

    fun loginToAgyHub(force: Boolean = false) {
        backendScope.launch {
            _isAuthBusy.value = true
            val result = runCatching { refreshAuth() }
            _isAuthBusy.value = false
            _authFeedbackMessage.tryEmit(
                if (result.isSuccess) "Reconnected to SAIF AI's agent."
                else "Could not reach SAIF AI's agent: ${result.exceptionOrNull()?.message}"
            )
        }
    }

    /** Signs the agent out. The conversation history is left alone. */
    fun logoutFromAgyHub() {
        backendScope.launch {
            _isAuthBusy.value = true
            val result = runCatching { agyHubClient.logout() }
            _agyAuthInfo.value = AgyHubClient.AgyAuthInfo(
                status = AgyHubClient.AgyAuthStatus.UNAUTHENTICATED
            )
            _agyLoginIssue.value = null
            _pendingLoginUrl.value = null
            _isAuthBusy.value = false
            _authFeedbackMessage.tryEmit(
                if (result.isFailure) "Signed out locally; the server did not confirm."
                else "Signed out."
            )
        }
    }

    fun retryConnections() {
        backendScope.launch {
            refreshAuth()
            refreshModels()
            onHubOnline()
        }
    }

    /**
     * Transcribes a recording using SAIF AI's own speech-to-text router.
     *
     * An empty transcript is reported through [onError] rather than as an empty success, because
     * "I heard nothing" and "I heard silence" are different things to the person who just spoke.
     */
    fun transcribeAudioFile(file: File, onDone: (String) -> Unit, onError: ((String) -> Unit)? = null) {
        backendScope.launch {
            val outcome = withContext(Dispatchers.IO) {
                runCatching {
                    com.example.stt.SttRouter.transcribe(
                        wavBytes = file.readBytes(),
                        profile = com.example.stt.SttProfile.DICTATION,
                        context = application
                    )
                }
            }
            outcome
                .onSuccess { result ->
                    if (result.text.isNotBlank()) onDone(result.text)
                    else onError?.invoke(result.rejectedReason ?: "No speech was recognised.")
                }
                .onFailure { onError?.invoke(it.message ?: "Transcription failed.") }
        }
    }

    /** Folds the current conversation into a summary message and starts fresh context. */
    fun compact(conversationId: String) {
        val all = store.messagesFor(conversationId)
        if (all.isEmpty()) return
        val summary = all.filter { it.content.isNotBlank() }
            .takeLast(20)
            .joinToString("\n") { "${it.role}: ${it.content.take(400)}" }
        store.addMessage(
            conversationId,
            ChatMessage(
                conversationId = conversationId,
                role = MessageRole.SUMMARY,
                content = summary
            )
        )
        _messages.value = store.messagesFor(conversationId)
    }
}
