/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. The app as distributed also contains third-party
 * GNU GPL v3 material - see LICENSE and THIRD_PARTY_NOTICES.md.
 */

package com.example.saifagent.tools

import com.example.saifagent.AgentTool
import com.example.saifagent.ToolContext
import com.example.saifagent.ToolOutcome
import com.example.saifagent.ToolParam
import com.example.saifagent.optionalString
import com.example.saifagent.requireString
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private val http = OkHttpClient.Builder()
    .connectTimeout(15, TimeUnit.SECONDS)
    .readTimeout(30, TimeUnit.SECONDS)
    .followRedirects(true)
    .build()

/**
 * Strips scripts, styles and tags so a web page arrives as text the model can actually read.
 *
 * This is not an HTML parser and does not try to be: for the agent's purposes "good enough text" is
 * worth far more than a correct DOM, and a real parser is a large dependency for little gain.
 */
private fun htmlToText(html: String): String {
    var text = html
    val kill = Regex("(?is)<(script|style|noscript|svg)[^>]*>.*?</\\1>")
    text = kill.replace(text, " ")
    text = Regex("(?is)<br\\s*/?>|</p>|</div>|</li>|</h[1-6]>").replace(text, "\n")
    text = Regex("(?s)<[^>]+>").replace(text, " ")
    text = text
        .replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<")
        .replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'")
    return text.lineSequence()
        .map { it.trim() }
        .filter { it.isNotBlank() }
        .joinToString("\n")
}

/**
 * `http_get` — fetch a URL and return it as text.
 *
 * Only https, never follows a redirect to a private address, and the response is capped so one page
 * cannot swallow the whole context window.
 */
class HttpGetTool : AgentTool {
    override val name = "http_get"
    override val description =
        "Fetch a URL over HTTPS and return the response as text. HTML is converted to readable text."
    override val params = listOf(
        ToolParam("url", "An https:// URL."),
        ToolParam("max_chars", "Optional cap on returned characters.", "number", false)
    )

    override suspend fun run(args: JSONObject, ctx: ToolContext): ToolOutcome {
        val url = args.requireString("url").trim()
        if (!url.startsWith("https://")) return ToolOutcome.fail("only https:// URLs are allowed")
        val cap = args.opt("max_chars")?.toString()?.toIntOrNull() ?: 20_000
        return try {
            val request = Request.Builder().url(url).get()
                .header("User-Agent", "SAIF-AI-Agent/1.0")
                .build()
            http.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return ToolOutcome.fail("HTTP ${response.code}")
                val body = response.body?.string().orEmpty()
                val text = if (body.trimStart().startsWith("<")) htmlToText(body) else body
                ctx.log("GET ${url.take(80)} -> ${text.length} chars")
                ToolOutcome.ok(if (text.length <= cap) text else text.take(cap) + "\n… truncated")
            }
        } catch (e: Exception) {
            ToolOutcome.fail("request failed: ${e.message}")
        }
    }
}

/**
 * `web_search` — optional, and off until the user supplies an endpoint.
 *
 * SAIF AI does not hard-code a search provider: scraping a public engine is fragile and usually
 * against its terms. The user can point this at any endpoint they are entitled to use (their own
 * gateway, a paid search API) from the agent settings.
 */
class WebSearchTool(private val endpoint: () -> String) : AgentTool {
    override val name = "web_search"
    override val description =
        "Search the web. Only available when a search endpoint is configured in SAIF AI's agent settings."
    override val params = listOf(ToolParam("query", "What to search for."))

    override suspend fun run(args: JSONObject, ctx: ToolContext): ToolOutcome {
        val base = endpoint().trim()
        if (base.isBlank()) {
            return ToolOutcome.fail(
                "web search is not configured. Add a search endpoint in Settings → SAIF AI Agent, " +
                    "or use http_get on a URL you already have."
            )
        }
        val query = args.requireString("query").trim()
        return try {
            val request = Request.Builder()
                .url("$base${if (base.contains('?')) '&' else '?'}q=${java.net.URLEncoder.encode(query, "UTF-8")}")
                .get().build()
            http.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return ToolOutcome.fail("search endpoint returned HTTP ${response.code}")
                val body = response.body?.string().orEmpty().take(20_000)
                ctx.log("search: ${query.take(80)}")
                ToolOutcome.ok(body)
            }
        } catch (e: Exception) {
            ToolOutcome.fail("search failed: ${e.message}")
        }
    }
}

/** `finish` is a no-op marker so the model can end a run explicitly when it prefers to. */
class AnswerTool : AgentTool {
    override val name = "finish"
    override val description = "End the run and give the final answer to the user."
    override val params = listOf(ToolParam("text", "The final answer."))

    override suspend fun run(args: JSONObject, ctx: ToolContext): ToolOutcome =
        ToolOutcome.ok(args.optionalString("text"))
}
