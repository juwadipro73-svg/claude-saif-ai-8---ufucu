/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore

import android.content.Context
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.ServerSocket
import java.net.URL
import java.util.concurrent.atomic.AtomicReference

/**
 * Runs SAIF AI's workspace daemon as a child process of the app.
 *
 * The daemon is a small Go binary shipped in the APK's native library directory. Android unpacks
 * that directory onto the filesystem automatically, which is the only supported way to get an
 * executable out of an APK. Nothing here needs root, a terminal app, or a downloaded Linux
 * filesystem: if the app is installed, the workspace can start.
 *
 * The port is chosen at launch rather than fixed, because a fixed port is a port that can already
 * be taken — by a previous run of the app, or by anything else on the device. We bind a socket to
 * port 0, read the port the system gave us, close it, and hand that number to the daemon. There is
 * a small race in between, but a collision only costs one retry.
 */
object SaifDaemon {

    private const val BINARY_NAME = "libsaifdaemon.so"
    private const val READY_TIMEOUT_MS = 10_000L
    private const val READY_POLL_MS = 150L
    private const val START_ATTEMPTS = 3

    @Volatile
    private var process: Process? = null

    @Volatile
    private var startedPort: Int = 0

    private val lastFailure = AtomicReference<String?>(null)

    /** Why the daemon could not be started, or null when it is running or has never been asked. */
    fun lastError(): String? = lastFailure.get()

    /** The port the running daemon answered on, or 0 when it is not running. */
    fun port(): Int = startedPort

    /** Where the daemon keeps the workspace: projects, saved state and sign-in details. */
    fun homeDir(context: Context): File {
        val external = context.getExternalFilesDir(null)
        val base = external ?: context.filesDir
        val home = File(base, "workspace")
        if (!home.exists()) home.mkdirs()
        return home
    }

    /**
     * Finds the bundled daemon binary, or null when this APK was built without one.
     *
     * The primary ABI directory is tried first, then every directory the package manager may have
     * unpacked, because a sideloaded build and an installed one do not always expose the same list.
     */
    private fun locateBinary(context: Context): File? {
        val libDirs = linkedSetOf<String>()
        context.applicationInfo.nativeLibraryDir?.let { libDirs.add(it) }
        context.applicationInfo.sourceDir?.let { apk ->
            val libRoot = File(apk).parentFile?.resolve("lib")
            libRoot?.listFiles()?.forEach { libDirs.add(it.absolutePath) }
        }
        val candidates = mutableListOf<File>()
        libDirs.filter { it.isNotBlank() }.forEach { dir ->
            Build.SUPPORTED_ABIS.forEach { abi ->
                candidates.add(File("$dir/$abi", BINARY_NAME))
            }
            File(dir).listFiles()?.forEach { sub ->
                candidates.add(File(sub, BINARY_NAME))
            }
            candidates.add(File(dir, BINARY_NAME))
        }
        return candidates.firstOrNull { it.exists() && it.length() > 0 }
    }

    /**
     * Starts the daemon if it is not already answering, and returns the base URL it is reachable
     * at — or null when it could not be started.
     *
     * Safe to call repeatedly and from several coroutines at once: the lock means concurrent
     * callers wait for one launch instead of racing to bind the same port.
     */
    suspend fun ensureRunning(context: Context): String? = withContext(Dispatchers.IO) {
        synchronized(this@SaifDaemon) {
            if (process?.isAlive == true && startedPort > 0 && probe(startedPort)) {
                val url = "http://127.0.0.1:$startedPort"
                AuthPreferences.daemonBaseUrl = url
                return@withContext url
            }
        }

        val binary = locateBinary(context)
            ?: run {
                lastFailure.set("This build of SAIF AI was packaged without the workspace daemon.")
                return@withContext null
            }

        val home = homeDir(context)
        repeat(START_ATTEMPTS) { attempt ->
            val port = freePort() ?: return@repeat
            val launched = runCatching {
                if (!binary.canExecute()) binary.setExecutable(true)
                ProcessBuilder(
                    binary.absolutePath,
                    "-port", port.toString(),
                    "-home", home.absolutePath
                ).apply {
                    redirectErrorStream(true)
                    environment()["HOME"] = home.absolutePath
                    environment()["TMPDIR"] = context.cacheDir.absolutePath
                }.start()
            }.getOrElse { error ->
                lastFailure.set("Could not start the workspace daemon: ${error.message}")
                null
            } ?: return@repeat

            process = launched
            // A child that writes more than the pipe holds blocks forever, so its output is
            // drained on a separate thread and kept as the daemon's log.
            drain(launched)

            val url = awaitReady(port)
            if (url != null) {
                synchronized(this@SaifDaemon) {
                    startedPort = port
                    lastFailure.set(null)
                }
                // Published last: the clients read this the moment it is set, so the daemon must
                // already be answering before anything is pointed at it.
                AuthPreferences.daemonBaseUrl = url
                return@withContext url
            }

            runCatching { launched.destroy() }
            if (attempt == START_ATTEMPTS - 1) {
                lastFailure.set("The workspace daemon started but never answered on port $port.")
            }
        }
        null
    }

    /** Stops the daemon. Used when the app is torn down; Android kills it anyway on process death. */
    fun stop() {
        synchronized(this@SaifDaemon) {
            runCatching { process?.destroy() }
            process = null
            startedPort = 0
            AuthPreferences.daemonBaseUrl = ""
        }
    }

    /** Asks the kernel for a free port on loopback. */
    private fun freePort(): Int? = runCatching {
        ServerSocket(0).use { it.localPort }
    }.getOrNull()

    /** Polls /ping until the daemon answers or we run out of patience. */
    private suspend fun awaitReady(port: Int): String? {
        val deadline = System.currentTimeMillis() + READY_TIMEOUT_MS
        while (System.currentTimeMillis() < deadline) {
            if (process?.isAlive == false) return null
            if (probe(port)) return "http://127.0.0.1:$port"
            delay(READY_POLL_MS)
        }
        return null
    }

    /**
     * A direct socket check rather than an OkHttp call, because this runs while the app is still
     * starting up and must not depend on the HTTP client's own state. It also has no timeout
     * surprises: both limits are set explicitly, and anything unexpected counts as "not yet".
     */
    private fun probe(port: Int): Boolean = runCatching {
        val connection = URL("http://127.0.0.1:$port/ping").openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 700
            connection.readTimeout = 700
            connection.instanceFollowRedirects = false
            connection.requestMethod = "GET"
            val ok = connection.responseCode in 200..299
            connection.inputStream.use { }
            ok
        } finally {
            connection.disconnect()
        }
    }.getOrDefault(false)

    private fun drain(process: Process) {
        val thread = Thread {
            runCatching {
                process.inputStream.bufferedReader().useLines { lines ->
                    lines.forEach { line ->
                        if (line.isNotBlank()) TermuxDaemonManager.log(line.trim())
                    }
                }
            }
        }
        thread.isDaemon = true
        thread.name = "saif-daemon-log"
        thread.start()
    }
}
