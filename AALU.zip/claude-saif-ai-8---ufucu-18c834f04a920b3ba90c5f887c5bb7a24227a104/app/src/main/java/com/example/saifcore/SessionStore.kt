/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. The app as distributed also contains third-party
 * GNU GPL v3 material - see LICENSE and THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore

import java.util.concurrent.ConcurrentHashMap

/**
 * Where a conversation lives while the agent is working on it.
 *
 * Written from scratch. It holds no Android objects and does no I/O: it is the in-memory working
 * set for one agent session, so it can be created per session and thrown away without ceremony.
 *
 * Two small design choices are worth stating. Ids are minted here rather than by the caller, so a
 * message can never be added without one. And message lookup is by both conversation and message id,
 * because tools arrive addressed to a message inside a conversation and must not be applied to a
 * same-named message elsewhere.
 */
class ChatSessionStore {

    private val conversations = ConcurrentHashMap<String, Conversation>()
    private val messages = ConcurrentHashMap<String, MutableList<ChatMessage>>()

    /** The conversation the UI is currently showing. */
    @Volatile
    var activeConversationId: String? = null
        private set

    fun newConversation(title: String = "New Chat", modelId: String = ""): Conversation {
        val conversation = Conversation(title = title, modelId = modelId)
        conversations[conversation.id] = conversation
        messages.putIfAbsent(conversation.id, mutableListOf())
        activeConversationId = conversation.id
        return conversation
    }

    fun setActive(conversationId: String?) {
        activeConversationId = conversationId
    }

    fun all(): List<Conversation> =
        conversations.values.sortedByDescending { it.updatedAt }

    fun get(conversationId: String): Conversation? = conversations[conversationId]

    fun rename(conversationId: String, title: String) {
        val current = conversations[conversationId] ?: return
        conversations[conversationId] = current.copy(title = title, updatedAt = System.currentTimeMillis())
    }

    fun markRunning(conversationId: String, running: Boolean) {
        val current = conversations[conversationId] ?: return
        conversations[conversationId] = current.copy(
            isRunning = running,
            notFullyIdle = running,
            runStatus = if (running) "CASCADE_RUN_STATUS_RUNNING" else "CASCADE_RUN_STATUS_IDLE",
            updatedAt = System.currentTimeMillis()
        )
    }

    fun delete(conversationId: String) {
        conversations.remove(conversationId)
        messages.remove(conversationId)
        if (activeConversationId == conversationId) activeConversationId = null
    }

    fun clear() {
        conversations.clear()
        messages.clear()
        activeConversationId = null
    }

    // ---- Messages ----------------------------------------------------------------------------

    fun messagesFor(conversationId: String): List<ChatMessage> =
        messages[conversationId]?.toList() ?: emptyList()

    fun addMessage(conversationId: String, message: ChatMessage): ChatMessage {
        val list = messages.getOrPut(conversationId) { mutableListOf() }
        list.add(message)
        touch(conversationId)
        return message
    }

    /** Replaces the message with the same id, or appends it when it is new. */
    fun upsertMessage(conversationId: String, message: ChatMessage) {
        val list = messages.getOrPut(conversationId) { mutableListOf() }
        val index = list.indexOfFirst { it.id == message.id }
        if (index >= 0) list[index] = message else list.add(message)
        touch(conversationId)
    }

    fun findMessage(conversationId: String, messageId: String): ChatMessage? =
        messages[conversationId]?.firstOrNull { it.id == messageId }

    fun removeMessage(conversationId: String, messageId: String) {
        messages[conversationId]?.removeAll { it.id == messageId }
        touch(conversationId)
    }

    /** Replaces one tool call inside a message, keeping the other calls as they were. */
    fun updateToolCall(conversationId: String, messageId: String, updated: ToolCall) {
        val list = messages[conversationId] ?: return
        val index = list.indexOfFirst { it.id == messageId }
        if (index < 0) return
        val message = list[index]
        val tools = message.toolCalls.toMutableList()
        val toolIndex = tools.indexOfFirst { it.id == updated.id }
        if (toolIndex >= 0) tools[toolIndex] = updated else tools.add(updated)
        list[index] = message.copy(toolCalls = tools)
        touch(conversationId)
    }

    private fun touch(conversationId: String) {
        val current = conversations[conversationId] ?: return
        conversations[conversationId] = current.copy(
            updatedAt = System.currentTimeMillis(),
            hasActivity = true,
            stepCount = current.stepCount + 1
        )
    }
}
