/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saifagent

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import org.json.JSONObject
import java.io.File

/**
 * How the runtime talks to a model.
 *
 * Deliberately the smallest possible surface — system prompt in, text out — so the runtime can run
 * against SAIF AI's provider gateway, a local model, or a fake in a test without any of them knowing
 * about each other.
 */
fun interface ModelGateway {
    suspend fun complete(system: String, prompt: String): Result<String>
}

/** One round of the transcript. */
sealed class TranscriptEntry {
    data class Call(val tool: String, val arguments: JSONObject) : TranscriptEntry()
    data class Observation(val tool: String, val ok: Boolean, val output: String) : TranscriptEntry()
    data class Refusal(val tool: String, val reason: String) : TranscriptEntry()
}

/** What a run produces. */
data class AgentResult(
    val answer: String,
    val stepsUsed: Int,
    val transcript: List<TranscriptEntry>,
    val stoppedBecause: StopReason
)

enum class StopReason { ANSWERED, STEP_LIMIT, CANCELLED, MODEL_ERROR }

/**
 * SAIF AI's own agent runtime.
 *
 * The loop is the ordinary one: describe the tools, ask the model for one step, run that step, show
 * it what happened, repeat until it answers or runs out of steps. What is SAIF AI's here is the
 * policy around it — every path is confined to the workspace, anything that changes the device asks
 * first, a refusal is fed back to the model as information rather than as an error, and a malformed
 * reply is repaired instead of failing the run.
 *
 * Nothing in this class reads the network, touches Android, or knows which provider is in use.
 */
class AgentRuntime(
    private val registry: ToolRegistry,
    private val model: ModelGateway,
    private val maxSteps: Int = 24,
    private val autoApprove: () -> Boolean = { false }
) {

    /** Everything a UI needs to render a run as it happens. */
    sealed interface Event {
        data class Thinking(val text: String) : Event
        data class Action(val tool: String, val arguments: JSONObject, val step: Int) : Event
        data class Observation(val tool: String, val ok: Boolean, val output: String) : Event
        data class Refused(val tool: String, val reason: String) : Event
        data class Asking(val tool: String, val summary: String) : Event
        data class Done(val answer: String, val steps: Int) : Event
        data class Failed(val reason: String) : Event
    }

    /**
     * Runs [task] to completion, emitting progress as it goes.
     *
     * @param workspace the only directory the tools may touch
     * @param approval asked before any tool that changes the device; ignored when auto-approve is on
     * @param isCancelled polled between steps so a long run can be stopped from the UI
     */
    fun run(
        task: String,
        workspace: File,
        approval: ApprovalGate,
        isCancelled: () -> Boolean = { false }
    ): Flow<Event> = flow {
        val transcript = mutableListOf<TranscriptEntry>()
        val system = AgentProtocol.systemPrompt(registry.all(), workspace.absolutePath)
        var answer = ""
        var reason = StopReason.STEP_LIMIT

        workspace.mkdirs()

        for (step in 1..maxSteps) {
            if (isCancelled()) {
                reason = StopReason.CANCELLED
                break
            }

            val prompt = AgentProtocol.renderTurn(task, transcript)
            val reply = model.complete(system, prompt)
            if (reply.isFailure) {
                emit(Event.Failed(reply.exceptionOrNull()?.message ?: "the model call failed"))
                reason = StopReason.MODEL_ERROR
                break
            }

            when (val parsed = AgentProtocol.parse(reply.getOrThrow())) {
                is AgentStep.Answer -> {
                    answer = parsed.text
                    reason = StopReason.ANSWERED
                    emit(Event.Done(answer, step))
                    break
                }

                is AgentStep.Unreadable -> {
                    // Show it to the model and let it correct itself instead of giving up.
                    transcript += TranscriptEntry.Observation("reply", false,
                        "Your reply could not be used (${parsed.reason}). Answer with exactly one JSON object.")
                    emit(Event.Thinking(parsed.reason))
                    continue
                }

                is AgentStep.Call -> {
                    val tool = registry.find(parsed.tool)
                    if (tool == null) {
                        transcript += TranscriptEntry.Observation(parsed.tool, false,
                            "No such tool. Available: ${registry.names().joinToString(", ")}")
                        emit(Event.Refused(parsed.tool, "unknown tool"))
                        continue
                    }

                    if (parsed.thought.isNotBlank()) emit(Event.Thinking(parsed.thought))
                    emit(Event.Action(tool.name, parsed.arguments, step))
                    transcript += TranscriptEntry.Call(tool.name, parsed.arguments)

                    if (tool.needsApproval && !autoApprove()) {
                        emit(Event.Asking(tool.name, tool.summary(parsed.arguments)))
                        val allowed = approval.confirm(tool.name, tool.summary(parsed.arguments),
                            parsed.arguments.toString())
                        if (!allowed) {
                            val refusal = "The user refused this action."
                            transcript += TranscriptEntry.Refusal(tool.name, "user refused")
                            emit(Event.Refused(tool.name, "user refused"))
                            continue
                        }
                    }

                    val outcome = try {
                        tool.run(parsed.arguments, ToolContext(workspace, approval) { })
                    } catch (e: ToolArgumentException) {
                        ToolOutcome.fail(e.message ?: "bad arguments")
                    } catch (e: Exception) {
                        ToolOutcome.fail("${e.javaClass.simpleName}: ${e.message}")
                    }

                    transcript += TranscriptEntry.Observation(tool.name, outcome.ok, outcome.output)
                    emit(Event.Observation(tool.name, outcome.ok, outcome.output))

                    if (outcome.fatal) {
                        reason = StopReason.MODEL_ERROR
                        emit(Event.Failed(outcome.output))
                        break
                    }
                }
            }
        }

        if (reason == StopReason.STEP_LIMIT) {
            emit(Event.Failed("stopped after $maxSteps steps without a final answer"))
        }
        if (reason == StopReason.CANCELLED) {
            emit(Event.Failed("cancelled"))
        }
        lastResult = AgentResult(answer, transcript.size, transcript, reason)
    }

    /** The result of the most recent run, for callers that do not collect the flow. */
    @Volatile
    var lastResult: AgentResult? = null
        private set
}
