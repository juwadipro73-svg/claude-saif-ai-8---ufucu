/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.SecureRandom
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * SAIF AI's own local HTTP server.
 *
 * Written from scratch on a plain [ServerSocket]. It exists to solve one problem the app genuinely
 * has: a file it produces (a built APK, an exported project) has to be handed to another app — the
 * installer, a browser — and the only handle that works everywhere is an `http://` URL on loopback.
 *
 * So the server does three things and nothing else: serve a registered file once or twice, answer
 * `GET /ping` so callers can tell whether it is up, and report a 404 for anything else.
 *
 * It binds to loopback only, hands out single-use tokens instead of predictable paths, and expires
 * registrations on their own — a download link is a capability, so it should not last.
 */
class AndroidLocalBridgeServer private constructor() {

    private data class Registration(
        val file: File,
        val mime: String,
        val fileName: String,
        val expiresAtMs: Long
    )

    private val downloads = ConcurrentHashMap<String, Registration>()
    private val random = SecureRandom()
    private val pool = Executors.newCachedThreadPool { runnable ->
        Thread(runnable, "saif-bridge").apply { isDaemon = true }
    }

    @Volatile
    private var server: ServerSocket? = null

    @Volatile
    var boundPort: Int = DEFAULT_PORT
        private set

    @Volatile
    private var cliReady = false

    val isRunning: Boolean get() = server?.isClosed == false

    /**
     * Registers a file for download and returns the URL to open.
     *
     * The token is random rather than derived from the file name, so a link cannot be guessed from
     * knowing what the file is called.
     */
    fun registerDownloadFile(context: Context, file: File, desiredFileName: String? = null): String {
        expireOld()
        val rawName = (desiredFileName?.takeIf { it.isNotBlank() } ?: file.name)
        val ext = rawName.substringAfterLast('.', file.extension).lowercase(Locale.US)
        val mime = when (ext) {
            "apk" -> "application/vnd.android.package-archive"
            "zip" -> "application/zip"
            "json" -> "application/json"
            "txt", "log", "md" -> "text/plain; charset=utf-8"
            "html" -> "text/html; charset=utf-8"
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            else -> "application/octet-stream"
        }
        val token = newToken()
        downloads[token] = Registration(
            file = file,
            mime = mime,
            fileName = rawName,
            expiresAtMs = System.currentTimeMillis() + REGISTRATION_TTL_MS
        )
        return "http://127.0.0.1:$boundPort/d/$token"
    }

    /** Starts the server. Does nothing if it is already running. */
    fun start(context: Context, port: Int = DEFAULT_PORT) {
        if (isRunning) return
        synchronized(this) {
            if (isRunning) return
            val bindAddr = InetAddress.getByName("127.0.0.1")
            val socket = runCatching { ServerSocket(port, 50, bindAddr) }
                .getOrElse { ServerSocket(0, 50, bindAddr) }
            boundPort = socket.localPort
            server = socket
            pool.execute { acceptLoop(socket) }
        }
    }

    fun stop() {
        runCatching { server?.close() }
        server = null
        cliReady = false
    }

    /**
     * Makes sure the command-line tools are usable.
     *
     * Cheap and idempotent: on a device with a verified environment this is a no-op after the first
     * call, and where there is no environment at all it simply leaves the flag unset rather than
     * throwing — a missing shell is a capability the app loses, not a failure.
     */
    suspend fun ensureLinuxCliReady(context: Context) {
        if (cliReady) return
        withContext(Dispatchers.IO) {
            val app = context.applicationContext
            LocalEnvironmentManager.ensureInstalledInBackground(app)
            val bin = LocalEnvironmentManager.getBinDir(app)
            cliReady = bin.isDirectory && bin.listFiles()?.any { it.canExecute() } == true
            if (!cliReady) {
                LocalEnvironmentManager.log("Linux command line is not available on this device.")
            }
        }
    }

    // ---- Server -------------------------------------------------------------------------------

    private fun acceptLoop(socket: ServerSocket) {
        while (!socket.isClosed) {
            val client = try {
                socket.accept()
            } catch (_: Exception) {
                break
            }
            pool.execute {
                try {
                    client.soTimeout = 30_000
                    handle(client)
                } catch (_: Exception) {
                    // A broken client connection is not worth reporting.
                } finally {
                    runCatching { client.close() }
                }
            }
        }
    }

    private fun handle(client: Socket) {
        val input = client.getInputStream()
        val output = client.getOutputStream()

        val requestLine = readRequestLine(input) ?: return
        val parts = requestLine.split(" ")
        if (parts.size < 2) return
        val method = parts[0]
        val path = parts[1]

        // Drain the request headers so the client sees a well-formed exchange.
        readHeaders(input)

        when {
            path == "/ping" -> writeText(output, 200, "ok", "text/plain")
            path.startsWith("/d/") -> serveDownload(output, path.removePrefix("/d/"), method)
            else -> writeText(output, 404, "Not found", "text/plain")
        }
    }

    private fun serveDownload(output: OutputStream, token: String, method: String) {
        val registration = downloads[token]
        if (registration == null) {
            writeText(output, 404, "This link has expired.", "text/plain")
            return
        }
        if (System.currentTimeMillis() > registration.expiresAtMs) {
            downloads.remove(token)
            writeText(output, 410, "This link has expired.", "text/plain")
            return
        }
        val file = registration.file
        if (!file.isFile) {
            writeText(output, 404, "The file is no longer available.", "text/plain")
            return
        }

        if (method == "HEAD") {
            writeHead(output, 200, registration.mime, file.length(), headOnly = true)
            return
        }

        // Fetching a build artifact is expected to happen once; keeping the link alive afterwards
        // would only widen the window in which it can be reused.
        downloads.remove(token)
        writeHead(output, 200, registration.mime, file.length(), headOnly = false)
        FileInputStream(file).use { it.copyTo(output) }
        output.flush()
    }

    // ---- HTTP helpers -------------------------------------------------------------------------

    private fun readRequestLine(input: java.io.InputStream): String? {
        val builder = StringBuilder()
        while (true) {
            val byte = try {
                input.read()
            } catch (_: Exception) {
                return null
            }
            if (byte < 0) return null
            if (byte == '\n'.code) break
            if (byte != '\r'.code) builder.append(byte.toChar())
        }
        return builder.toString().trim().takeIf { it.isNotEmpty() }
    }

    private fun readHeaders(input: java.io.InputStream) {
        var blank = 0
        while (true) {
            val byte = try {
                input.read()
            } catch (_: Exception) {
                return
            }
            if (byte < 0) return
            if (byte == '\n'.code) {
                if (++blank >= 1) return
            } else if (byte != '\r'.code) {
                blank = 0
            }
        }
    }

    private fun writeHead(output: OutputStream, code: Int, mime: String, length: Long, headOnly: Boolean) {
        val reason = when (code) { 200 -> "OK"; 404 -> "Not Found"; 410 -> "Gone"; else -> "Error" }
        val head = buildString {
            append("HTTP/1.1 ").append(code).append(' ').append(reason).append("\r\n")
            append("Content-Type: ").append(mime).append("\r\n")
            append("Content-Length: ").append(length).append("\r\n")
            append("Cache-Control: no-store\r\n")
            append("Connection: close\r\n")
            append("\r\n")
        }
        output.write(head.toByteArray(Charsets.US_ASCII))
        if (headOnly) output.flush()
    }

    private fun writeText(output: OutputStream, code: Int, body: String, mime: String) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        writeHead(output, code, "$mime; charset=utf-8", bytes.size.toLong(), headOnly = false)
        output.write(bytes)
        output.flush()
    }

    private fun expireOld() {
        val now = System.currentTimeMillis()
        downloads.entries.removeIf { it.value.expiresAtMs < now }
    }

    private fun newToken(): String {
        val bytes = ByteArray(16)
        random.nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }
    }

    companion object {
        const val DEFAULT_PORT = 8931

        /** How long a download link stays valid. Long enough to open it, short enough to forget. */
        private val REGISTRATION_TTL_MS = TimeUnit.MINUTES.toMillis(30)

        val instance: AndroidLocalBridgeServer by lazy { AndroidLocalBridgeServer() }
    }
}
