/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. The app as distributed also contains third-party
 * GNU GPL v3 material - see LICENSE and THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.TextButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.saifcore.ChatMessage
import com.example.saifcore.MarkdownBlock
import com.example.saifcore.MessageRole
import com.example.saifcore.ToolCall
import com.example.saifcore.ToolStatus
import com.example.saifcore.ToolType

/**
 * The chat bubble and the block renderer for SAIF AI's own agent feed.
 *
 * Written from scratch. The palette is fixed here rather than themed, because these bubbles sit
 * inside a host screen whose own theme the feed cannot see; the colours are chosen to read correctly
 * on both the light and dark surfaces the app uses.
 */
private val Accent = Color(0xFF7C5CE0)
private val UserBubble = Color(0xFF2F2E2C)
private val AssistantSurface = Color(0xFF1A1918)
private val AssistantBorder = Color(0x33FFFFFF)
private val OnDark = Color(0xFFF4F3F0)
private val Muted = Color(0xFFA8A59B)
private val OkGreen = Color(0xFF22C55E)
private val FailRed = Color(0xFFEF4444)

/**
 * One message, rendered as a bubble.
 *
 * This is the entry point the host screens use, so it takes only the message and the model id —
 * every decision about how to lay the message out is made here.
 */
@Composable
fun MessageBubble(
    message: ChatMessage,
    modelId: String = "",
    modifier: Modifier = Modifier,
    onRetry: (() -> Unit)? = null
) {
    Column(modifier = modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
        when (message.role) {
            MessageRole.USER -> UserBubble(message)
            MessageRole.SUMMARY -> SummaryBubble(message)
            MessageRole.ASSISTANT -> AssistantBubble(message, modelId, onRetry)
            MessageRole.TOOL,
            MessageRole.SYSTEM -> SystemLine(message)
        }
    }
}

@Composable
private fun UserBubble(message: ChatMessage) {
    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = UserBubble,
            modifier = Modifier.padding(start = 48.dp)
        ) {
            Text(
                text = message.content,
                color = OnDark,
                fontSize = 15.sp,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
            )
        }
    }
}

@Composable
private fun SummaryBubble(message: ChatMessage) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = AssistantSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, AssistantBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text("Earlier conversation", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text(
                text = message.content,
                color = Muted,
                fontSize = 13.sp,
                lineHeight = 19.sp
            )
        }
    }
}

@Composable
private fun SystemLine(message: ChatMessage) {
    Text(
        text = message.content,
        color = Muted,
        fontSize = 12.5.sp,
        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
    )
}

@Composable
private fun AssistantBubble(message: ChatMessage, modelId: String, onRetry: (() -> Unit)?) {
    Column(modifier = Modifier.fillMaxWidth().padding(end = 24.dp)) {
        if (!message.thoughtText.isNullOrBlank()) {
            ThinkingAccordion(
                thought = message.thoughtText,
                durationMs = message.thoughtDurationMs,
                isStreaming = message.isStreaming
            )
        }

        if (message.content.isNotBlank()) {
            val blocks = remember(message.id, message.content) {
                com.example.saifcore.MarkdownParser.splitThought(message.content).second
                    .let { com.example.saifcore.MarkdownParser.parse(it, emptyList()) }
            }
            blocks.forEach { block ->
                MarkdownBlockView(block = block)
            }
        }

        message.toolCalls.forEach { tool ->
            ToolCardView(tool = tool)
        }

        if (message.isStreaming && message.content.isBlank() && message.toolCalls.isEmpty()) {
            ModelTypingIndicator(modelId = message.modelId ?: modelId)
        }

        if (!message.isStreaming && message.content.isNotBlank()) {
            AssistantFooter(message = message, modelId = message.modelId ?: modelId, onRetry = onRetry)
        }
    }
}

// ---- Blocks -----------------------------------------------------------------------------------

/** Renders one parsed markdown block. */
@Composable
fun MarkdownBlockView(block: MarkdownBlock, modifier: Modifier = Modifier) {
    when (block) {
        is MarkdownBlock.Text -> Text(
            text = block.text,
            color = OnDark,
            fontSize = 15.sp,
            lineHeight = 22.sp,
            modifier = modifier.padding(vertical = 4.dp)
        )

        is MarkdownBlock.Heading -> Text(
            text = block.text,
            color = OnDark,
            fontSize = (22 - (block.level * 2)).coerceAtLeast(15).sp,
            fontWeight = FontWeight.Bold,
            modifier = modifier.padding(top = 12.dp, bottom = 6.dp)
        )

        is MarkdownBlock.CodeBlock -> CodeBlockView(language = block.language, code = block.code, modifier = modifier)

        is MarkdownBlock.ListBlock -> Column(modifier = modifier.padding(vertical = 4.dp)) {
            block.items.forEachIndexed { index, item ->
                Row(modifier = Modifier.padding(vertical = 2.dp)) {
                    Text(
                        text = if (block.ordered) "${index + 1}." else "•",
                        color = Accent,
                        fontSize = 14.sp,
                        modifier = Modifier.width(22.dp)
                    )
                    Text(text = item, color = OnDark, fontSize = 15.sp, lineHeight = 21.sp, modifier = Modifier.weight(1f))
                }
            }
        }

        is MarkdownBlock.Quote -> Surface(
            shape = RoundedCornerShape(10.dp),
            color = AssistantSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, AssistantBorder),
            modifier = modifier.fillMaxWidth().padding(vertical = 4.dp)
        ) {
            Text(
                text = block.text,
                color = Muted,
                fontSize = 14.sp,
                lineHeight = 21.sp,
                modifier = Modifier.padding(12.dp)
            )
        }

        MarkdownBlock.Rule -> Box(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp)
                .height(1.dp)
                .background(AssistantBorder)
        )

        is MarkdownBlock.Table -> TableView(headers = block.headers, rows = block.rows, modifier = modifier)

        is MarkdownBlock.ToolCard -> ToolCardView(tool = block.tool, modifier = modifier)
    }
}

@Composable
private fun CodeBlockView(language: String, code: String, modifier: Modifier = Modifier) {
    val clipboard = LocalClipboardManager.current
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF121110),
        border = androidx.compose.foundation.BorderStroke(1.dp, AssistantBorder),
        modifier = modifier.fillMaxWidth().padding(vertical = 6.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = language.ifBlank { "code" },
                    color = Muted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = { clipboard.setText(AnnotatedString(code)) },
                    modifier = Modifier.size(26.dp)
                ) {
                    Icon(Icons.Outlined.ContentCopy, contentDescription = "Copy code", tint = Muted, modifier = Modifier.size(15.dp))
                }
            }
            Box(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                Text(
                    text = code,
                    color = OnDark,
                    fontSize = 12.5.sp,
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 18.sp,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun TableView(headers: List<String>, rows: List<List<String>>, modifier: Modifier = Modifier) {
    Box(modifier = modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp)) {
        Column {
            Row(modifier = Modifier.background(AssistantSurface).padding(8.dp)) {
                headers.forEach { header ->
                    Text(
                        text = header,
                        color = Accent,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.width(140.dp).padding(end = 8.dp)
                    )
                }
            }
            rows.forEach { row ->
                Row(modifier = Modifier.padding(8.dp)) {
                    row.forEach { cell ->
                        Text(
                            text = cell,
                            color = OnDark,
                            fontSize = 13.sp,
                            modifier = Modifier.width(140.dp).padding(end = 8.dp)
                        )
                    }
                }
            }
        }
    }
}

// ---- Tool cards -------------------------------------------------------------------------------

/** One tool call: what it did, its state, and its output. */
@Composable
fun ToolCardView(
    tool: ToolCall,
    modifier: Modifier = Modifier,
    onApprove: (() -> Unit)? = null,
    onReject: (() -> Unit)? = null,
    onTerminate: (() -> Unit)? = null
) {
    var expanded by remember(tool.id) { mutableStateOf(tool.status == ToolStatus.FAILED) }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = AssistantSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, statusColor(tool.status).copy(alpha = 0.45f)),
        modifier = modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(statusColor(tool.status))
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = toolLabel(tool),
                    color = OnDark,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = tool.status.lowercase().replace('_', ' '),
                    color = statusColor(tool.status),
                    fontSize = 11.sp
                )
            }

            if (tool.command.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    text = tool.command,
                    color = Muted,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    maxLines = if (expanded) Int.MAX_VALUE else 3
                )
            }

            if (tool.output.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = if (expanded) 320.dp else 90.dp)
                        .verticalScroll(rememberScrollState())
                        .background(Color(0xFF121110), RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = tool.output,
                        color = OnDark,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 17.sp
                    )
                }
            }

            if (onApprove != null || onReject != null || onTerminate != null) {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    onApprove?.let {
                        androidx.compose.material3.Button(onClick = it) { Text("Allow", color = OnDark) }
                    }
                    onReject?.let {
                        androidx.compose.material3.OutlinedButton(onClick = it) { Text("Deny") }
                    }
                    onTerminate?.let {
                        androidx.compose.material3.TextButton(onClick = it) { Text("Stop") }
                    }
                }
            }

            if (tool.output.length > 120 || tool.command.length > 120) {
                Text(
                    text = if (expanded) "Show less" else "Show more",
                    color = Accent,
                    fontSize = 12.sp,
                    modifier = Modifier
                        .padding(top = 6.dp)
                        .clickable { expanded = !expanded }
                )
            }
        }
    }
}

private fun statusColor(status: String): Color = when (status) {
    ToolStatus.SUCCESS -> OkGreen
    ToolStatus.FAILED -> FailRed
    ToolStatus.TERMINATED -> Muted
    ToolStatus.PENDING_APPROVAL, ToolStatus.AWAITING_CHOICE -> Color(0xFFF59E0B)
    else -> Accent
}

private fun toolLabel(tool: ToolCall): String = when (tool.toolType) {
    ToolType.BASH -> "Running a command"
    ToolType.VIEW_FILE -> "Reading a file"
    ToolType.EDIT_FILE -> "Editing a file"
    ToolType.LIST_DIR -> "Listing a folder"
    ToolType.GREP_SEARCH -> "Searching the workspace"
    ToolType.FIND -> "Finding files"
    ToolType.SEARCH_WEB -> "Searching the web"
    ToolType.READ_URL -> "Opening a web page"
    ToolType.GENERATE_IMAGE -> "Generating an image"
    ToolType.MCP -> "Using ${tool.name.substringAfterLast("__")}"
    ToolType.ASK_CHOICE -> "Asking you to choose"
    ToolType.MATH -> "Calculating"
    ToolType.SYSTEM_NOTIFICATION -> "System notice"
    ToolType.UNKNOWN -> tool.name
}

// ---- Extras -----------------------------------------------------------------------------------

/** The model's reasoning passage, collapsed by default so it does not crowd the answer. */
@Composable
fun ThinkingAccordion(thought: String, durationMs: Long? = null, isStreaming: Boolean = false) {
    var expanded by remember { mutableStateOf(false) }
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = AssistantSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, AssistantBorder),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.clickable { expanded = !expanded },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (expanded) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                    contentDescription = null,
                    tint = Accent,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = if (isStreaming) "Thinking…" else "Thought${durationMs?.let { " (${it / 1000}s)" } ?: ""}",
                    color = Accent,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
            }
            if (expanded) {
                Spacer(Modifier.height(8.dp))
                Text(text = thought, color = Muted, fontSize = 13.sp, lineHeight = 20.sp)
            }
        }
    }
}

/** The animated dots shown while a reply is on its way. */
@Composable
fun ModelTypingIndicator(modelId: String = "") {
    val transition = rememberInfiniteTransition(label = "typing")
    val alpha by transition.animateFloat(
        initialValue = 0.25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "typingAlpha"
    )
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 8.dp)
    ) {
        Text(text = "•", color = Accent.copy(alpha = alpha), fontSize = 26.sp)
        Spacer(Modifier.width(2.dp))
        Text(text = "•", color = Accent.copy(alpha = alpha.coerceIn(0.25f, 0.75f)), fontSize = 26.sp)
        Spacer(Modifier.width(2.dp))
        Text(text = "•", color = Accent.copy(alpha = 0.25f), fontSize = 26.sp)
        if (modelId.isNotBlank()) {
            Spacer(Modifier.width(10.dp))
            Text(text = modelId, color = Muted, fontSize = 11.5.sp)
        }
    }
}

/** Copy / retry row under a finished reply. */
@Composable
fun AssistantFooter(message: ChatMessage, modelId: String = "", onRetry: (() -> Unit)? = null) {
    val clipboard = LocalClipboardManager.current
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(top = 6.dp)
    ) {
        IconButton(onClick = { clipboard.setText(AnnotatedString(message.content)) }, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Outlined.ContentCopy, contentDescription = "Copy", tint = Muted, modifier = Modifier.size(15.dp))
        }
        if (onRetry != null) {
            IconButton(onClick = onRetry, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Outlined.Refresh, contentDescription = "Retry", tint = Muted, modifier = Modifier.size(15.dp))
            }
        }
        Spacer(Modifier.width(6.dp))
        message.tokenUsage?.let { usage ->
            Text(
                text = "${usage.totalTokens} tokens",
                color = Muted,
                fontSize = 11.sp
            )
        }
        if (modelId.isNotBlank()) {
            Spacer(Modifier.width(8.dp))
            Text(text = modelId, color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
        }
    }
}

/** A labelled divider between days or between models. */
@Composable
fun WaveDivider(label: String, modifier: Modifier = Modifier) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier.fillMaxWidth().padding(vertical = 12.dp)
    ) {
        Box(modifier = Modifier.weight(1f).height(1.dp).background(AssistantBorder))
        Text(
            text = label,
            color = Muted,
            fontSize = 11.5.sp,
            modifier = Modifier.padding(horizontal = 10.dp)
        )
        Box(modifier = Modifier.weight(1f).height(1.dp).background(AssistantBorder))
    }
}

/** The spinner shown while the agent is working between messages. */
@Composable
fun AgentWorkingSpinner(color: Color = Accent, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "working")
    val scale by transition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(600), RepeatMode.Reverse),
        label = "workingScale"
    )
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
        modifier = modifier.fillMaxWidth().padding(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size((10 * scale).dp)
                .clip(RoundedCornerShape(50))
                .background(color)
        )
        Spacer(Modifier.width(10.dp))
        Text(text = "Working…", color = Muted, fontSize = 12.5.sp)
    }
}

/** Material theme fallback used by the panels; kept so the screens compile without a host theme. */
@Composable
internal fun themedSurfaceColor(): Color = MaterialTheme.colorScheme.surface
