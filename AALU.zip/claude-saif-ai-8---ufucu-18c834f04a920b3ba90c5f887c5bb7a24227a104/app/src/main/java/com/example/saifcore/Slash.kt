/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. The app as distributed also contains third-party
 * GNU GPL v3 material - see LICENSE and THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Slash commands: what the user types after `/`, and how it expands.
 *
 * Written from scratch. Two rules shape the whole file:
 *
 *  - **A command is only expanded at the start of the message.** `/review fix this` expands; a
 *    sentence mentioning `/review` mid-way does not. That is what [SkillSlashParsing.parse] decides.
 *  - **What the user typed is what the feed shows**, even though the model receives the expanded
 *    instructions. [PromptExpansion.collapse] reverses the expansion for display, so a command never
 *    silently rewrites the conversation in front of the user.
 */

object SkillSlashParsing {

    /** A command the user actually invoked: its name and the text that follows it. */
    data class Invocation(val command: String, val task: String)

    private val LEADING = Regex("^/([A-Za-z0-9_.-]+)\\s*(.*)$", RegexOption.DOT_MATCHES_ALL)

    /** Reads a leading `/command rest` out of [text]. Null when the text is not an invocation. */
    fun parse(text: String): Invocation? {
        val match = LEADING.find(text.trimStart()) ?: return null
        return Invocation(
            command = match.groupValues[1],
            task = match.groupValues[2].trim()
        )
    }

    /**
     * The partial command being typed at the end of [text], for the suggestion overlay.
     *
     * Returns null as soon as the fragment contains a space — that means the command name is
     * finished and the user has moved on to the task.
     */
    fun query(text: String): String? {
        val trimmed = text.trimStart()
        if (!trimmed.startsWith("/")) return null
        val fragment = trimmed.substring(1)
        if (fragment.isEmpty()) return ""
        if (fragment.any { it.isWhitespace() }) return null
        if (!fragment.all { it.isLetterOrDigit() || it == '_' || it == '-' || it == '.' }) return null
        return fragment
    }
}

/** The commands SAIF AI ships with, plus any the user has saved. */
object SlashCommandsCache {

    /**
     * Built-in commands.
     *
     * Deliberately small and stable: these are the ones worth learning by heart, and each maps to a
     * behaviour the app already has rather than to a prompt the model might obey differently.
     */
    private val builtIn = listOf(
        SlashCommandItem("Clear", "clear", "Start a fresh conversation.", type = "command"),
        SlashCommandItem("Compact", "compact", "Summarise the conversation so far and continue.", type = "command"),
        SlashCommandItem("Explain", "explain", "Explain the code or the last answer in plain language.", type = "command"),
        SlashCommandItem("Review", "review", "Review the current workspace for bugs and risks.", type = "command"),
        SlashCommandItem("Test", "test", "Write and run tests for the current change.", type = "command"),
        SlashCommandItem("Fix", "fix", "Fix the failing build or test.", type = "command"),
        SlashCommandItem("Commit", "commit", "Write a commit message for the staged changes.", type = "command"),
        SlashCommandItem("Help", "help", "List every available command.", type = "command")
    )

    @Volatile
    private var cached: List<SlashCommandItem> = builtIn

    /** Everything currently available: built-ins first, then the user's saved skills. */
    @Synchronized
    fun getCommands(): List<SlashCommandItem> {
        cached = builtIn + SavedAiSkills.suggestions("")
        return cached
    }

    /** The last computed list, without refreshing it. Safe to call from the input bar on every key. */
    fun getCachedSync(): List<SlashCommandItem> = cached

    /** Commands matching [query], for the overlay. */
    fun match(query: String): List<SlashCommandItem> {
        val all = getCommands()
        if (query.isBlank()) return all
        val q = query.lowercase()
        return all.filter {
            it.name.lowercase().contains(q) ||
                it.command.lowercase().contains(q) ||
                it.description.lowercase().contains(q)
        }
    }

    /** Re-reads the command list. Call after the user saves, renames or deletes a skill. */
    fun refresh() {
        getCommands()
    }
}

/**
 * User-defined slash commands.
 *
 * Stored as one JSON file per account inside the app's private files, so commands follow the account
 * that made them and never leak into another user's session. Loading is lazy and idempotent: calling
 * [init] repeatedly is how the app re-binds after a sign-in change.
 */
object CustomSlashCommands {

    private const val FILE_NAME = "custom_slash_commands.json"

    @Volatile
    private var loaded = false

    @Volatile
    private var items: List<SlashCommandItem> = emptyList()

    fun init(context: Context) {
        if (loaded) return
        val file = File(context.applicationContext.filesDir, FILE_NAME)
        if (!file.isFile) {
            items = emptyList()
            loaded = true
            return
        }
        items = runCatching {
            val array = JSONArray(file.readText())
            (0 until array.length()).mapNotNull { i ->
                val obj = array.optJSONObject(i) ?: return@mapNotNull null
                SlashCommandItem(
                    name = obj.optString("name").ifBlank { return@mapNotNull null },
                    command = obj.optString("command").ifBlank { obj.optString("name") },
                    description = obj.optString("description"),
                    type = obj.optString("type", "command"),
                    argumentHint = obj.optString("argumentHint")
                )
            }
        }.getOrDefault(emptyList())
        loaded = true
        SlashCommandsCache.refresh()
    }

    fun all(): List<SlashCommandItem> = items

    fun find(command: String): SlashCommandItem? =
        items.firstOrNull { it.command.equals(command, ignoreCase = true) }

    fun save(context: Context, next: List<SlashCommandItem>): Boolean {
        val file = File(context.applicationContext.filesDir, FILE_NAME)
        return runCatching {
            val array = JSONArray()
            next.forEach {
                array.put(
                    JSONObject()
                        .put("name", it.name)
                        .put("command", it.command)
                        .put("description", it.description)
                        .put("type", it.type)
                        .put("argumentHint", it.argumentHint)
                )
            }
            val tmp = File(file.parentFile, "$FILE_NAME.tmp")
            tmp.writeText(array.toString(2))
            if (!tmp.renameTo(file)) file.writeText(array.toString(2))
            items = next
            SlashCommandsCache.refresh()
            true
        }.getOrDefault(false)
    }
}

/**
 * Turns a typed slash command into the instructions the model actually receives.
 *
 * The expansion is a plain wrapper — the command's text, then the user's task — rather than a
 * template language. That keeps a command's behaviour readable in one place and makes [collapse]
 * reliable, since the unexpanded form is always recoverable.
 */
object PromptExpansion {

    /** Marks an expansion in the text that goes to the model, so it can be collapsed for display. */
    private const val MARKER_PREFIX = "<!-- slash:"
    private const val MARKER_SUFFIX = " -->"

    /** The entries shown in the overlay before any search: built-ins and saved skills. */
    fun baseSlashItems(): List<SlashCommandItem> = SlashCommandsCache.getCommands()

    /** Expands a leading `/command task` into the text sent to the model. */
    fun expand(prompt: String): String {
        val invocation = SkillSlashParsing.parse(prompt) ?: return prompt
        val command = SlashCommandsCache.getCommands().firstOrNull {
            it.command.equals(invocation.command, ignoreCase = true)
        } ?: return prompt

        val body = commandBody(command)
        val task = invocation.task
        val expanded = buildString {
            append(MARKER_PREFIX).append(command.command).append(MARKER_SUFFIX).append('\n')
            append(body)
            if (task.isNotBlank()) {
                append('\n').append('\n')
                append("Now do this:\n").append(task)
            }
        }
        return expanded
    }

    /** Reverses [expand] for display: returns what the user typed. */
    fun collapse(content: String): String {
        if (!content.startsWith(MARKER_PREFIX)) return content
        val end = content.indexOf(MARKER_SUFFIX)
        if (end < 0) return content
        val command = content.substring(MARKER_PREFIX.length, end).trim()
        val rest = content.substring(end + MARKER_SUFFIX.length).trimStart()

        // Everything after the command body is the user's own task, if any.
        val taskMarker = "\n\nNow do this:\n"
        val taskIndex = rest.indexOf(taskMarker)
        val task = if (taskIndex >= 0) rest.substring(taskIndex + taskMarker.length).trim() else ""

        return if (task.isBlank()) "/$command" else "/$command $task"
    }

    /** Where each `/command` appears in [text], for highlighting it in the user's own bubble. */
    fun commandRanges(text: String): List<IntRange> {
        val ranges = mutableListOf<IntRange>()
        var index = text.indexOf('/')
        while (index >= 0) {
            val isStart = index == 0 || text[index - 1].isWhitespace()
            if (isStart) {
                var end = index + 1
                while (end < text.length && (text[end].isLetterOrDigit() || text[end] == '_' || text[end] == '-')) end++
                if (end > index + 1) ranges.add(index until end)
                index = text.indexOf('/', end)
            } else {
                index = text.indexOf('/', index + 1)
            }
        }
        return ranges
    }

    private fun commandBody(command: SlashCommandItem): String {
        val description = command.description.trim()
        val base = buildString {
            append("Follow this saved instruction: ").append(command.name).append('.')
            if (description.isNotBlank()) {
                append(' ').append(description)
            }
        }
        val skill = SavedAiSkills.find(command.command)
        return if (skill != null && skill.instructions.isNotBlank()) {
            "$base\n\n${skill.instructions}"
        } else {
            base
        }
    }
}
