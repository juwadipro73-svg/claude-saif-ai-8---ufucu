/*
 * Copyright (c) SAIF AI. All rights reserved.
 *
 * Original code written for SAIF AI. Distributed as part of the SAIF AI app, which ships
 * under the GNU GPL v3 (see LICENSE and THIRD_PARTY_NOTICES.md).
 */

package com.example.terminal

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** What kind of terminal backend a provider is. */
enum class TerminalProviderKind {
    /** SAIF AI's own Antigravity workspace: the in-app bridge does the work, no key needed here. */
    ANTIGRAVITY,

    /** Any OpenAI-compatible chat-completions endpoint the user points us at. */
    OPENAI_COMPATIBLE,

    /** Anthropic messages API. */
    ANTHROPIC
}

/**
 * Where a provider's terminal command comes from.
 *
 * Most coding agents publish a real CLI, and SAIF AI installs that inside its Linux environment so
 * the command behaves exactly as it would on a laptop. A few services have no CLI at all - they are
 * only reachable over their API - and for those SAIF AI writes an OpenAI-compatible launcher
 * instead of pretending to install something that does not exist.
 */
enum class TerminalCliSource {
    /** Nothing to install: SAIF AI's own bridge answers for it. */
    BUILT_IN,

    /** A Node.js package, installed with npm. */
    NPM,

    /** A Python package, installed with pip. */
    PIP,

    /** No CLI exists; the provider is driven through its API URL. */
    URL_ONLY
}

/**
 * One terminal provider the user can pick.
 *
 * [cliCommand] is the command SAIF AI writes into the Linux environment so the same provider is
 * reachable from a terminal session as well.
 */
data class TerminalProvider(
    val id: String,
    val name: String,
    val tagline: String,
    val description: String,
    val kind: TerminalProviderKind,
    val cliCommand: String,
    val apiBaseUrl: String = "",
    val defaultModel: String = "",
    /** Empty when the provider needs no key (Antigravity uses the app's own sign-in). */
    val authHint: String = "",
    /** How SAIF AI obtains the real CLI inside its Linux environment. */
    val cliSource: TerminalCliSource = TerminalCliSource.URL_ONLY,
    /** The npm or pip package to install. Blank when [cliSource] needs none. */
    val cliPackage: String = "",
    val isCustom: Boolean = false
) {
    fun needsApiKey(): Boolean = kind != TerminalProviderKind.ANTIGRAVITY

    /** True when a real CLI gets installed, rather than an API launcher being written. */
    fun installsCli(): Boolean = cliSource == TerminalCliSource.NPM || cliSource == TerminalCliSource.PIP
}

/**
 * The single source of truth for terminal providers: the built-in list, the user's own custom
 * providers, which one is active, and each provider's API key.
 *
 * Keys are encrypted with the same Android Keystore vault the rest of SAIF AI uses
 * (`com.example.llm.KeyStoreCrypto`); they are only ever decrypted in memory.
 */
object TerminalProviders {

    private const val PREFS = "saif_terminal_providers"
    private const val KEY_SELECTED = "selected_provider_id"
    private const val KEY_CUSTOM = "custom_providers"
    private const val KEY_KEYS = "provider_keys"
    private const val KEY_URLS = "provider_urls"
    private const val KEY_MODELS = "provider_models"
    private const val KEY_SHARED = "shared_keys"

    /** Built-in providers. Their URLs/models are starting points the user may edit. */
    /**
     * Built-in providers. Their URLs and models are starting points the user may edit.
     *
     * The ones with a real CLI list the package that provides it, so picking one installs the same
     * command a developer would install on a laptop. The rest are services that publish no CLI -
     * Arena, for instance - and for those SAIF AI writes an API launcher instead, because inventing
     * an install step for something that does not exist would only produce a failure later.
     */
    val BUILT_IN: List<TerminalProvider> = listOf(
        TerminalProvider(
            id = "antigravity",
            name = "Antigravity",
            tagline = "SAIF AI's own agent workspace",
            description = "Uses the Antigravity account you connect inside SAIF AI. No extra API key: chat, "
                + "terminal, code editing and file tools all come from the in-app bridge.",
            kind = TerminalProviderKind.ANTIGRAVITY,
            cliCommand = "agy",
            cliSource = TerminalCliSource.BUILT_IN,
            authHint = "Sign in from Settings → Antigravity Connection"
        ),
        TerminalProvider(
            id = "opencode",
            name = "OpenCode",
            tagline = "Open-source coding agent",
            description = "The OpenCode CLI, installed into SAIF AI's Linux environment and ready in one tap. "
                + "OpenCode Zen lists free models, so a key from their site is enough to start.",
            kind = TerminalProviderKind.OPENAI_COMPATIBLE,
            cliCommand = "opencode",
            cliSource = TerminalCliSource.NPM,
            cliPackage = "opencode-ai",
            apiBaseUrl = "https://opencode.ai/api/v1",
            defaultModel = "opencode/big-pickle",
            authHint = "OpenCode API key (opencode.ai)"
        ),
        TerminalProvider(
            id = "gemini-cli",
            name = "Gemini CLI",
            tagline = "Google's command-line agent",
            description = "Google's Gemini CLI, installed with npm. Uses Gemini's OpenAI-compatible "
                + "endpoint, so one API key covers chat, agents and the terminal.",
            kind = TerminalProviderKind.OPENAI_COMPATIBLE,
            cliCommand = "gemini",
            cliSource = TerminalCliSource.NPM,
            cliPackage = "@google/gemini-cli",
            apiBaseUrl = "https://generativelanguage.googleapis.com/v1beta/openai",
            defaultModel = "gemini-2.5-flash",
            authHint = "Google AI Studio API key"
        ),
        TerminalProvider(
            id = "qwen-code",
            name = "Qwen Code",
            tagline = "Alibaba's coding agent",
            description = "Qwen Code, installed with npm and pointed at DashScope's OpenAI-compatible "
                + "endpoint.",
            kind = TerminalProviderKind.OPENAI_COMPATIBLE,
            cliCommand = "qwen",
            cliSource = TerminalCliSource.NPM,
            cliPackage = "@qwen-code/qwen-code",
            apiBaseUrl = "https://dashscope-intl.aliyuncs.com/compatible-mode/v1",
            defaultModel = "qwen-plus",
            authHint = "DashScope API key"
        ),
        TerminalProvider(
            id = "claude",
            name = "Claude Code",
            tagline = "Anthropic Claude Code",
            description = "Run Claude Code inside SAIF AI's Linux terminal. SAIF AI writes the launcher and "
                + "keeps it working across Claude's own updates.",
            kind = TerminalProviderKind.ANTHROPIC,
            cliCommand = "claude",
            cliSource = TerminalCliSource.NPM,
            cliPackage = "@anthropic-ai/claude-code",
            apiBaseUrl = "https://api.anthropic.com/v1",
            defaultModel = "claude-sonnet-4-5",
            authHint = "Anthropic API key"
        ),
        TerminalProvider(
            id = "codex",
            name = "Codex CLI",
            tagline = "OpenAI Codex CLI",
            description = "Run the Codex CLI against your OpenAI-compatible endpoint, prepared automatically "
                + "in the background after you pick it.",
            kind = TerminalProviderKind.OPENAI_COMPATIBLE,
            cliCommand = "codex",
            cliSource = TerminalCliSource.NPM,
            cliPackage = "@openai/codex",
            apiBaseUrl = "https://api.openai.com/v1",
            defaultModel = "gpt-5-codex",
            authHint = "OpenAI API key"
        ),
        TerminalProvider(
            id = "amp",
            name = "Amp",
            tagline = "Sourcegraph's coding agent",
            description = "Sourcegraph's Amp CLI, installed with npm and driven with your own key.",
            kind = TerminalProviderKind.OPENAI_COMPATIBLE,
            cliCommand = "amp",
            cliSource = TerminalCliSource.NPM,
            cliPackage = "@sourcegraph/amp",
            apiBaseUrl = "https://ampcode.com/api/v1",
            defaultModel = "amp-default",
            authHint = "Amp API key"
        ),
        TerminalProvider(
            id = "copilot",
            name = "Copilot CLI",
            tagline = "GitHub's command-line agent",
            description = "GitHub's Copilot CLI, installed with npm. Sign in with your GitHub account on "
                + "their site and paste the key here.",
            kind = TerminalProviderKind.OPENAI_COMPATIBLE,
            cliCommand = "copilot",
            cliSource = TerminalCliSource.NPM,
            cliPackage = "@github/copilot",
            apiBaseUrl = "https://api.githubcopilot.com",
            defaultModel = "gpt-4o",
            authHint = "GitHub Copilot API key"
        ),
        TerminalProvider(
            id = "aider",
            name = "Aider",
            tagline = "Pair-programming in a terminal",
            description = "Aider, installed with pip. Works with the model provider whose key you enter.",
            kind = TerminalProviderKind.OPENAI_COMPATIBLE,
            cliCommand = "aider",
            cliSource = TerminalCliSource.PIP,
            cliPackage = "aider-chat",
            apiBaseUrl = "https://api.openai.com/v1",
            defaultModel = "gpt-4o",
            authHint = "API key for your model provider"
        ),
        TerminalProvider(
            id = "arena",
            name = "Arena AI",
            tagline = "Arena.ai agent runtime",
            description = "Arena publishes no command-line tool, so SAIF AI reaches it through its "
                + "OpenAI-compatible URL instead: enter your endpoint and key and it behaves like any "
                + "other provider in chat and agents.",
            kind = TerminalProviderKind.OPENAI_COMPATIBLE,
            cliCommand = "arena",
            cliSource = TerminalCliSource.URL_ONLY,
            apiBaseUrl = "https://api.arena.ai/v1",
            defaultModel = "arena-auto",
            authHint = "Arena AI API key"
        )
    )

    private var prefs: android.content.SharedPreferences? = null

    fun init(context: Context) {
        prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }

    private fun store(context: Context): android.content.SharedPreferences {
        if (prefs == null) init(context)
        return prefs!!
    }

    private fun readCustom(context: Context): List<TerminalProvider> {
        val raw = store(context).getString(KEY_CUSTOM, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { i ->
                val o = array.optJSONObject(i) ?: return@mapNotNull null
                val id = o.optString("id")
                if (id.isBlank()) return@mapNotNull null
                TerminalProvider(
                    id = id,
                    name = o.optString("name", id),
                    tagline = o.optString("tagline", "Custom provider"),
                    description = o.optString("description", "Provider you added yourself."),
                    kind = runCatching { TerminalProviderKind.valueOf(o.optString("kind", "OPENAI_COMPATIBLE")) }
                        .getOrDefault(TerminalProviderKind.OPENAI_COMPATIBLE),
                    cliCommand = o.optString("cliCommand", id),
                    apiBaseUrl = o.optString("apiBaseUrl", ""),
                    defaultModel = o.optString("defaultModel", ""),
                    authHint = o.optString("authHint", "Your API key"),
                    // A provider someone added by pasting a URL has no CLI to install.
                    cliSource = TerminalCliSource.URL_ONLY,
                    cliPackage = "",
                    isCustom = true
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun writeCustom(context: Context, list: List<TerminalProvider>) {
        val array = JSONArray()
        list.forEach { p ->
            array.put(JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("tagline", p.tagline)
                put("description", p.description)
                put("kind", p.kind.name)
                put("cliCommand", p.cliCommand)
                put("apiBaseUrl", p.apiBaseUrl)
                put("defaultModel", p.defaultModel)
                put("authHint", p.authHint)
            })
        }
        store(context).edit().putString(KEY_CUSTOM, array.toString()).apply()
    }

    /** Every provider: the built-ins plus the user's own, with any edited URL/model applied. */
    fun all(context: Context): List<TerminalProvider> {
        val urls = JSONObject(store(context).getString(KEY_URLS, "{}") ?: "{}")
        val models = JSONObject(store(context).getString(KEY_MODELS, "{}") ?: "{}")
        return (BUILT_IN + readCustom(context)).map { p ->
            val url = urls.optString(p.id)
            val model = models.optString(p.id)
            p.copy(
                apiBaseUrl = if (url.isNotBlank()) url else p.apiBaseUrl,
                defaultModel = if (model.isNotBlank()) model else p.defaultModel
            )
        }
    }

    fun find(context: Context, id: String): TerminalProvider? =
        all(context).firstOrNull { it.id.equals(id, ignoreCase = true) }

    /** The active provider. Falls back to Antigravity until the user picks one. */
    fun selected(context: Context): TerminalProvider {
        val id = store(context).getString(KEY_SELECTED, null)
        return all(context).firstOrNull { it.id.equals(id, ignoreCase = true) } ?: BUILT_IN.first()
    }

    /** True once the user has actively chosen a provider (the post-sign-in screen is then not shown). */
    fun hasChosenProvider(context: Context): Boolean =
        !store(context).getString(KEY_SELECTED, null).isNullOrBlank()

    fun select(context: Context, id: String) {
        store(context).edit().putString(KEY_SELECTED, id).apply()
    }

    fun apiKey(context: Context, id: String): String {
        val obj = JSONObject(store(context).getString(KEY_KEYS, "{}") ?: "{}")
        val raw = obj.optString(id)
        if (raw.isBlank()) return ""
        return runCatching { com.example.llm.KeyStoreCrypto.decrypt(raw) }.getOrElse { raw }
    }

    fun setApiKey(context: Context, id: String, key: String) {
        val obj = JSONObject(store(context).getString(KEY_KEYS, "{}") ?: "{}")
        if (key.isBlank()) obj.remove(id)
        else obj.put(id, runCatching { com.example.llm.KeyStoreCrypto.encrypt(key.trim()) }.getOrDefault(key.trim()))
        store(context).edit().putString(KEY_KEYS, obj.toString()).apply()
    }

    fun setBaseUrl(context: Context, id: String, url: String) {
        val obj = JSONObject(store(context).getString(KEY_URLS, "{}") ?: "{}")
        if (url.isBlank()) obj.remove(id) else obj.put(id, url.trim())
        store(context).edit().putString(KEY_URLS, obj.toString()).apply()
    }

    fun setModel(context: Context, id: String, model: String) {
        val obj = JSONObject(store(context).getString(KEY_MODELS, "{}") ?: "{}")
        if (model.isBlank()) obj.remove(id) else obj.put(id, model.trim())
        store(context).edit().putString(KEY_MODELS, obj.toString()).apply()
    }

    /**
     * Whether a copy of the key may be placed inside the Linux sandbox so the provider's CLI can
     * read it. Off by default: the chat/agent paths never need it, only the terminal command does.
     */
    fun isTerminalKeyShared(context: Context, id: String): Boolean {
        val set = store(context).getStringSet(KEY_SHARED, emptySet()).orEmpty()
        return id in set
    }

    fun setTerminalKeyShared(context: Context, id: String, shared: Boolean) {
        val set = store(context).getStringSet(KEY_SHARED, emptySet()).orEmpty().toMutableSet()
        if (shared) set.add(id) else set.remove(id)
        store(context).edit().putStringSet(KEY_SHARED, set).apply()
        if (!shared) com.example.terminal.TerminalProviderProvisioner.revokeTerminalKey(context, id)
    }

    /** A stable command name for a display name: lowercase, letters/digits/hyphens only. */
    fun commandFor(name: String): String =
        name.trim().lowercase().map { ch -> if (ch.isLetterOrDigit()) ch else '-' }
            .joinToString("").trim('-').ifBlank { "custom" }

    /** Adds a provider the user typed in. Throws with a message the UI can show. */
    fun addCustom(
        context: Context,
        name: String,
        command: String,
        baseUrl: String,
        model: String,
        kind: TerminalProviderKind,
        apiKey: String
    ): TerminalProvider {
        val cleanName = name.trim()
        require(cleanName.length in 2..40) { "Give the provider a name (2–40 characters)" }
        val cmd = command.trim().ifBlank { commandFor(cleanName) }
        require(Regex("[a-z0-9][a-z0-9_-]{1,31}").matches(cmd)) {
            "The command may only use lowercase letters, digits, '_' and '-' (2–32 characters)"
        }
        require(baseUrl.trim().startsWith("http")) { "Enter a base URL starting with http:// or https://" }
        val id = "custom_" + cmd
        val existing = readCustom(context)
        require(existing.none { it.id.equals(id, ignoreCase = true) }) { "A provider with the command '$cmd' already exists" }
        require(BUILT_IN.none { it.cliCommand.equals(cmd, ignoreCase = true) }) { "'$cmd' is already a built-in provider" }
        val provider = TerminalProvider(
            id = id,
            name = cleanName,
            tagline = "Your provider",
            cliSource = TerminalCliSource.URL_ONLY,
            description = "Added by you. SAIF AI prepares '$cmd' in the Linux terminal in the background.",
            kind = kind,
            cliCommand = cmd,
            apiBaseUrl = baseUrl.trim().trimEnd('/'),
            defaultModel = model.trim(),
            authHint = "Your $cleanName API key",
            isCustom = true
        )
        writeCustom(context, existing + provider)
        setBaseUrl(context, id, provider.apiBaseUrl)
        if (provider.defaultModel.isNotBlank()) setModel(context, id, provider.defaultModel)
        if (apiKey.isNotBlank()) setApiKey(context, id, apiKey)
        return provider
    }

    fun removeCustom(context: Context, id: String) {
        val remaining = readCustom(context).filterNot { it.id.equals(id, ignoreCase = true) }
        writeCustom(context, remaining)
        setApiKey(context, id, "")
        setBaseUrl(context, id, "")
        setModel(context, id, "")
        if (store(context).getString(KEY_SELECTED, null).equals(id, ignoreCase = true)) {
            store(context).edit().putString(KEY_SELECTED, BUILT_IN.first().id).apply()
        }
    }

    /** Everything the terminal needs to call this provider, resolved in one place. */
    fun resolved(context: Context, id: String): ResolvedProvider? {
        val p = find(context, id) ?: return null
        return ResolvedProvider(
            provider = p,
            apiKey = apiKey(context, p.id),
            isReady = !p.needsApiKey() || apiKey(context, p.id).isNotBlank()
        )
    }

    data class ResolvedProvider(
        val provider: TerminalProvider,
        val apiKey: String,
        val isReady: Boolean
    )
}
