/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */
package com.example

import kotlinx.coroutines.flow.MutableStateFlow

/** Lets other modules (the live engine) ask the Compose UI to open its Settings panel. */
object HostNavigation {
    val openSettingsRequest = MutableStateFlow(false)
}
