/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saifagent

import org.json.JSONObject
import java.io.File

/**
 * One parameter of an [AgentTool].
 *
 * The schema is deliberately tiny — `string`, `number`, `boolean` — because every provider we talk
 * to accepts those, and a tool the model cannot describe is a tool the model cannot use.
 */
data class ToolParam(
    val name: String,
    val description: String,
    val type: String = "string",
    val required: Boolean = true
)

/** The result of running one tool. [output] is what the model gets to read next. */
data class ToolOutcome(
    val ok: Boolean,
    val output: String,
    /** Set when the step should stop the run entirely (for example a fatal sandbox error). */
    val fatal: Boolean = false
) {
    companion object {
        fun ok(text: String) = ToolOutcome(true, text)
        fun fail(text: String) = ToolOutcome(false, text)
        fun fatal(text: String) = ToolOutcome(false, text, fatal = true)
    }
}

/**
 * Everything a tool is allowed to touch: one workspace directory, one approval gate, one log.
 *
 * Tools never see the Android [android.content.Context]. That is the point: a tool cannot reach
 * outside the workspace, read another app's data, or make a network call we did not design for.
 */
data class ToolContext(
    val workspace: File,
    val approval: ApprovalGate,
    val log: (String) -> Unit
)

/** Asked before anything that changes the device or leaves it. */
fun interface ApprovalGate {
    /**
     * @return true to run the action, false to refuse it. The refusal text goes back to the model so
     * it can pick a different approach instead of silently failing.
     */
    suspend fun confirm(tool: String, summary: String, detail: String): Boolean
}

/**
 * A capability the agent can call by name.
 *
 * Implement this to add a tool; register it in [ToolRegistry]. Tools must be quick to describe and
 * safe to retry: the runtime may call the same tool many times in one run.
 */
interface AgentTool {
    /** Lowercase snake_case, unique within a registry. */
    val name: String
    /** One or two sentences, written for the model, not for a human UI. */
    val description: String
    val params: List<ToolParam>

    /** Human-readable line shown when the run asks for approval. */
    fun summary(args: JSONObject): String = "$name(${params.joinToString(", ") { it.name }})"

    /** True when this tool changes files, runs commands or leaves the device. */
    val needsApproval: Boolean get() = false

    suspend fun run(args: JSONObject, ctx: ToolContext): ToolOutcome

    /** The JSON schema fragment handed to the model. */
    fun schema(): JSONObject = JSONObject().apply {
        put("name", name)
        put("description", description)
        val props = JSONObject()
        val required = org.json.JSONArray()
        for (p in params) {
            props.put(p.name, JSONObject().apply {
                put("type", p.type)
                put("description", p.description)
            })
            if (p.required) required.put(p.name)
        }
        put("parameters", JSONObject().apply {
            put("type", "object")
            put("properties", props)
            put("required", required)
        })
    }
}

/** Thrown by a tool when the arguments it received are unusable. The text goes back to the model. */
class ToolArgumentException(message: String) : IllegalArgumentException(message)

internal fun JSONObject.requireString(key: String): String {
    val value = opt(key)
    if (value == null || value == JSONObject.NULL) throw ToolArgumentException("missing required argument '$key'")
    return value.toString()
}

internal fun JSONObject.optionalString(key: String, fallback: String = ""): String {
    val value = opt(key)
    return if (value == null || value == JSONObject.NULL) fallback else value.toString()
}
