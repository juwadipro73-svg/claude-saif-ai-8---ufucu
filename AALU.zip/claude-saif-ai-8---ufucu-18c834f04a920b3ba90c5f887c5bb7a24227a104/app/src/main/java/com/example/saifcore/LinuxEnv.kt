/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. The app as distributed also contains third-party
 * GNU GPL v3 material - see LICENSE and THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipInputStream

/**
 * SAIF AI's own Linux environment manager.
 *
 * Written from scratch. The job is narrow and mechanical: put a working Linux userland inside the
 * app's private files, keep a record of whether it verified, and tell the UI what is happening while
 * that takes several minutes.
 *
 * Three decisions shape it:
 *
 *  - **Everything lives under `filesDir/usr`.** No root, no external storage, no shared prefix — so
 *    the environment belongs to this app and is removed with it.
 *  - **Install runs in the background and is idempotent.** It can be requested from a dozen places
 *    at once; only the first does the work, and the rest observe the same state.
 *  - **A verified environment is a separate flag from an installed one.** Extraction succeeding is
 *    not proof the binaries run, so the app verifies once and remembers, instead of re-checking on
 *    every launch.
 */
object LocalEnvironmentManager {

    private const val NOTIFICATION_CHANNEL_ID = "saif_linux_setup"
    private const val NOTIFICATION_ID = 4101

    /** Version recorded with the install; bumping it forces a fresh setup. */
    private const val ENVIRONMENT_VERSION = "1"

    private val _installerState = MutableStateFlow<LocalInstallerState>(LocalInstallerState.Idle)
    val installerState: StateFlow<LocalInstallerState> = _installerState.asStateFlow()

    private val _installerLogs = MutableStateFlow<List<String>>(emptyList())
    val installerLogs: StateFlow<List<String>> = _installerLogs.asStateFlow()

    @Volatile
    private var installJobRunning = false

    // ---- Layout ------------------------------------------------------------------------------

    fun getPrefixDir(context: Context): File = File(context.filesDir, "usr")
    fun getBinDir(context: Context): File = File(getPrefixDir(context), "bin")
    fun getLibDir(context: Context): File = File(getPrefixDir(context), "lib")
    fun getEtcDir(context: Context): File = File(getPrefixDir(context), "etc")
    fun getTmpDir(context: Context): File = File(getPrefixDir(context), "tmp")
    fun getHomeDir(context: Context): File = File(context.filesDir, "home")
    fun getProjectsDir(context: Context): File = File(getHomeDir(context), "projects")
    fun getUbuntuRootDir(context: Context): File = File(context.filesDir, "ubuntu")

    fun isTermuxPackage(context: Context): Boolean = context.packageName == "com.termux"

    // ---- State -------------------------------------------------------------------------------

    /** True when a prefix exists and at least one expected binary is present. */
    fun isInstalled(context: Context): Boolean {
        val bin = getBinDir(context)
        return bin.isDirectory && (File(bin, "bash").exists() || File(bin, "sh").exists())
    }

    /** True when an install has both completed and passed a runtime check at least once. */
    fun hasVerifiedEnvironment(context: Context): Boolean {
        if (!isInstalled(context)) return false
        val prefs = context.applicationContext.getSharedPreferences(AuthPreferences.PREFS, Context.MODE_PRIVATE)
        val recorded = prefs.getString(KEY_ENV_VERSION, null)
        return recorded == ENVIRONMENT_VERSION && prefs.getBoolean(KEY_ENV_VERIFIED, false)
    }

    fun markVerifiedEnvironment(context: Context) {
        context.applicationContext.getSharedPreferences(AuthPreferences.PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ENV_VERIFIED, true)
            .putString(KEY_ENV_VERSION, ENVIRONMENT_VERSION)
            .apply()
    }

    // ---- Install -----------------------------------------------------------------------------

    /**
     * Installs the environment if it is not already there.
     *
     * Safe to call repeatedly and concurrently. Sign-in and chat never wait on this — they start
     * immediately and the environment becomes available when it is ready.
     */
    suspend fun ensureInstalledInBackground(context: Context) {
        val app = context.applicationContext
        if (hasVerifiedEnvironment(app) || installJobRunning) return
        synchronized(this) {
            if (installJobRunning) return
            installJobRunning = true
        }
        try {
            if (hasVerifiedEnvironment(app)) return
            _installerState.value = LocalInstallerState.Discovering
            log("Preparing the Linux environment…")

            val prefix = getPrefixDir(app)
            prefix.mkdirs()
            getHomeDir(app).mkdirs()
            getProjectsDir(app).mkdirs()
            getTmpDir(app).mkdirs()

            val source = discoverBootstrap(app)
            if (source == null) {
                // No package available and nothing bundled: the app still works, just without a shell.
                log("No Linux package is available. The app will run without a local shell.")
                _installerState.value = LocalInstallerState.Done
                return
            }

            _installerState.value = LocalInstallerState.Downloading(0, source.sizeBytes)
            val archive = download(app, source)

            _installerState.value = LocalInstallerState.Extracting(0f)
            extract(archive, prefix)

            _installerState.value = LocalInstallerState.Configuring
            configure(app)

            _installerState.value = LocalInstallerState.Verifying
            val ok = verify(app)
            if (ok) {
                app.getSharedPreferences(AuthPreferences.PREFS, Context.MODE_PRIVATE)
                    .edit().putBoolean(KEY_LOCAL_TOOLS_INSTALLED, true)
                    .putLong(KEY_LOCAL_TOOLS_INSTALL_DATE, System.currentTimeMillis())
                    .putString(KEY_LOCAL_TOOLS_VERSION, ENVIRONMENT_VERSION)
                    .apply()
                markVerifiedEnvironment(app)
                _installerState.value = LocalInstallerState.Done
                log("Linux environment ready.")
            } else {
                _installerState.value = LocalInstallerState.Error("The Linux tools did not start correctly.")
            }
        } catch (t: Throwable) {
            _installerState.value = LocalInstallerState.Error(t.message ?: "Setup failed.")
            log("Setup failed: ${t.message}")
        } finally {
            installJobRunning = false
        }
    }

    // ---- Steps -------------------------------------------------------------------------------

    private data class Bootstrap(val url: String, val sizeBytes: Long)

    /**
     * Finds something to install, in preference order: a cached download, a bundled asset, then the
     * network. Returns null when none is available, which is a valid outcome rather than an error.
     */
    private fun discoverBootstrap(context: Context): Bootstrap? {
        val cached = File(context.filesDir, "bootstrap/bootstrap.zip")
        if (cached.isFile && cached.length() > 0) {
            log("Using the cached Linux package.")
            return Bootstrap("file://${cached.absolutePath}", cached.length())
        }

        val bundled = runCatching {
            val names = context.assets.list("bootstrap").orEmpty()
            names.firstOrNull { it.endsWith(".zip") }
        }.getOrNull()
        if (bundled != null) {
            log("Using the bundled Linux package: $bundled")
            return Bootstrap("asset://bootstrap/$bundled", 0L)
        }

        val remote = System.getenv("SAIF_ROOTFS_URL")?.takeIf { it.isNotBlank() }
            ?: return null
        log("Downloading the Linux package…")
        return Bootstrap(remote, 0L)
    }

    private suspend fun download(context: Context, source: Bootstrap): File = withContext(Dispatchers.IO) {
        val out = File(context.filesDir, "bootstrap/bootstrap.zip")
        out.parentFile?.mkdirs()

        when {
            source.url.startsWith("file://") -> File(source.url.removePrefix("file://"))
            source.url.startsWith("asset://") -> {
                val name = source.url.removePrefix("asset://")
                context.assets.open(name).use { input ->
                    FileOutputStream(out).use { input.copyTo(it) }
                }
                out
            }
            else -> {
                val connection = URL(source.url).openConnection() as HttpURLConnection
                try {
                    connection.connectTimeout = 20_000
                    connection.readTimeout = 60_000
                    connection.instanceFollowRedirects = true
                    connection.connect()
                    if (connection.responseCode !in 200..299) error("HTTP ${connection.responseCode}")
                    val total = connection.contentLengthLong
                    connection.inputStream.use { input ->
                        FileOutputStream(out).use { fileOut ->
                            val buffer = ByteArray(64 * 1024)
                            var read: Int
                            var done = 0L
                            while (input.read(buffer).also { read = it } >= 0) {
                                fileOut.write(buffer, 0, read)
                                done += read
                                _installerState.value = LocalInstallerState.Downloading(done, total)
                            }
                        }
                    }
                } finally {
                    connection.disconnect()
                }
                out
            }
        }
    }

    private suspend fun extract(archive: File, target: File) = withContext(Dispatchers.IO) {
        target.mkdirs()
        ZipInputStream(archive.inputStream().buffered()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                val destination = File(target, entry.name).canonicalFile
                // Refuse anything that would escape the prefix, whatever the archive claims.
                if (!destination.path.startsWith(target.canonicalFile.path + File.separator)) continue
                if (entry.isDirectory) {
                    destination.mkdirs()
                } else {
                    destination.parentFile?.mkdirs()
                    FileOutputStream(destination).use { zip.copyTo(it) }
                }
                zip.closeEntry()
            }
        }
        // Archives from different packagers differ on the executable bit, so set it explicitly.
        val bin = File(target, "bin")
        if (bin.isDirectory) {
            bin.listFiles()?.forEach { runCatching { it.setExecutable(true, true) } }
        }
    }

    private fun configure(context: Context) {
        val etc = getEtcDir(context)
        etc.mkdirs()
        val profile = File(etc, "profile")
        val prefix = getPrefixDir(context).absolutePath
        profile.writeText(
            """
            export PREFIX=$prefix
            export HOME=${getHomeDir(context).absolutePath}
            export TMPDIR=${getTmpDir(context).absolutePath}
            export PATH=$prefix/bin:${'$'}PATH
            export LD_LIBRARY_PATH=$prefix/lib:${'$'}LD_LIBRARY_PATH
            export LANG=C.UTF-8
            """.trimIndent()
        )
    }

    /** Runs the shell itself, which is the only check that actually proves the install works. */
    private suspend fun verify(context: Context): Boolean = withContext(Dispatchers.IO) {
        val shell = listOf(
            File(getBinDir(context), "bash"),
            File(getBinDir(context), "sh")
        ).firstOrNull { it.exists() } ?: return@withContext false
        runCatching {
            shell.setExecutable(true)
            val process = ProcessBuilder(shell.absolutePath, "-c", "echo ok")
                .directory(getPrefixDir(context))
                .redirectErrorStream(true)
                .start()
            process.waitFor(20, java.util.concurrent.TimeUnit.SECONDS)
            val out = process.inputStream.bufferedReader().readText()
            process.exitValue() == 0 && out.contains("ok")
        }.getOrDefault(false)
    }

    // ---- Reporting ---------------------------------------------------------------------------

    fun log(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val entry = "$time  $message"
        _installerLogs.value = (_installerLogs.value + entry).takeLast(400)
    }

    fun clearLogs() {
        _installerLogs.value = emptyList()
    }

    /** Shows setup progress in the notification shade, since it runs for minutes at a time. */
    private fun notify(context: Context, title: String, text: String) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "Linux setup",
                NotificationManager.IMPORTANCE_LOW
            )
            manager.createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(context, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
        runCatching { manager.notify(NOTIFICATION_ID, notification) }
    }

    private const val KEY_ENV_VERIFIED = "linux_env_verified"
    private const val KEY_ENV_VERSION = "linux_env_version"
    private const val KEY_LOCAL_TOOLS_INSTALLED = "local_tools_installed"
    private const val KEY_LOCAL_TOOLS_INSTALL_DATE = "local_tools_install_date"
    private const val KEY_LOCAL_TOOLS_VERSION = "local_tools_version"
}

/**
 * Starts, and stops, the parts of the environment that belong to a signed-in account.
 *
 * The environment itself is shared; what is per-account is the home and projects layout. Signing out
 * therefore does not delete anything — it just stops the per-account work until someone signs in
 * again, so a sign-out can never destroy a user's files.
 */
object AuthenticatedWorkspace {

    @Volatile
    private var started = false

    suspend fun ensureStarted(context: Context) {
        if (started) return
        val app = context.applicationContext
        LocalEnvironmentManager.getHomeDir(app).mkdirs()
        LocalEnvironmentManager.getProjectsDir(app).mkdirs()
        started = true
        LocalEnvironmentManager.log("Workspace ready at ${LocalEnvironmentManager.getHomeDir(app)}")

        // The environment is only prepared for a signed-in account; installation runs in the
        // background and never blocks the UI.
        LocalEnvironmentManager.ensureInstalledInBackground(app)
    }

    fun onSignedOut() {
        started = false
    }
}

/**
 * Starts and stops SAIF AI's local HTTP server.
 *
 * Kept deliberately simple: the server is one component with no dependencies, so "restart" is
 * literally stop-then-start with a short pause, and any failure is reported rather than retried
 * forever.
 */
object LocalServerManager {

    /**
     * Restarts the local server.
     *
     * Not suspend, because it is called straight from a click handler: the work goes onto the IO
     * dispatcher and the caller carries on. A restart that fails is logged, never thrown.
     */
    fun restartServer(context: Context) {
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            LocalEnvironmentManager.log("Restarting the local server…")
            runCatching { AndroidLocalBridgeServer.instance.stop() }
            runCatching { Thread.sleep(300) }
            runCatching { AndroidLocalBridgeServer.instance.start(context.applicationContext) }
                .onFailure { LocalEnvironmentManager.log("Could not restart the local server: ${it.message}") }
        }
    }
}
