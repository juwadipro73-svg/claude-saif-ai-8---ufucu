/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. The app as distributed also contains third-party
 * GNU GPL v3 material - see LICENSE and THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore

/**
 * Status types shared across SAIF AI's runtime.
 *
 * Written from scratch for SAIF AI. Each type describes a state the UI already renders, so the
 * shapes are fixed by what the screens need rather than by any external protocol.
 */

/** How well the local Linux environment and the agent backend are doing. */
enum class SystemStatus(val label: String) {
    /** Everything is up and a request can be sent right now. */
    READY("Ready"),

    /** Still starting: installing, booting the server, or waiting on the network. */
    STARTING("Starting"),

    /** The backend answered, but the user is not signed in. */
    UNAUTHENTICATED("Not signed in"),

    /** The backend answered and refused, or the last request failed. */
    ERROR("Error"),

    /** Nothing has been started yet in this session. */
    IDLE("Idle")
}

/**
 * One snapshot of how connected SAIF AI is.
 *
 * [isReady] is the only field most callers look at; the rest exist so the UI can explain *why* it is
 * not ready, which is the difference between a spinner and a useful message.
 */
sealed class SystemConnectionState {

    abstract val status: SystemStatus
    open val isReady: Boolean get() = false
    open val message: String get() = ""

    data object Idle : SystemConnectionState() {
        override val status = SystemStatus.IDLE
        override val message = "SAIF AI has not started yet."
    }

    data class Starting(override val message: String = "Starting SAIF AI…") : SystemConnectionState() {
        override val status = SystemStatus.STARTING
    }

    data class Ready(
        override val message: String = "Connected",
        val endpoint: String = ""
    ) : SystemConnectionState() {
        override val status = SystemStatus.READY
        override val isReady = true
    }

    data class Unauthenticated(override val message: String = "Sign in to continue.") : SystemConnectionState() {
        override val status = SystemStatus.UNAUTHENTICATED
    }

    data class Error(override val message: String = "Something went wrong.") : SystemConnectionState() {
        override val status = SystemStatus.ERROR
    }

    companion object {
        fun of(status: SystemStatus, message: String = ""): SystemConnectionState = when (status) {
            SystemStatus.READY -> Ready(message)
            SystemStatus.STARTING -> Starting(message)
            SystemStatus.UNAUTHENTICATED -> Unauthenticated(message)
            SystemStatus.ERROR -> Error(message)
            SystemStatus.IDLE -> Idle
        }
    }
}

/**
 * Progress of the one-time Linux environment setup.
 *
 * The [percent] values are the ones the terminal screen shows, so they are deliberately coarse:
 * a setup that takes minutes does not need to look more precise than it is.
 */
sealed class LocalInstallerState {

    /** Nothing asked for the environment yet. */
    data object Idle : LocalInstallerState()

    /** Looking for a package to use: bundled, cached, or a release to download. */
    data object Discovering : LocalInstallerState()

    /** Waiting for the user to agree to a large download. */
    data class AwaitingConfirmation(val bytes: Long) : LocalInstallerState()

    data class Downloading(val bytesDownloaded: Long, val totalBytes: Long) : LocalInstallerState()

    data class Extracting(val percent: Float = 0f) : LocalInstallerState()

    data object Configuring : LocalInstallerState()

    data object Verifying : LocalInstallerState()

    data object Done : LocalInstallerState()

    data class Error(val message: String) : LocalInstallerState()

    /** 0..1, or null when the step has no meaningful progress. */
    fun progress(): Float? = when (this) {
        Idle -> null
        Discovering -> 0.05f
        is AwaitingConfirmation -> 0.1f
        is Downloading -> if (totalBytes > 0) (0.1f + 0.5f * (bytesDownloaded.toFloat() / totalBytes)).coerceIn(0f, 1f) else 0.3f
        is Extracting -> 0.6f + (percent.coerceIn(0f, 1f) * 0.05f)
        Configuring -> 0.65f
        Verifying -> 0.7f
        Done -> 1f
        is Error -> null
    }
}

/** Health of the local workspace daemon. */
enum class DaemonStatus(val label: String) {
    STOPPED("Stopped"),
    STARTING("Starting"),
    RUNNING("Running"),
    ERROR("Error")
}

/** Result of comparing an open editor tab against what is on disk. */
enum class TabDiskUpdateResult {
    /** The file on disk is identical to what is open. */
    NO_CHANGE,

    /** The tab was updated from disk because it had no unsaved edits. */
    RELOADED,

    /** The tab has unsaved edits and the file on disk changed too: the user must choose. */
    CONFLICT
}

/** A model the agent can be pointed at. */
data class AgentModel(
    val id: String,
    val label: String,
    val description: String = "",
    val isDefault: Boolean = false
)

/** Quota information shown next to a model. Empty when the provider reports nothing. */
data class AgentQuota(
    val label: String,
    val remaining: Long? = null,
    val limit: Long? = null,
    val resetsAtMs: Long? = null
)
