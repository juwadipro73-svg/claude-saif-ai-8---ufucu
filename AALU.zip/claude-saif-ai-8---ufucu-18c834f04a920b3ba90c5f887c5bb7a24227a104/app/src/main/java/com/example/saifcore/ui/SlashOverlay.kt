/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.saifcore.SlashCommandItem
import androidx.compose.foundation.rememberScrollState

/**
 * The suggestion list that appears under the composer while the user types `/…`.
 *
 * Written from scratch. It is a plain list rather than a popup: docking it above the composer keeps
 * it inside the keyboard's own animation, which is the difference between a list that follows the
 * keyboard and one that floats away from it.
 *
 * [runsOnTap] lets the host say whether picking an item should send it immediately or just insert
 * the text — a built-in command like `/clear` runs at once, a skill the user must fill in does not.
 */
@Composable
fun SlashCommandOverlay(
    items: List<SlashCommandItem>,
    query: String = "",
    runsOnTap: (SlashCommandItem) -> Boolean = { false },
    onPick: (SlashCommandItem) -> Unit,
    modifier: Modifier = Modifier
) {
    if (items.isEmpty()) return

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = Color(0xFF1F1E1D),
        tonalElevation = 6.dp,
        shadowElevation = 6.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(vertical = 6.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (query.isBlank()) "Commands" else "Commands matching \"/$query\"",
                    color = Color(0xFFA8A59B),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = if (runsOnTap(items.first())) "tap to run" else "tap to insert",
                    color = Color(0xFFA8A59B),
                    fontSize = 10.5.sp
                )
            }

            // A bounded list: with a few hundred skills the overlay must still leave room for the
            // composer and the keyboard.
            LazyColumn(modifier = Modifier.heightIn(max = 220.dp)) {
                items(items = items, key = { it.type + ":" + it.command }) { item ->
                    CommandRow(item = item, onPick = onPick)
                }
            }
        }
    }
}

@Composable
private fun CommandRow(item: SlashCommandItem, onPick: (SlashCommandItem) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onPick(item) }
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "/${item.command}",
            color = Color(0xFF7C5CE0),
            fontSize = 13.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = item.name,
                color = Color(0xFFF4F3F0),
                fontSize = 13.sp
            )
            if (item.description.isNotBlank()) {
                Text(
                    text = item.description,
                    color = Color(0xFFA8A59B),
                    fontSize = 11.5.sp
                )
            }
        }
        if (item.type == "skill") {
            Text(text = "skill", color = Color(0xFFA8A59B), fontSize = 10.5.sp)
        }
    }
}
