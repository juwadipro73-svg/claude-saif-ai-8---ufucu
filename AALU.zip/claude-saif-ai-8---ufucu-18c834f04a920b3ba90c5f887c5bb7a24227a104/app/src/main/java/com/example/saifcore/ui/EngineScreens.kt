/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. The app as distributed also contains third-party
 * GNU GPL v3 material - see LICENSE and THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.saifcore.AgentKind
import com.example.saifcore.AgentPreferences
import com.example.saifcore.SaifEngineViewModel
import com.example.saifcore.SavedAiSkills
import com.example.saifcore.SlashCommandItem
import com.example.saifcore.SlashCommandsCache
import com.example.saifcore.AuthPreferences
import com.example.saifcore.SystemConnectionState
import com.example.saifcore.SystemStatus
import kotlinx.coroutines.launch

/**
 * The settings sections for SAIF AI's own engine.
 *
 * Written from scratch. A section is a row that opens a screen inside the sheet; there is no nested
 * navigation stack, so the back button always means "back to the section list" and the user can never
 * get lost inside settings.
 */
enum class SettingsSection(val title: String, val subtitle: String) {
    MAIN("Settings & Preferences", "Configure your SAIF AI experience"),
    APPEARANCE("Appearance & Theme", "Theme, dark mode, and chat font scaling"),
    SERVERS("Servers & Connectivity", "Local bridge and agent endpoints"),
    SLASH_COMMANDS("Slash Commands", "Your own / commands and what they expand to"),
    AI_SKILLS("Add New AI Skill", "Import and manage skills for / commands"),
    AGENTS("Agents", "Which agent backends are enabled"),
    SKILLS_PLUGINS("Skills & Plugins", "Agent capabilities and extensions"),
    MCP("MCP Servers", "Tool servers the agent can reach"),
    TERMINAL("Terminal & Shell", "Local tools, SSH and styling"),
    COMMANDS("Commands & Permissions", "Auto-run policy and tool approvals")
}

/** The sections shown, in order. */
val ENGINE_SETTINGS_SECTIONS: List<SettingsSection> = listOf(
    SettingsSection.MAIN,
    SettingsSection.APPEARANCE,
    SettingsSection.SERVERS,
    SettingsSection.SLASH_COMMANDS,
    SettingsSection.AI_SKILLS,
    SettingsSection.AGENTS,
    SettingsSection.SKILLS_PLUGINS,
    SettingsSection.MCP,
    SettingsSection.TERMINAL,
    SettingsSection.COMMANDS
)

private val Accent = Color(0xFF7C5CE0)
private val OnDark = Color(0xFFF4F3F0)
private val Muted = Color(0xFFA8A59B)
private val Card = Color(0xFF1F1E1D)
private val CardLight = Color(0xFFFAF9F5)
private val TextLight = Color(0xFF1A1918)

/**
 * The engine settings surface shown inside SAIF AI's own settings sheet.
 *
 * @param initialSection the section to open on, by enum name
 */
@Composable
fun EmbeddedEngineSettings(
    viewModel: SaifEngineViewModel,
    isLightMode: Boolean,
    initialSection: String = SettingsSection.MAIN.name,
    onOpenTerminal: () -> Unit = {},
    autoApprove: Boolean = false,
    onAutoApproveChange: (Boolean) -> Unit = {},
    onDismiss: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val start = remember(initialSection) {
        runCatching { SettingsSection.valueOf(initialSection) }.getOrDefault(SettingsSection.MAIN)
    }
    var section by remember(initialSection) { mutableStateOf<SettingsSection?>(start) }

    val card = if (isLightMode) CardLight else Card
    val text = if (isLightMode) TextLight else OnDark
    val muted = if (isLightMode) Color(0xFF6B6862) else Muted

    Surface(modifier = modifier.fillMaxSize(), color = card) {
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { if (section == null) onDismiss() else section = null }) {
                    Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back", tint = text)
                }
                Spacer(Modifier.width(6.dp))
                Text(
                    text = section?.title ?: "Engine Settings",
                    color = text,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            if (section == null) {
                SectionList(onPick = { section = it }, text = text, muted = muted)
            } else {
                when (section) {
                    SettingsSection.MAIN -> MainSection(viewModel, text, muted)
                    SettingsSection.APPEARANCE -> AppearanceSection(viewModel, text, muted)
                    SettingsSection.SERVERS -> ServersSection(viewModel, text, muted)
                    SettingsSection.SLASH_COMMANDS -> SlashSection(text, muted)
                    SettingsSection.AI_SKILLS -> SkillsSection(text, muted)
                    SettingsSection.MCP -> McpSection(viewModel, text, muted)
                    SettingsSection.AGENTS -> AgentsSection(viewModel, text, muted)
                    SettingsSection.SKILLS_PLUGINS -> SlashSection(text, muted)
                    SettingsSection.TERMINAL -> TerminalSection(viewModel, text, muted, onOpenTerminal)
                    SettingsSection.COMMANDS -> PermissionSection(
                        viewModel, text, muted, autoApprove, onAutoApproveChange
                    )
                    null -> Unit
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SectionList(onPick: (SettingsSection) -> Unit, text: Color, muted: Color) {
    ENGINE_SETTINGS_SECTIONS.forEach { section ->
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onPick(section) }
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(section.title, color = text, fontSize = 14.5.sp)
                Text(section.subtitle, color = muted, fontSize = 11.5.sp)
            }
            Icon(Icons.Outlined.ChevronRight, contentDescription = null, tint = muted, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun MainSection(viewModel: SaifEngineViewModel, text: Color, muted: Color) {
    val connection by viewModel.systemConnectionState.collectAsState()
    Column(modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)) {
        StatusRow(
            label = "Agent",
            value = connection.message.ifBlank { connection.status.label },
            muted = muted
        )
        StatusRow(
            label = "Model",
            value = viewModel.agyBackend.selectedModelId.value.ifBlank { "not selected" },
            muted = muted
        )
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = { viewModel.retryConnections() }) { Text("Reconnect") }
            OutlinedButton(onClick = { viewModel.agyBackend.refreshModelsAsync() }) { Text("Refresh models") }
        }
    }
}

@Composable
private fun AppearanceSection(viewModel: SaifEngineViewModel, text: Color, muted: Color) {
    var dividers by remember { mutableStateOf(viewModel.authPreferences.chatDividersEnabled) }
    var animation by remember { mutableStateOf(viewModel.authPreferences.workingAnimationEnabled) }
    Column(modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)) {
        ToggleRow("Chat dividers", "Separate days and model switches.", dividers, muted) {
            dividers = it
            viewModel.authPreferences.chatDividersEnabled = it
        }
        ToggleRow("Working animation", "Show the indicator while the agent works.", animation, muted) {
            animation = it
            viewModel.authPreferences.workingAnimationEnabled = it
        }
    }
}

@Composable
private fun ServersSection(viewModel: SaifEngineViewModel, text: Color, muted: Color) {
    var bridge by remember { mutableStateOf(viewModel.authPreferences.bridgeHttpUrl) }
    var hub by remember { mutableStateOf(viewModel.authPreferences.hubUrl) }
    Column(modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)) {
        OutlinedTextField(
            value = bridge,
            onValueChange = { bridge = it; viewModel.authPreferences.bridgeHttpUrl = it },
            label = { Text("Local bridge URL") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = hub,
            onValueChange = { hub = it; viewModel.authPreferences.hubUrl = it },
            label = { Text("Agent endpoint URL") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(14.dp))
        Text(
            "Both addresses are on this device (127.0.0.1). SAIF AI never sends them anywhere.",
            color = muted, fontSize = 11.5.sp
        )
    }
}

@Composable
private fun SlashSection(text: Color, muted: Color) {
    val items = remember { SlashCommandsCache.getCommands() }
    Column(modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)) {
        items.forEach { item ->
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                Text("/${item.command}", color = Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(item.name, color = text, fontSize = 13.sp)
                    Text(item.description, color = muted, fontSize = 11.5.sp)
                }
            }
        }
    }
}

@Composable
private fun SkillsSection(text: Color, muted: Color) {
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var link by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Column(modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)) {
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Skill name") },
            singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = description, onValueChange = { description = it },
            label = { Text("Description") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = link, onValueChange = { link = it },
            label = { Text("GitHub file URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            scope.launch {
                message = runCatching {
                    SavedAiSkills.fetchAndSave(name, description, link)
                    "Saved."
                }.getOrElse { "Could not import: ${it.message}" }
            }
        }) { Text("Import") }
        if (message.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(message, color = muted, fontSize = 12.sp)
        }
        Spacer(Modifier.height(16.dp))
        SavedAiSkills.visibleSkills().forEach { skill ->
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Text(skill.name, color = text, fontSize = 13.sp, modifier = Modifier.weight(1f))
                Text("remove", color = Accent, fontSize = 12.sp,
                    modifier = Modifier.clickable { SavedAiSkills.delete(skill.name) })
            }
        }
    }
}

@Composable
private fun McpSection(viewModel: SaifEngineViewModel, text: Color, muted: Color) {
    val scope = rememberCoroutineScope()
    var message by remember { mutableStateOf("") }
    Column(modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)) {
        Text(
            "Tool servers are read from your local MCP configuration. Reload after changing it.",
            color = muted, fontSize = 12.sp
        )
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = {
            scope.launch {
                message = runCatching {
                    viewModel.agyBackend.agyHubClient.refreshMcpServers().getOrThrow()
                    "Reloaded."
                }.getOrElse { "Could not reload: ${it.message}" }
            }
        }) { Text("Reload tool servers") }
        if (message.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(message, color = muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun AgentsSection(viewModel: SaifEngineViewModel, text: Color, muted: Color) {
    val enabled = AgentPreferences.enabledSync(viewModel.getApplication())
    Column(modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)) {
        Text(
            "SAIF AI's own agent is active. Enable a second backend only if you run one yourself.",
            color = muted, fontSize = 12.sp
        )
        Spacer(Modifier.height(10.dp))
        AgentKind.values().forEach { kind ->
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(kind.name, color = OnDark, fontSize = 14.sp)
                    Text(
                        if (kind == AgentKind.SAIF) "SAIF AI's own runtime" else "External backend",
                        color = muted, fontSize = 11.5.sp
                    )
                }
                Text(
                    if (kind in enabled) "on" else "off",
                    color = if (kind in enabled) Accent else muted,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun TerminalSection(
    viewModel: SaifEngineViewModel,
    text: Color,
    muted: Color,
    onOpenTerminal: () -> Unit
) {
    var fontSize by remember { mutableStateOf(viewModel.authPreferences.terminalFontSize.toString()) }
    Column(modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)) {
        OutlinedTextField(
            value = fontSize,
            onValueChange = { input ->
                fontSize = input.filter { it.isDigit() }.take(2)
                fontSize.toIntOrNull()?.let { viewModel.authPreferences.terminalFontSize = it }
            },
            label = { Text("Terminal font size") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(14.dp))
        OutlinedButton(onClick = onOpenTerminal) { Text("Open the terminal") }
    }
}

@Composable
private fun PermissionSection(
    viewModel: SaifEngineViewModel,
    text: Color,
    muted: Color,
    autoApprove: Boolean,
    onAutoApproveChange: (Boolean) -> Unit
) {
    var terminal by remember { mutableStateOf(viewModel.authPreferences.isTerminalToolEnabled) }
    var files by remember { mutableStateOf(viewModel.authPreferences.isFileToolEnabled) }
    var web by remember { mutableStateOf(viewModel.authPreferences.isWebSearchToolEnabled) }

    Column(modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)) {
        ToggleRow(
            "Auto-run commands",
            "Let the agent run commands without asking. Off by default.",
            autoApprove, muted, onAutoApproveChange
        )
        ToggleRow("Terminal", "Allow shell commands.", terminal, muted) {
            terminal = it; viewModel.authPreferences.isTerminalToolEnabled = it
        }
        ToggleRow("Files", "Allow reading and writing files in the workspace.", files, muted) {
            files = it; viewModel.authPreferences.isFileToolEnabled = it
        }
        ToggleRow("Web search", "Allow searching the web.", web, muted) {
            web = it; viewModel.authPreferences.isWebSearchToolEnabled = it
        }
    }
}

@Composable
private fun ToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    muted: Color,
    onToggle: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = OnDark, fontSize = 14.sp)
            Text(subtitle, color = muted, fontSize = 11.5.sp)
        }
        Switch(checked = checked, onCheckedChange = onToggle)
    }
}

@Composable
private fun StatusRow(label: String, value: String, muted: Color) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(label, color = muted, fontSize = 13.sp, modifier = Modifier.width(90.dp))
        Text(value, color = OnDark, fontSize = 13.sp, modifier = Modifier.weight(1f))
    }
}

/**
 * The full-screen engine surfaces: browser and terminal.
 *
 * Written from scratch. Only the modes the app actually offers are handled; an unknown mode is
 * dismissed rather than shown as an empty screen.
 */
@Composable
fun EmbeddedEngineFeatures(
    activeMode: String?,
    isLightMode: Boolean,
    onModeChange: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    if (activeMode == null) return

    Surface(modifier = modifier.fillMaxSize(), color = if (isLightMode) CardLight else Card) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = when (activeMode) {
                        "BROWSER" -> "Browser"
                        "TERMINAL" -> "Terminal"
                        "IDE" -> "Workspace"
                        else -> activeMode
                    },
                    color = OnDark,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "This surface is provided by SAIF AI's own engine.",
                    color = Muted,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(16.dp))
                OutlinedButton(onClick = { onModeChange(null) }) { Text("Close") }
            }
        }
    }
}

/** Kept so callers that only have a status can render a label. */
fun statusLabel(state: SystemConnectionState): String =
    state.message.ifBlank { state.status.label }

/** True when a connection state allows the user to send. */
fun canSend(state: SystemConnectionState): Boolean =
    state.status == SystemStatus.READY || state.status == SystemStatus.IDLE
