/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. The app as distributed also contains third-party
 * GNU GPL v3 material - see LICENSE and THIRD_PARTY_NOTICES.md.
 */

package com.example.saifcore

import android.content.Context
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/** One saved instruction set, invocable as `/name`. */
data class SavedAiSkill(
    val name: String,
    val description: String,
    val instructions: String = "",
    val source: String = ""
)

/**
 * The user's saved slash-command skills.
 *
 * Written from scratch. Two properties matter:
 *
 *  - **Skills belong to an account.** [bind] is called on every sign-in change, and until it is
 *    called with a matching owner the list is empty, so one account can never see another's skills.
 *  - **Instructions live in files, not in preferences.** A skill can be a few thousand characters;
 *    preferences are for small values, and a large blob there slows every read of every key.
 */
object SavedAiSkills {

    private const val PREFS = "saif_skills"
    private const val MAX_SKILLS = 200
    private const val MAX_SINGLE_FILE_BYTES = 512 * 1024

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private var storageKey = "skills_anonymous"
    private var filesDir: File? = null
    private var prefsStore: android.content.SharedPreferences? = null

    /** The skills of the bound account, or an empty list when nothing is bound. */
    private val skills = mutableListOf<SavedAiSkill>()

    /** True when the bound account is the one the app is currently signed in as. */
    @Volatile
    private var boundToCurrentAccount = false

    /**
     * Binds the store to an account.
     *
     * @param uid the signed-in account id, or null for the signed-out/local case
     */
    fun bind(context: Context, uid: String?) {
        val app = context.applicationContext
        filesDir = app.filesDir
        prefsStore = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        val account = uid?.takeIf { it.isNotBlank() }
        boundToCurrentAccount = account != null
        val newKey = account?.let { "skills_" + sha256(it).take(16) } ?: "skills_anonymous"

        if (newKey == storageKey && skills.isNotEmpty()) return
        storageKey = newKey
        skills.clear()

        val stored = prefsStore?.getString(newKey, null) ?: return
        val array = runCatching { JSONArray(stored) }.getOrElse { return }
        for (i in 0 until minOf(array.length(), MAX_SKILLS)) {
            val item = array.optJSONObject(i) ?: continue
            val name = item.optString("name").takeIf { it.isNotBlank() } ?: continue
            val file = fileFor(name)
            val fromFile = if (file.isFile && file.length() in 1..MAX_SINGLE_FILE_BYTES.toLong()) {
                runCatching { file.readText() }.getOrNull()
            } else null
            val text = fromFile ?: item.optString("instructions").takeIf { it.isNotBlank() } ?: continue
            skills.add(
                SavedAiSkill(
                    name = name,
                    description = item.optString("description"),
                    instructions = text,
                    source = item.optString("source")
                )
            )
        }
        SlashCommandsCache.refresh()
    }

    /** Skills visible right now: empty unless an account is bound. */
    fun visibleSkills(): List<SavedAiSkill> =
        if (boundToCurrentAccount) skills.toList() else emptyList()

    fun find(name: String): SavedAiSkill? =
        visibleSkills().firstOrNull { it.name.equals(name, ignoreCase = true) }

    /** Skills as slash-command entries, filtered by [query]. */
    fun suggestions(query: String): List<SlashCommandItem> {
        val q = query.trim().lowercase()
        return visibleSkills()
            .filter { q.isBlank() || it.name.lowercase().contains(q) || it.description.lowercase().contains(q) }
            .map {
                SlashCommandItem(
                    name = it.name,
                    command = it.name.lowercase().replace(Regex("[^a-z0-9_-]"), "-"),
                    description = it.description,
                    type = "skill"
                )
            }
    }

    /** Adds or replaces a skill and persists it. */
    fun save(skill: SavedAiSkill): Boolean {
        val dir = filesDir ?: return false
        val name = skill.name.trim()
        if (name.isBlank()) return false

        runCatching {
            val file = File(dir, "skills/${sha256(storageKey + name).take(24)}.md")
            file.parentFile?.mkdirs()
            val tmp = File(file.parentFile, "${file.name}.tmp")
            tmp.writeText(skill.instructions)
            if (!tmp.renameTo(file)) file.writeText(skill.instructions)
        }

        skills.removeAll { it.name.equals(name, ignoreCase = true) }
        skills.add(skill.copy(name = name))
        persist()
        SlashCommandsCache.refresh()
        return true
    }

    fun delete(name: String) {
        if (skills.removeAll { it.name.equals(name, ignoreCase = true) }) {
            persist()
            SlashCommandsCache.refresh()
        }
    }

    /** Turns a GitHub blob URL into its raw form. Accepts raw URLs unchanged. */
    fun githubRawUrl(input: String): String {
        val raw = input.trim()
        if (raw.startsWith("raw.githubusercontent.com")) return "https://$raw"
        if (raw.startsWith("https://raw.githubusercontent.com")) return raw
        val match = Regex("https?://(?:www\\.)?github\\.com/([^/]+)/([^/]+)/blob/([^/]+)/(.+)").find(raw)
            ?: return raw
        val (owner, repo, ref, path) = match.destructured
        return "https://raw.githubusercontent.com/$owner/$repo/$ref/$path"
    }

    /** Downloads a skill file from a GitHub URL and saves it under [nameInput]. */
    suspend fun fetchAndSave(nameInput: String, descriptionInput: String, linkInput: String): SavedAiSkill =
        withContext(Dispatchers.IO) {
            val name = nameInput.trim().ifBlank {
                linkInput.substringAfterLast('/').substringBeforeLast('.').ifBlank { "skill" }
            }
            val url = githubRawUrl(linkInput)
            val request = Request.Builder().url(url).get().build()
            val text = http.newCall(request).execute().use { response ->
                if (!response.isSuccessful) error("GitHub returned HTTP ${response.code}")
                val stream = response.body?.byteStream() ?: error("GitHub returned an empty file")
                val out = ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                while (true) {
                    val count = stream.read(buffer)
                    if (count < 0) break
                    val remaining = MAX_SINGLE_FILE_BYTES - out.size()
                    if (remaining <= 0) break
                    out.write(buffer, 0, minOf(count, remaining))
                }
                out.toString("UTF-8")
            }
            val skill = SavedAiSkill(
                name = name,
                description = descriptionInput.trim(),
                instructions = text,
                source = url
            )
            save(skill)
            skill
        }

    private fun persist() {
        val store = prefsStore ?: return
        val array = JSONArray()
        skills.forEach {
            array.put(
                JSONObject()
                    .put("name", it.name)
                    .put("description", it.description)
                    .put("source", it.source)
            )
        }
        store.edit().putString(storageKey, array.toString()).apply()
    }

    private fun fileFor(name: String): File =
        File(filesDir, "skills/${sha256(storageKey + name).take(24)}.md")

    private fun sha256(text: String): String =
        MessageDigest.getInstance("SHA-256").digest(text.toByteArray())
            .joinToString("") { "%02x".format(it) }

    /** Exports the visible skills as base64 so they can be shared or restored. */
    fun exportAsBase64(): String {
        val array = JSONArray()
        visibleSkills().forEach {
            array.put(
                JSONObject()
                    .put("name", it.name)
                    .put("description", it.description)
                    .put("instructions", it.instructions)
                    .put("source", it.source)
            )
        }
        return Base64.encodeToString(array.toString().toByteArray(), Base64.NO_WRAP)
    }
}
