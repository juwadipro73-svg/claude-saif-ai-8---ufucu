/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.saifagent.tools

import com.example.saifagent.AgentTool
import com.example.saifagent.ToolContext
import com.example.saifagent.ToolOutcome
import com.example.saifagent.ToolParam
import com.example.saifagent.optionalString
import com.example.saifagent.requireString
import org.json.JSONObject
import java.io.File

/**
 * The result of one shell command.
 *
 * [stdout] and [stderr] are kept apart because the model reads them differently: stdout is the
 * answer, stderr is usually the reason the answer is wrong.
 */
data class CommandResult(
    val exitCode: Int,
    val stdout: String,
    val stderr: String,
    val timedOut: Boolean = false
)

/**
 * Runs a shell command somewhere.
 *
 * This is an interface on purpose. The runtime must not care whether the command runs in a plain
 * Android process, inside SAIF AI's Linux environment, over SSH, or not at all — that choice belongs
 * to whoever wires the app together, and it keeps this module free of any particular environment.
 */
interface ShellRunner {
    /** Human name shown in the UI, e.g. "Linux environment" or "not configured". */
    val displayName: String
    val isAvailable: Boolean
    suspend fun run(command: String, workingDir: File, timeoutMs: Long): CommandResult
}

/** A runner that does nothing and says so. Used until a real environment is wired in. */
object UnavailableShell : ShellRunner {
    override val displayName = "no shell configured"
    override val isAvailable = false
    override suspend fun run(command: String, workingDir: File, timeoutMs: Long) =
        CommandResult(127, "", "No shell is available. Ask the user to finish SAIF AI's environment setup.")
}

/**
 * Runs commands through the platform's own `/system/bin/sh`.
 *
 * Deliberately plain: no login shell, no profile scripts, no inherited environment beyond what is
 * passed in, and a hard timeout with the process destroyed if it is reached.
 */
class ProcessShellRunner(
    private val environment: Map<String, String> = emptyMap(),
    private val shell: String = "/system/bin/sh"
) : ShellRunner {
    override val displayName = "Android shell"
    override val isAvailable = File(shell).exists()

    override suspend fun run(command: String, workingDir: File, timeoutMs: Long): CommandResult {
        if (!isAvailable) return CommandResult(127, "", "No shell at $shell")
        return try {
            val process = ProcessBuilder(shell, "-c", command)
                .directory(workingDir)
                .redirectErrorStream(false)
                .apply { environment().putAll(this@ProcessShellRunner.environment) }
                .start()
            val finished = process.waitFor(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS)
            if (!finished) {
                process.destroyForcibly()
                CommandResult(-1, "", "command timed out after ${timeoutMs / 1000}s", timedOut = true)
            } else {
                val out = process.inputStream.bufferedReader().readText()
                val err = process.errorStream.bufferedReader().readText()
                CommandResult(process.exitValue(), out, err)
            }
        } catch (e: Exception) {
            CommandResult(-1, "", e.message ?: "command failed to start")
        }
    }
}

/**
 * `run_command` — the one tool that leaves the sandbox, so it always asks first and always reports
 * the exit code. Anything destructive is the user's call, not the model's.
 */
/**
 * @param policy final safety gate on the command text; the runtime blocks a handful of
 *   unrecoverable commands (fork bombs, formatting a device) no matter what the model asks for.
 */
class RunCommandTool(
    private val shell: ShellRunner,
    private val policy: (String) -> Boolean = { true }
) : AgentTool {
    override val name = "run_command"
    override val description =
        "Run a shell command inside the workspace and return its exit code, stdout and stderr. " +
            "Use it for builds, tests, git and any task the file tools cannot do."
    override val params = listOf(
        ToolParam("command", "The command line to run."),
        ToolParam("timeout_seconds", "Optional timeout, 1-600. Defaults to 120.", "number", false)
    )
    override val needsApproval = true

    override fun summary(args: JSONObject) = "run: ${args.optionalString("command").take(120)}"

    override suspend fun run(args: JSONObject, ctx: ToolContext): ToolOutcome {
        val command = args.requireString("command").trim()
        if (command.isBlank()) return ToolOutcome.fail("empty command")
        if (!policy(command)) return ToolOutcome.fail("that command is blocked by SAIF AI's safety policy")
        val timeoutSec = args.opt("timeout_seconds")?.toString()?.toLongOrNull()?.coerceIn(1, 600) ?: 120L
        ctx.log("sh: ${command.take(160)}")
        val result = shell.run(command, ctx.workspace, timeoutSec * 1000)
        val body = buildString {
            appendLine("exit code: ${result.exitCode}${if (result.timedOut) " (timed out)" else ""}")
            if (result.stdout.isNotBlank()) appendLine("stdout:\n${result.stdout.take(20_000)}")
            if (result.stderr.isNotBlank()) appendLine("stderr:\n${result.stderr.take(8_000)}")
        }
        return if (result.exitCode == 0) ToolOutcome.ok(body.trim()) else ToolOutcome.fail(body.trim())
    }
}
