/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. Third-party components are listed in THIRD_PARTY_NOTICES.md.
 */

package com.example.ui.components

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.SaifTheme

/**
 * Settings → LICENCES & OPEN SOURCE.
 *
 * The SAIF AI copyright, and the attribution and licence of every third-party component this build
 * actually ships.
 *
 * It is deliberately plain: a licence notice is a legal document, not a marketing page. Keep the
 * wording here in step with `LICENSE`, `THIRD_PARTY_NOTICES.md` and `SHIPPING_CHECKLIST.md` - an app
 * that names a licence it does not honour is in a worse position than one that said nothing.
 */
@Composable
fun SaifLicencesSection(glassBorderBrush: Brush) {
    var showDialog by remember { mutableStateOf(false) }

    LiquidSurface(
        color = SaifTheme.colors.surfaceCard,
        glassBorderBrush = glassBorderBrush,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth(),
        onClick = { showDialog = true }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Outlined.Description,
                contentDescription = null,
                tint = com.example.ui.theme.PrimaryAccent,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Licences & open source",
                    color = SaifTheme.colors.textPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "SAIF AI, plus the open-source components this build links",
                    color = SaifTheme.colors.textSecondary,
                    fontSize = 12.sp
                )
            }
            Icon(
                imageVector = Icons.Outlined.ChevronRight,
                contentDescription = null,
                tint = SaifTheme.colors.textSecondary
            )
        }
    }

    if (showDialog) {
        LicencesDialog(onDismiss = { showDialog = false })
    }
}

@Composable
private fun LicencesDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val sourceUrl = com.example.saifai.BuildConfig.SAIF_SOURCE_URL.trim()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        androidx.compose.material3.Surface(
            shape = RoundedCornerShape(24.dp),
            color = SaifTheme.colors.surfaceCard,
            modifier = Modifier.fillMaxWidth(0.94f)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Licences & open source",
                    color = SaifTheme.colors.textPrimary,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(14.dp))

                Column(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                ) {
                    LicenceBlock(
                        title = "SAIF AI",
                        body = "Copyright (c) SAIF AI. All rights reserved. The interface, chat, agent, " +
                            "video studio, cloud, workspace, terminal and APK builder are SAIF AI's own " +
                            "code, written for SAIF AI."
                    )
                    LicenceBlock(
                        title = "sora-editor",
                        body = "The code editor is Rosemoe sora-editor, used unmodified under the GNU " +
                            "Lesser General Public License v2.1. Its notice and licence ship with this app."
                    )
                    LicenceBlock(
                        title = "JLaTeXMath",
                        body = "Math rendering uses JLaTeXMath, licensed under the GNU General Public " +
                            "License v2.0 or later with the Classpath Exception. Its notice and licence " +
                            "ship with this app."
                    )
                    LicenceBlock(
                        title = "Vosk",
                        body = "On-device speech recognition is Vosk by Alpha Cephei, used under the " +
                            "Apache License 2.0. The speech model is fetched on first use."
                    )
                    LicenceBlock(
                        title = "Termux terminal emulator",
                        body = "The terminal's native pseudo-terminal comes from the termux-app " +
                            "terminal-emulator library, which Termux publishes under the Apache " +
                            "License 2.0 as an exception to its own GPL v3."
                    )
                    LicenceBlock(
                        title = "Linux runtime",
                        body = "The bundled bootstrap archives and the glibc runtime retain the licences " +
                            "of their upstream distributions."
                    )
                    LicenceBlock(
                        title = "Other components",
                        body = "AndroidX, Jetpack Compose, Room, Media3, OkHttp, jsoup, Coil, " +
                            "commons-compress, JSch, Firebase and the other libraries this app links " +
                            "are used under their own permissive licences. THIRD_PARTY_NOTICES.md " +
                            "lists them all."
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Source for this build",
                        color = SaifTheme.colors.textPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (sourceUrl.isBlank()) {
                            "Not configured. Set SAIF_SOURCE_URL when building so the source " +
                                "for this exact build is published alongside it."
                        } else sourceUrl,
                        color = if (sourceUrl.isBlank()) Color(0xFFEF4444) else SaifTheme.colors.textSecondary,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    if (sourceUrl.isNotBlank()) {
                        TextButton(onClick = {
                            runCatching {
                                val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                                    as android.content.ClipboardManager
                                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("SAIF AI source", sourceUrl))
                                Toast.makeText(context, "Source link copied", Toast.LENGTH_SHORT).show()
                            }
                        }) { Text("Copy link") }
                        TextButton(onClick = {
                            runCatching {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(sourceUrl)))
                            }
                        }) { Text("Open") }
                    }
                    Spacer(modifier = Modifier.weight(1f))
                    Button(onClick = onDismiss) { Text("Close") }
                }
            }
        }
    }
}

@Composable
private fun LicenceBlock(title: String, body: String) {
    Row(modifier = Modifier.padding(bottom = 12.dp)) {
        Box(
            modifier = Modifier
                .padding(top = 6.dp)
                .size(6.dp)
                .background(com.example.ui.theme.PrimaryAccent, CircleShape)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = SaifTheme.colors.textPrimary,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = body,
                color = SaifTheme.colors.textSecondary,
                fontSize = 12.sp
            )
        }
    }
}
