/*
 * Copyright (c) SAIF AI. All rights reserved.
 * Original SAIF AI code. The app as distributed also contains third-party
 * GNU GPL v3 material - see LICENSE and THIRD_PARTY_NOTICES.md.
 */

package com.example.saifagent

import org.json.JSONObject

/** What the model asked for in one turn. */
sealed interface AgentStep {
    data class Call(val thought: String, val tool: String, val arguments: JSONObject) : AgentStep
    data class Answer(val thought: String, val text: String) : AgentStep
    /** The reply could not be read as a step; [raw] is kept so the runtime can show it. */
    data class Unreadable(val raw: String, val reason: String) : AgentStep
}

/**
 * The small, strict wire format between SAIF AI's agent runtime and the model.
 *
 * The model is asked to answer with exactly one JSON object per turn:
 *
 * ```json
 * {"thought": "why this step", "action": {"tool": "read_file", "arguments": {"path": "a.txt"}}}
 * {"thought": "why this step", "final": "the answer to the user"}
 * ```
 *
 * Exactly one of `action` or `final` must be present. Anything the model writes outside the object
 * is treated as a note to the user and kept out of the tool channel, so prose never turns into a
 * tool call by accident.
 *
 * Why a JSON envelope and not provider-native function calling: one format works across every
 * provider SAIF AI supports, it survives providers that drop tool schemas mid-stream, and it lets
 * the runtime validate and repair a malformed call instead of failing the run.
 */
object AgentProtocol {

    fun systemPrompt(tools: List<AgentTool>, workspace: String): String = buildString {
        appendLine("You are SAIF AI's agent. You complete the user's task by calling tools, one step at a time.")
        appendLine()
        appendLine("Rules:")
        appendLine("1. Answer with ONE JSON object and nothing else. No markdown fence, no commentary outside it.")
        appendLine("2. The object is {\"thought\": string, \"action\": {\"tool\": string, \"arguments\": object}} to call a tool,")
        appendLine("   or {\"thought\": string, \"final\": string} when the task is done.")
        appendLine("3. Never invent a tool name or an argument that is not listed below.")
        appendLine("4. Read before you write. If a tool returns an error, change your approach instead of repeating it.")
        appendLine("5. Paths are relative to the workspace root: $workspace. You cannot leave it.")
        appendLine("6. Be brief in \"thought\". Be complete in \"final\".")
        appendLine()
        appendLine("Tools:")
        for (tool in tools) {
            val args = tool.params.joinToString(", ") { p ->
                "${p.name}: ${p.type}${if (p.required) "" else "?"}"
            }
            appendLine("- ${tool.name}($args): ${tool.description}")
        }
        appendLine()
        appendLine("Example:")
        appendLine("{\"thought\": \"Read the config first\", \"action\": {\"tool\": \"read_file\", \"arguments\": {\"path\": \"config.json\"}}}")
    }

    /** Renders the conversation so far: the task, then each step and what the tools returned. */
    fun renderTurn(
        task: String,
        history: List<TranscriptEntry>
    ): String = buildString {
        appendLine("Task: $task")
        for (entry in history) {
            when (entry) {
                is TranscriptEntry.Call -> appendLine("You called ${entry.tool}(${entry.arguments})")
                is TranscriptEntry.Observation -> {
                    appendLine(if (entry.ok) "Result of ${entry.tool}:" else "Error from ${entry.tool}:")
                    appendLine(truncate(entry.output))
                }
                is TranscriptEntry.Refusal -> appendLine("Refused ${entry.tool}: ${entry.reason}")
            }
        }
        appendLine()
        appendLine("Your next JSON object:")
    }

    /**
     * Pulls the first complete JSON object out of [reply].
     *
     * Models wrap JSON in prose and fences constantly, so this scans for a balanced object rather
     * than trusting the whole reply to parse.
     */
    fun parse(reply: String): AgentStep {
        val cleaned = reply.trim()
            .removePrefix("```json").removePrefix("```")
            .removeSuffix("```").trim()
        val start = cleaned.indexOf('{')
        if (start < 0) return AgentStep.Unreadable(reply, "no JSON object found in the reply")

        val end = endOfObject(cleaned, start)
        if (end < 0) return AgentStep.Unreadable(reply, "the JSON object in the reply is not closed")

        val body = cleaned.substring(start, end + 1)
        val json = try {
            JSONObject(body)
        } catch (e: Exception) {
            return AgentStep.Unreadable(reply, "the JSON object could not be parsed: ${e.message}")
        }

        val thought = json.optString("thought", "")

        val finalText = json.opt("final")
        if (finalText != null && finalText != JSONObject.NULL && finalText.toString().isNotBlank()) {
            return AgentStep.Answer(thought, finalText.toString())
        }

        val action = json.optJSONObject("action")
        if (action != null) {
            val tool = action.optString("tool", "")
            if (tool.isBlank()) return AgentStep.Unreadable(reply, "the action has no tool name")
            val arguments = action.optJSONObject("arguments") ?: JSONObject()
            return AgentStep.Call(thought, tool, arguments)
        }

        // Some models flatten the call one level up.
        val flatTool = json.optString("tool", "")
        if (flatTool.isNotBlank()) {
            val arguments = json.optJSONObject("arguments") ?: JSONObject()
            return AgentStep.Call(thought, flatTool, arguments)
        }

        return AgentStep.Unreadable(reply, "the object has neither 'final' nor 'action'")
    }

    /** Index of the `}` closing the object that starts at [start], or -1. */
    private fun endOfObject(text: String, start: Int): Int {
        var depth = 0
        var inString = false
        var escaped = false
        for (i in start until text.length) {
            val c = text[i]
            if (inString) {
                when {
                    escaped -> escaped = false
                    c == '\\' -> escaped = true
                    c == '"' -> inString = false
                }
                continue
            }
            when (c) {
                '"' -> inString = true
                '{' -> depth++
                '}' -> {
                    depth--
                    if (depth == 0) return i
                }
            }
        }
        return -1
    }

    private fun truncate(text: String, limit: Int = 8000): String =
        if (text.length <= limit) text
        else text.take(limit) + "\n… (truncated, ${text.length - limit} more characters)"
}
