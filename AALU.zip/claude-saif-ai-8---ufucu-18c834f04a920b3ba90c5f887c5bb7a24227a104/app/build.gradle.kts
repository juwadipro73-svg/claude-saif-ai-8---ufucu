/*
 * Copyright (c) SAIF AI. All rights reserved.
 *
 * Build script for the SAIF AI application module.
 *
 * The version is read from version.json at the repository root so the number a person sees in
 * the app is the same number that is committed. On GitHub Actions the run number is folded into
 * the version code, which guarantees every CI build is a strictly newer package than the last:
 * without that, Android sometimes refuses to install a freshly built APK over an older one and
 * the phone keeps quietly running the previous version.
 */

import groovy.json.JsonSlurper

// ---------------------------------------------------------------------------------------------
// Version
// ---------------------------------------------------------------------------------------------

val versionFile = rootProject.file("version.json")
val parsedVersion: Map<String, Any> = if (versionFile.exists()) {
    @Suppress("UNCHECKED_CAST")
    JsonSlurper().parseText(versionFile.readText()) as Map<String, Any>
} else {
    mapOf("version_code" to 1, "version_name" to "1.0.0")
}

val baseVersionCode = (parsedVersion["version_code"] as? Number)?.toInt() ?: 1
val baseVersionName = (parsedVersion["version_name"] as? String) ?: "1.0.0"

val ciRunNumber = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull()
val ciSha = (System.getenv("GITHUB_SHA") ?: "").take(7)

val appVersionCode = if (ciRunNumber != null) maxOf(baseVersionCode, 1000 + ciRunNumber) else baseVersionCode
val appVersionName = if (ciRunNumber != null) "$baseVersionName-b$ciRunNumber" else baseVersionName
val buildStamp = if (ciRunNumber != null) "build #$ciRunNumber ($ciSha)" else "local build"

/**
 * Reads an endpoint from the environment and refuses anything that is not a plain HTTPS URL.
 *
 * These end up baked into BuildConfig as Java string literals, so a stray quote or backslash
 * would not just be wrong, it would stop the file compiling. Validating here turns that into a
 * readable build error naming the offending variable.
 */
fun httpsEnv(key: String): String {
    val value = System.getenv(key).orEmpty().trim().trimEnd('/')
    require(value.isEmpty() || (value.startsWith("https://") && '"' !in value && '\\' !in value)) {
        "$key must be an HTTPS URL"
    }
    return value
}

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.compose.compiler)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.google.devtools.ksp)
    alias(libs.plugins.google.services)
}

android {
    namespace = "com.example.saifai"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.saifai.app"
        // 26 is the floor for the bundled Linux workspace; 28 is the ceiling this build is
        // tested against, and raising it changes storage behaviour the app is not ready for.
        minSdk = 26
        targetSdk = 28
        versionCode = appVersionCode
        versionName = appVersionName
        buildConfigField("String", "BUILD_STAMP", "\"$buildStamp\"")

        // Optional model-provider keys. Read from the environment only; empty in a normal build,
        // in which case the user supplies their own key inside the app.
        buildConfigField("String", "GEMINI_API_KEY", "\"${System.getenv("GEMINI_API_KEY") ?: ""}\"")
        buildConfigField("String", "OPENROUTER_API_KEY", "\"${System.getenv("OPENROUTER_API_KEY") ?: ""}\"")

        // Public endpoint URLs. No secret ever goes in here.
        listOf("SAIF_CLOUD_API_BASE_URL", "SAIF_DOWNLOAD_PORTAL_URL", "SAIF_FIREBASE_DATABASE_URL")
            .forEach { key -> buildConfigField("String", key, "\"${httpsEnv(key)}\"") }

        // Telegram asset library, supplied as CI secrets; empty when not configured.
        buildConfigField("String", "TG_BOT_TOKEN", "\"${System.getenv("TG_BOT_TOKEN") ?: ""}\"")
        buildConfigField("String", "TG_CHAT_ID", "\"${System.getenv("TG_CHAT_ID") ?: ""}\"")

        // Source publication address. Point it at the exact commit being shipped so the binary
        // and its source can always be matched up afterwards.
        buildConfigField("String", "SAIF_SOURCE_URL", "\"${httpsEnv("SAIF_SOURCE_URL")}\"")
    }

    signingConfigs {
        // A fixed debug key lives in the repository on purpose. CI runners otherwise mint a new
        // random debug key per build, and Android then treats each APK as a different app:
        // installing over the previous one fails with "App not installed" and the phone silently
        // keeps running the old build.
        getByName("debug") {
            storeFile = file("saif-debug.jks")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    flavorDimensions += "mode"
    productFlavors {
        // The local bridge, hub and browser tool server each need their own port. They are fixed
        // here rather than searched for at runtime so the on-device firewall rules and the
        // workspace scripts can be written against known numbers.
        create("standard") {
            dimension = "mode"
            applicationId = "com.saifai.app"
            buildConfigField("int", "BRIDGE_PORT", "1236")
            buildConfigField("int", "HUB_PORT", "1237")
            buildConfigField("int", "BROWSER_MCP_PORT", "8767")
        }
    }

    buildTypes {
        debug {
            // Nothing to add: the default debug config already disables minification.
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    base {
        archivesName.set("app")
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
        disable += "ExpiredTargetSdkVersion"
    }

    buildFeatures {
        compose = true
        buildConfig = true
        aidl = false
        shaders = false
    }

    androidResources {
        // Archives are streamed straight out of the assets folder by the workspace installer;
        // re-compressing them inside the APK would gain nothing and cost install size.
        noCompress += listOf("gz", "tgz", "tar.gz", "tar", "apk")
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "META-INF/DEPENDENCIES"
            excludes += "META-INF/INDEX.LIST"
            excludes += "META-INF/LICENSE*"
            excludes += "META-INF/NOTICE*"
            excludes += "META-INF/io.netty.versions.properties"
            excludes += "*.xsd"
            excludes += "**/*.xsd"
        }
    }
}

kotlin {
    jvmToolchain(21)
}

dependencies {
    val composeBom = platform(libs.androidx.compose.bom)
    implementation(composeBom)

    // --- Android foundation ---
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation("androidx.work:work-runtime-ktx:2.10.0")
    implementation(libs.androidx.datastore.preferences)
    implementation(libs.androidx.webkit)
    implementation(libs.kotlinx.coroutines.android)
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")

    // --- Compose UI ---
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)
    debugImplementation(libs.androidx.compose.ui.tooling)

    // --- Navigation 3 ---
    implementation(libs.androidx.navigation3.runtime)
    implementation(libs.androidx.navigation3.ui)
    implementation(libs.androidx.lifecycle.viewmodel.navigation3)

    // --- Networking and serialization ---
    implementation(libs.okhttp)
    implementation(libs.okhttp.sse)
    implementation(libs.kotlinx.serialization.json)

    // --- Markdown, LaTeX and images in assistant replies ---
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("io.coil-kt:coil-svg:2.7.0")
    implementation("io.noties.markwon:ext-latex:4.6.2")
    implementation("ru.noties:jlatexmath-android:0.2.0")

    // --- Workspace: SSH into the local environment, and unpack its bootstrap archives ---
    implementation("com.github.mwiede:jsch:0.2.20")
    implementation("org.apache.commons:commons-compress:1.26.1")
    implementation("org.tukaani:xz:1.9")

    // --- Terminal emulator (native PTY); the terminal view itself is built from source ---
    implementation("com.github.termux.termux-app:terminal-emulator:v0.118.1")
    implementation("com.google.guava:listenablefuture:1.0")

    // --- Web tools used by the agent ---
    implementation("org.jsoup:jsoup:1.18.3")

    // --- Code editor ---
    implementation("io.github.Rosemoe.sora-editor:editor:0.23.6")
    implementation("io.github.Rosemoe.sora-editor:language-textmate:0.23.6")
    implementation("io.github.Rosemoe.sora-editor:language-java:0.23.6")

    // --- Persistence ---
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    // --- Sign-in and cloud sync ---
    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.auth)
    implementation(libs.firebase.firestore)
    implementation("com.google.firebase:firebase-database")
    implementation("com.google.firebase:firebase-appcheck-playintegrity")

    // --- Audio playback for speech output ---
    implementation(libs.media3.common)
    implementation(libs.media3.exoplayer)
    implementation(libs.media3.ui)

    // --- On-device APK signing and automation ---
    implementation(libs.apksig)
    implementation(project(":automation"))
}

// OkHttp appears through several transitive paths; pinning one version keeps the SSL stack,
// the interceptor chain and the WebSocket code all agreeing on a single implementation.
configurations.all {
    resolutionStrategy {
        force("com.squareup.okhttp3:okhttp:4.12.0")
        force("com.squareup.okhttp3:okhttp-android:4.12.0")
    }
}

// The on-device compiler wraps a user's project inside a real Android app. That container is the
// :apprunner module's debug APK, copied into this module's assets under a fixed name so the
// compiler can find it at runtime without knowing anything about Gradle.
val bundleBaseRunnerApk by tasks.registering(Sync::class) {
    dependsOn(":apprunner:assembleDebug")
    from(project(":apprunner").layout.buildDirectory.dir("outputs/apk/debug")) {
        include("*.apk")
        exclude("*unaligned*")
        rename { "base_runner.apk" }
    }
    into(layout.buildDirectory.dir("generated/baseRunnerAssets"))
}

android.sourceSets.getByName("main").assets.srcDir(
    layout.buildDirectory.dir("generated/baseRunnerAssets").get().asFile
)

tasks.matching {
    (it.name.startsWith("merge") || it.name.startsWith("generate")) && it.name.endsWith("Assets")
}.configureEach { dependsOn(bundleBaseRunnerApk) }
tasks.named("preBuild").configure { dependsOn(bundleBaseRunnerApk) }
